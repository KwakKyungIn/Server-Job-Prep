## Section 5: 운영 관측 & 성능 검증 (Page 35~37)

Section 5는 "기능이 동작한다"를 넘어 "운영 상황에서도 수치로 설명 가능하다"를 증명하는 파트다.
Page 35~37은 성능 가드레일, 관측 체계, 부하 실험 보고를 한 흐름으로 연결해 제출 심사자가 품질 근거를 빠르게 추적할 수 있도록 구성한다.

---

## Page 35. 메모리/송신 성능 가드레일

### 페이지 핵심 메시지
- 실시간 서버의 안정성은 기능 코드보다 할당/송신 경로의 상한과 재사용 정책에서 먼저 결정된다.

### 이 페이지가 필요한 이유
- 전투/이동/브로드캐스트가 겹치는 구간에서는 짧은 시간에 객체 생성과 송신 요청이 급증한다.
- 이때 정책 없는 `new/delete`와 무제한 송신 큐는 지연 급증, 메모리 파편화, 스파이크를 유발한다.
- 따라서 이 페이지는 "가드레일이 실제 코드로 강제되는가"를 보여주는 증거 페이지로 둔다.

### 가드레일 A: ObjectPool + MemoryPool 기반 할당 경로 고정
- `Memory`는 크기 구간별 풀 테이블을 구성해 소형/중형 할당을 풀 경로로 수렴시킨다.
- `ObjectPool<T>`는 타입 단위로 `Pop/Push`를 강제해 핫패스 객체의 할당/해제를 정형화한다.
- 전투 투사체, 몬스터 스폰, 룸 Job 적재에 동일 정책을 적용해 할당 비용 분산을 줄인다.

### 가드레일 B: SendBufferChunk 재사용
- `SendBufferChunk`는 6KB 고정 청크를 재사용하며, `SendBuffer`는 청크 내부 슬라이스만 참조한다.
- `SendBufferManager`는 TLS 청크 우선, 부족 시 글로벌 풀 보충으로 송신 버퍼 재할당을 완화한다.
- Scatter-Gather `WSASend`와 결합해 다건 송신의 복사/할당 비용을 줄인다.

### 가드레일 C: 백로그 상한 + 배치 송신 + 단일 in-flight 등록
- 하드캡: `MAX_BACKLOG_BYTES(128KB)` / `MAX_BACKLOG_COUNT(256)` 초과 시 즉시 드롭한다.
- 소프트캡: 이미 `WSASend`가 진행 중이면 더 낮은 임계치(`64KB/128`)를 적용해 급격한 적체를 완충한다.
- 배치 송신: `MAX_SEND_BATCH_BYTES(32KB)` / `MAX_SEND_BATCH_COUNT(64)` 범위로 묶어 `WSASend` 등록한다.
- `_sendRegistered` 게이트로 동시에 1개 송신 등록만 유지해 등록 경쟁을 제어한다.

### 운영 기준표 (페이지 표)
| 구분 | 코드 기준값 | 동작 방식 | 운영 의미 |
| --- | --- | --- | --- |
| 백로그 하드캡 | `128KB / 256` | 초과 시 `Send` 드롭 | 세션 단위 과적체 차단 |
| 백로그 소프트캡 | `64KB / 128` | 송신 진행 중 추가 드롭 | 스파이크 완화 |
| 송신 배치 상한 | `32KB / 64` | 다건 패킷 묶음 `WSASend` | syscall/락 왕복 절감 |
| 청크 크기 | `6000 bytes` | 고정 청크 재사용 | 송신 버퍼 단편화 완화 |

### 35페이지 전용 배치
- 상단: "가드레일 없이는 지연이 아니라 붕괴가 먼저 온다" 메시지 배너.
- 좌측 상단: 메모리 경로(`MemoryPool/ObjectPool`) 카드.
- 좌측 하단: 송신 청크 재사용(`SendBufferChunk`) 카드.
- 우측 상단: 하드캡/소프트캡/배치 상한 정책 표.
- 우측 하단: `Send -> Queue -> Batch WSASend -> ProcessSend` 흐름 다이어그램.

### 시각 스타일 가이드
- 메모리 관련 카드는 `청록 계열`, 송신 가드레일 카드는 `주황 계열`로 분리해 인지 경계를 만든다.
- 상한값(`128KB`, `64KB`, `32KB`, `256`, `128`, `64`)은 단색 강조 배지로 시각적으로 고정한다.
- 코드 스니펫은 2개만 크게 배치하고, 나머지는 "증명 스니펫 목록"으로 하단에 정리한다.
- 아이콘은 `shield`(보호), `stack`(풀링), `wave`(트래픽) 3종만 사용해 과밀을 피한다.

### 삽입 다이어그램
```mermaid
flowchart LR
  A[Gameplay Event] --> B[ObjectPool<T>::MakeShared]
  B --> C[MemoryPool Bucket]
  A --> D[Session::Send]
  D --> E{Hard/Soft Backlog Cap}
  E -->|drop| X[Overload Shed]
  E -->|pass| F[SendQueue Enqueue]
  F --> G[RegisterSend]
  G --> H[Batch by Bytes/Count]
  H --> I[WSASend Scatter-Gather]
  I --> J[ProcessSend]
  J --> K{Queue Empty?}
  K -->|yes| L[_sendRegistered=false]
  K -->|no| G
```

### 증명 스니펫
- `ServerCore/Memory.cpp:12`
- `ServerCore/Memory.cpp:26`
- `ServerCore/Memory.cpp:39`
- `ServerCore/Memory.cpp:79`
- `ServerCore/Memory.cpp:107`
- `ServerCore/ObjectPool.h:22`
- `ServerCore/ObjectPool.h:35`
- `ServerCore/ObjectPool.h:41`
- `GameServer/GameRoom.Combat.cpp:102`
- `GameServer/GameRoom.LifeTime.cpp:135`
- `GameServer/GameRoom.h:50`
- `GameServer/GameRoom.h:63`
- `ServerCore/SendBuffer.h:46`
- `ServerCore/SendBuffer.cpp:89`
- `ServerCore/SendBuffer.cpp:92`
- `ServerCore/SendBuffer.cpp:101`
- `ServerCore/SendBuffer.cpp:113`
- `ServerCore/Session.h:59`
- `ServerCore/Session.h:63`
- `ServerCore/Session.cpp:128`
- `ServerCore/Session.cpp:138`
- `ServerCore/Session.cpp:298`
- `ServerCore/Session.cpp:319`
- `ServerCore/Session.cpp:348`
- `ServerCore/Session.cpp:443`

### 근거 코드
- `ServerCore/Memory.cpp`
- `ServerCore/ObjectPool.h`
- `ServerCore/SendBuffer.h`
- `ServerCore/SendBuffer.cpp`
- `ServerCore/Session.h`
- `ServerCore/Session.cpp`
- `GameServer/GameRoom.Combat.cpp`
- `GameServer/GameRoom.LifeTime.cpp`
- `GameServer/GameRoom.h`

### 검증 기록 문장
- 동시 이동/전투 구간에서 백로그 상한 도달 시 드롭 정책이 작동해 세션 폭주가 전역 장애로 번지지 않음을 확인했다.
- 투사체/몬스터/Job 생성 경로가 `ObjectPool` 경유로 고정되는지 코드/로그를 교차 확인했다.
- 배치 송신 후 큐 잔량에 따라 재등록/해제가 순환하는지 `ProcessSend` 경로로 점검했다.

---

## Page 36. 관측 체계 (Prometheus + Grafana)

### 페이지 핵심 메시지
- 운영 품질은 로그 한 줄이 아니라 "동일 시간축에서 비교 가능한 메트릭 집합"으로 관리해야 한다.

### 설계 의도
- 공용 계층(ServerCore)에서 `/metrics`를 열고, 도메인 계층(GameServer/DBAgent)에서 지표 의미를 채운다.
- 패킷 경로에는 공통 훅을 삽입해 신규 기능이 추가되어도 계측 누락 위험을 낮춘다.
- 대시보드는 쿼리 문서와 JSON 자산을 함께 제공해 재현성을 보장한다.

### 관측 아키텍처 구성
1. `CoreGlobal`이 설정에서 Metrics 옵션을 읽고 `MetricsSystem`을 초기화한다.
2. `MetricsExporter`가 HTTP `/metrics` 엔드포인트를 열고 Prometheus 포맷 텍스트를 렌더링한다.
3. `PacketMetricsHooks`가 dispatch/handled/failure/makeSend/parsed 지점을 공통 후킹한다.
4. GameServer는 패킷/로비 대기/S2S RTT/CCU/Ingame 지표를 기록한다.
5. DBAgent는 요청 처리/쿼리/풀 대기/풀 사용량 지표를 기록한다.
6. Prometheus가 두 서버를 scrape하고, Grafana JSON 대시보드로 시각화한다.

### 도메인별 핵심 지표 맵
| 도메인 | 대표 지표 | 해석 포인트 |
| --- | --- | --- |
| GameServer Packet | `packet_ingress_total`, `packet_handle_seconds`, `packet_failure_total` | 처리량, 처리지연, 실패원인 분해 |
| GameServer Lobby/S2S | `lobby_wait_seconds`, `s2s_rtt_seconds` | 입장 병목, DB 왕복 지연 추적 |
| ServerCore Queue/Worker | `jobqueue_*`, `globalqueue_*`, `worker_*` | 큐 정체와 워커 유휴/실행 비율 분해 |
| Session I/O | `session_rx_bytes_total`, `session_tx_bytes_total` | 네트워크 처리량 추세 |
| DBAgent | `req_*`, `query_seconds`, `pool_wait_seconds`, `pool_size/inuse` | DB 경로 병목 및 풀 포화 감지 |

### 대시보드 재현 자산
- Prometheus scrape 설정: `docs/monitoring/prometheus.yml`
- Grafana 실행 환경: `docs/monitoring/docker-compose.yml`
- GameServer 패널/쿼리 문서: `docs/monitoring/gameserver_dashboard_queries.md`
- DBAgent 패널/쿼리 문서: `docs/monitoring/dbagent_dashboard_queries.md`
- Dashboard JSON: `docs/monitoring/grafana_gameserver_dashboard.json`, `docs/monitoring/grafana_dbagent_dashboard.json`

### 36페이지 전용 배치
- 상단: "수집 -> 해석 -> 조치" 3단 파이프라인 배너.
- 좌측: ServerCore 공용 계층(`CoreGlobal`, `MetricsSystem`, `Exporter`) 박스.
- 중앙: GameServer/DBAgent 도메인 계측 카드 2열.
- 우측: Prometheus scrape + Grafana 패널 묶음.
- 하단: 지표-원인-조치 매핑 표(예: queue wait 상승 -> shard 편중/락 경합 점검).

### 시각 스타일 가이드
- 공용 계층은 `남색`, GameServer는 `청색`, DBAgent는 `녹색`으로 고정해 해석 축을 통일한다.
- p95 패널은 굵은 선, throughput 패널은 얇은 선으로 스타일을 분리해 해석 우선순위를 만든다.
- 장애 징후 계열(실패율, pool wait)은 `적색 포인트`를 사용해 즉시 식별 가능하게 구성한다.
- 페이지 우하단에 "대시보드 JSON 재현 가능" 배지를 고정해 제출 신뢰도를 높인다.

### 삽입 다이어그램
```mermaid
flowchart LR
  A[CoreGlobal Load Metrics Config] --> B[MetricsSystem Initialize]
  B --> C[MetricsExporter /metrics]
  D[PacketMetricsHooks] --> E[GameServer Metrics]
  D --> F[DBAgent Metrics]
  G[JobQueue/GlobalQueue/Worker Metrics] --> C
  E --> C
  F --> C
  C --> H[Prometheus Scrape]
  H --> I[Grafana Dashboards]
```

### 증명 스니펫
- `ServerCore/CoreGlobal.h:10`
- `ServerCore/CoreGlobal.h:15`
- `ServerCore/CoreGlobal.cpp:44`
- `ServerCore/CoreGlobal.cpp:187`
- `ServerCore/CoreGlobal.cpp:231`
- `ServerCore/CoreGlobal.cpp:238`
- `ServerCore/MetricsSystem.cpp:13`
- `ServerCore/MetricsSystem.cpp:49`
- `ServerCore/MetricsSystem.cpp:60`
- `ServerCore/MetricsExporter.cpp:35`
- `ServerCore/MetricsExporter.cpp:85`
- `ServerCore/MetricsExporter.cpp:131`
- `ServerCore/MetricsExporter.cpp:164`
- `ServerCore/MetricsExporter.cpp:175`
- `ServerCore/MetricsExporter.cpp:247`
- `ServerCore/PacketMetricsHooks.h:49`
- `ServerCore/PacketMetricsHooks.h:68`
- `ServerCore/PacketMetricsHooks.h:89`
- `GameServer/GameServer.cpp:170`
- `GameServer/GameMetrics.cpp:33`
- `GameServer/GameMetrics.cpp:52`
- `GameServer/GameMetrics.cpp:450`
- `GameServer/GameMetrics.cpp:478`
- `GameServer/GameMetrics.cpp:530`
- `GameServer/GameMetrics.cpp:542`
- `ServerCore/JobQueue.cpp:39`
- `ServerCore/JobQueue.cpp:49`
- `ServerCore/ThreadManager.cpp:23`
- `ServerCore/GlobalQueue.cpp:22`
- `ServerCore/Session.cpp:24`
- `DBAgent/DBAgent.cpp:43`
- `DBAgent/DBAgentMetrics.cpp:47`
- `DBAgent/DBAgentMetrics.cpp:65`
- `DBAgent/DBAgentMetrics.cpp:243`
- `DBAgent/DBConnectionPool.cpp:112`
- `DBAgent/DBConnection.cpp:77`

### 근거 코드/자산
- `ServerCore/CoreGlobal.cpp`
- `ServerCore/MetricsSystem.cpp`
- `ServerCore/MetricsExporter.cpp`
- `ServerCore/PacketMetricsHooks.h`
- `ServerCore/JobQueue.cpp`
- `ServerCore/ThreadManager.cpp`
- `ServerCore/GlobalQueue.cpp`
- `ServerCore/Session.cpp`
- `GameServer/GameMetrics.cpp`
- `DBAgent/DBAgentMetrics.cpp`
- `DBAgent/DBConnectionPool.cpp`
- `DBAgent/DBConnection.cpp`
- `docs/monitoring/prometheus.yml`
- `docs/monitoring/docker-compose.yml`
- `docs/monitoring/grafana_gameserver_dashboard.json`
- `docs/monitoring/grafana_dbagent_dashboard.json`

### 검증 기록 문장
- 설정값(`Enabled/Port/Path/BindAddress`) 변경 시 `/metrics` 노출 경로가 기대대로 반영되는지 확인했다.
- GameServer와 DBAgent가 각각 독립 프리픽스로 지표를 노출하고, 대시보드 쿼리와 라벨 체계가 일치하는지 검증했다.
- 패킷 실패(reason)/큐 대기/pool wait를 동시에 보면 병목 원인 분해가 가능함을 실험 로그로 확인했다.

---

## Page 37. DummyClient 부하 검증 보고

### 페이지 핵심 메시지
- 부하 실험은 최대 CCU 수치보다, 동일 조건에서 재현 가능한 관측 체계(Prometheus/Grafana)로 비교 가능해야 제출 가치가 높다.

### 검증 시나리오 모델
- `idle`: Heartbeat 중심 연결 유지 구간.
- `move`: 이동 패킷 중심 AOI/검증 구간.
- `combat`: 스킬 패킷 중심 전투 처리 구간.
- `mix`: 이동+스킬+Heartbeat 혼합 운영 근접 구간.

### 실행 설계
1. `LoadClientConfig`에서 목표 CCU, 램프업 간격, 유지시간, 시나리오 Hz를 로드한다.
2. 클라이언트 상태머신(로그인 -> 입장 -> 인게임)으로 세션을 자동 전개한다.
3. 목표 CCU 도달 전까지 `ramp_step / ramp_interval_sec` 정책으로 점진 투입한다.
4. 서버 측 `/metrics`를 Prometheus가 scrape하고, Grafana 대시보드 쿼리로 시계열을 수집한다.
5. Grafana/Prometheus 결과 CSV를 기준으로 기능 변경 전/후 비교표를 작성한다.

### 수집 지표 계약
| 분류 | 지표 | 산출 방식 |
| --- | --- | --- |
| 상태 | `gs_ccu`, `gs_ingame_players` | Gauge 시계열 |
| 처리량 | `rate(gs_packet_ingress_total)`, `rate(gs_session_tx_bytes_total)` | PromQL rate |
| 지연 | `histogram_quantile(0.95, ..._bucket)` 계열 | PromQL p95 |
| 안정성 | `rate(gs_packet_failure_total)`, `rate(db_req_failure_total)` | 오류율 시계열 |
| DB 경로 | `histogram_quantile(0.95, rate(db_pool_wait_seconds_bucket))` | DB 대기 병목 추적 |

### 관측 소스 계약
- 부하 발생기: `DummyClient` (트래픽 생성 전용)
- 관측/집계: Prometheus scrape + Grafana 패널 쿼리
- 보고 산출물: `docs/monitoring/result/first.csv`

### 실제 샘플 데이터 (Grafana/Prometheus 결과)
- `docs/monitoring/result/first.csv`는 UTF-16 CSV로 저장되어 있으며, `2026-02-10 11:57 ~ 12:00` 구간 실험값을 포함한다.
- 예시 구간에서 `ccu 205 -> 307` 램프업이 관찰되며, `packet_ingress_total_rps`는 `117 -> 597`까지 상승한다.
- 후반 구간의 `NaN` 값은 해당 윈도우에 샘플이 없거나 분모가 0인 구간을 의미하므로, 보고서 표에서는 결측 처리 규칙을 명시한다.

### 제출용 비교 표 템플릿 (Page 37 하단)
| 시나리오 | 비교 항목 | 변경 전 | 변경 후 | 해석 |
| --- | --- | --- | --- | --- |
| Move 300 CCU | `gs_packet_handle_seconds` p95 | [ ] | [ ] | [ ] |
| Mix 300 CCU | `packet_ingress_total_rps` | [ ] | [ ] | [ ] |
| Mix 300 CCU | `gs_packet_failure_total` rate | [ ] | [ ] | [ ] |
| Mix 300 CCU | `db_pool_wait_seconds` p95 | [ ] | [ ] | [ ] |

### 평가 기준 템플릿 (값/평가 입력 영역)
| 항목 | 기준 | 실제 값 | 판정 |
| --- | --- | --- | --- |
| 안정 구간 길이 | [ ] | [ ] | [ ] |
| 오류율 상한 | [ ] | [ ] | [ ] |
| p95 허용 상한 | [ ] | [ ] | [ ] |
| DB 대기 허용 상한 | [ ] | [ ] | [ ] |

### 37페이지 전용 배치
- 상단: 테스트 조건 카드(`CCU`, `ramp`, `hold`, `scenario`).
- 좌측: 부하 생성 -> scrape -> 대시보드 -> 비교표 흐름 다이어그램.
- 우측 상단: 실험 결과 요약 수치 카드(P95, RPS, 실패율).
- 우측 하단: 변경 전/후 비교 표.
- 하단 전체: PromQL 기준식 + CSV 원본 경로 + 결측 처리 규칙 + 해석 주의사항.

### 시각 스타일 가이드
- 시나리오별 색 고정: `idle=회색`, `move=청색`, `combat=적색`, `mix=주황`.
- 시간축 그래프는 `CCU`, `RTT p95`, `error` 3개만 기본 노출하고 나머지는 부록으로 분리한다.
- 핵심 결론 숫자는 "단위 포함 배지"로 표기(`ms`, `rps`, `%`)해 해석 오류를 줄인다.
- 표 캡션은 원인-결론 문장형으로 작성한다. 예: "CCU [ ] 유지 구간에서 ingress 증가 대비 오류율 [ ] 유지."

### 삽입 다이어그램
```mermaid
flowchart LR
  A[LoadClientConfig.json] --> B[DummyClient Ramp-Up]
  B --> C[Scenario Tick idle/move/combat/mix]
  C --> D[GameServer/DBAgent Metrics]
  D --> E[Prometheus Scrape]
  E --> F[Grafana Panels & PromQL]
  F --> G[CSV Export first.csv]
  G --> H[Before/After Comparison Report]
```

### 증명 스니펫
- `DummyClient/DummyClient.cpp:32`
- `DummyClient/DummyClient.cpp:58`
- `DummyClient/LoadClientConfig.json:5`
- `DummyClient/LoadClientConfig.json:13`
- `DummyClient/LoadClientConfig.json:39`
- `DummyClient/LoadClientManager.cpp:17`
- `DummyClient/LoadClientManager.cpp:955`
- `DummyClient/LoadClientManager.cpp:990`
- `docs/monitoring/prometheus.yml:7`
- `docs/monitoring/prometheus.yml:15`
- `docs/monitoring/gameserver_dashboard_queries.md:12`
- `docs/monitoring/gameserver_dashboard_queries.md:86`
- `docs/monitoring/dbagent_dashboard_queries.md:12`
- `docs/monitoring/dbagent_dashboard_queries.md:32`
- `docs/monitoring/grafana_gameserver_dashboard.json`
- `docs/monitoring/grafana_dbagent_dashboard.json`
- `docs/monitoring/result/first.csv`

### 근거 코드/산출물
- `DummyClient/LoadClientConfig.json`
- `DummyClient/LoadClientManager.cpp`
- `docs/monitoring/prometheus.yml`
- `docs/monitoring/gameserver_dashboard_queries.md`
- `docs/monitoring/dbagent_dashboard_queries.md`
- `docs/monitoring/grafana_gameserver_dashboard.json`
- `docs/monitoring/grafana_dbagent_dashboard.json`
- `docs/monitoring/result/first.csv`

### 검증 기록 문장
- 목표 CCU 도달 전까지 램프업 정책이 단계적으로 적용되는지(`ramp_step`, `ramp_interval_sec`)를 로그와 CSV로 확인했다.
- 시나리오 문자열 변경 시 `idle/move/combat/mix` 동작 분기가 기대대로 전환되는지 점검했다.
- Grafana 패널 쿼리(`p95`, `rate`)와 CSV 내 컬럼 정의가 동일한 기준식으로 대응되는지 확인했다.
- 결과 CSV의 결측(`NaN`) 구간은 지정한 결측 처리 규칙으로 분리해 해석 왜곡을 방지하도록 명시했다.

---

## Section 5 마무리 문장 (섹션 마지막 박스)

- Section 5는 "성능 최적화 기법" 소개가 아니라, **운영 관점에서 통제 가능한 가드레일과 관측 체계**를 증명하는 파트다.
- 즉, 이 섹션의 결론은 "빠르다"가 아니라 **"문제 발생 시 원인을 추적하고 재현 가능한 방식으로 개선할 수 있다"**이다.
