## Section 4: 데이터 정합성 & 영속화 (Page 30~34)

Section 4는 기능 시연보다 "데이터가 어긋나지 않도록 어떻게 설계했는가"를 증명하는 파트다.
페이지마다 인증, 캐시, 트랜잭션, 부팅 동기화, UID 발급을 분리해 설명하며, 페이지별 흐름과 틀은 독립적으로 구성한다.
문서 톤은 section3와 맞춰 글자 크기와 색상 계열만 통일한다.

---

## Page 30. Redis 토큰 인증 + 세션 바인딩

### 페이지 핵심 메시지
- 로그인 성공 자체와 게임 입장 허용은 분리되어 있으며, Redis 토큰 검증을 통과한 세션만 PlayerId에 바인딩된다.

### 설계 의도와 기대 효과
- 로그인 성공 이벤트를 그대로 신뢰하지 않고, 게임 서버에서 입장 권한을 독립 검증하도록 설계했다.
- 인증 판정(`token miss/hit`)과 세션 식별 판정(후접속 우선 재바인딩)을 분리해 보안 경계와 운영 정합성을 동시에 확보했다.
- 비인가 진입은 빠르게 차단되고, 재접속 구간에서도 세션 인덱스가 최신 상태로 안정적으로 수렴한다.

### 이 페이지에서 보여줄 강점
- 인증 성공과 게임 입장을 분리한 2단계 인증 구조로 세션 신뢰도를 높였다.
- Redis TTL 토큰과 이름 컨텍스트 캐시를 결합해 보안성과 초기 입장 성능을 동시에 확보했다.
- 비유효 토큰 요청을 Fail-Fast로 차단해 인증 경계를 명확히 유지했다.
- 동일 플레이어 재접속 시 후접속 세션을 기준으로 식별자를 재고정해 세션 정합성을 유지했다.

### 이 기술을 선택한 이유
- 인증 서버와 게임 서버를 분리한 구조에서는 "로그인 성공 사실"을 게임 서버가 독립적으로 검증할 수 있어야 한다.
- Redis 토큰 + TTL(300초)은 재전송/탈취 토큰의 사용 가능 시간을 제한해 보안 경계를 짧게 유지한다.
- `token:name:{token}` 캐싱은 입장 시점의 추가 DB 조회를 줄여 초기 진입 지연을 줄인다.
- 토큰 검증 이후에만 `BindPlayerId`를 수행해야 세션-플레이어 매핑 오염을 방지할 수 있다.
- 재접속이 겹치는 환경에서 "후접속 세션 우선" 정책을 고정해야 stale 세션 재사용을 줄일 수 있다.

### 구현 포인트
1. LoginServer가 DB 로그인 성공 응답을 받으면 토큰 문자열을 생성하고 Redis에 TTL 300초로 저장한다.
2. 동일 TTL로 `token:name:{token}`를 저장해 캐릭터 이름 컨텍스트를 함께 넘긴다.
3. GameServer의 `Handle_C_ENTER_GAME`는 Redis에서 토큰을 조회해 `playerId`를 복원한다.
4. 유효 토큰만 입장을 진행하고, 비유효 요청은 즉시 차단해 인증 경계를 명확히 유지한다.
5. 검증 통과 후에만 `BindPlayerId`, `SetPlayerId_ActorOnly`를 수행해 세션 식별자를 고정한다.
6. `GameSessionManager`는 동일 `playerId` 재바인딩 시 후접속 세션을 우선해 역인덱스를 갱신한다.

### 토큰 발급 정책 구체화
- 토큰 포맷은 `Token_{playerId}_{timestamp}_{random}` 조합으로 생성해 예측 가능성을 낮춘다.
- 인증 키(`token -> playerId`)와 이름 컨텍스트 키(`token:name:{token} -> loginName`)를 동일 TTL(300초)로 운용한다.
- 이름 키를 분리 저장해 입장 시 캐릭터 이름 동기화를 DB 재조회 없이 처리한다.
- 게임 서버는 토큰 값만으로 인증을 판정하고, 추가 식별자 주입 없이 Redis 조회 결과를 단일 진실원으로 사용한다.

### 인증 결정 매트릭스
| 입력 상태 | 판정 | 서버 동작 | 보장 효과 |
| --- | --- | --- | --- |
| `token miss` | 실패 | 즉시 `Disconnect(Invalid Token)` | 비인가 진입 차단 |
| `token hit` + 정상 `playerId` | 성공 | `BindPlayerId` + `SetPlayerId_ActorOnly` | 세션 식별 고정 |
| `token hit` + 이름 키 miss | 성공 | 기본 이름 보정 경로로 진행 | 입장 동기화 연속성 |
| 동일 `playerId` 재접속 | 성공 | 후접속 세션으로 인덱스 갱신 | stale 세션 참조 축소 |

### 정합성·보안 보장 규칙
| 구분 | 적용 규칙 | 효과 |
| --- | --- | --- |
| 인증 경계 | Redis 토큰 검증 통과 세션만 입장 진행 | 비인가 진입 차단 |
| 토큰 생명주기 | TTL 300초 토큰 운용 | 단기 토큰 기반 안전성 확보 |
| 세션 식별 | 검증 통과 후 `BindPlayerId` 수행 | 세션 매핑 오염 방지 |
| 이름 컨텍스트 | `token:name:{token}` 캐시 활용 | 입장 초기 동기화 속도 향상 |
| 재접속 정책 | 동일 `playerId`는 후접속 세션으로 재바인딩 | stale 세션 참조 축소 |

### 30페이지 전용 배치
- 상단: "인증 성공과 입장 허용을 분리한 2단계 검증" 메시지 배너.
- 중단 좌측: LoginServer 토큰 발급 + TTL 정책 카드.
- 중단 우측: GameServer 토큰 검증 + Fail-Fast 차단 + 세션 바인딩 카드.
- 하단: 재접속 시 세션 식별자 재바인딩(후접속 우선) 타임라인.

### 삽입 다이어그램
```mermaid
flowchart LR
  A[C_LOGIN] --> B[DBAgent Login Verify]
  B --> C[S2S_RES_LOGIN success]
  C --> D[LoginServer Token Generate]
  D --> E[Redis SET token -> playerId TTL 300s]
  D --> F[Redis SET token:name:{token} TTL 300s]
  G[C_ENTER_GAME token] --> H[GameServer Redis GET token]
  H -->|miss| X[Disconnect Invalid Token]
  H -->|hit| I[BindPlayerId + SetPlayerId]
  I --> J[Session Index Update]
  J --> K[Latest Session Wins]
```

### 증명 스니펫
- `LoginServer/S2SPacketHandler.cpp:44`
- `LoginServer/S2SPacketHandler.cpp:49`
- `LoginServer/S2SPacketHandler.cpp:59`
- `GameServer/ClientPacketHandler.EnterGame.cpp:24`
- `GameServer/ClientPacketHandler.EnterGame.cpp:29`
- `GameServer/ClientPacketHandler.EnterGame.cpp:92`
- `GameServer/ClientPacketHandler.EnterGame.cpp:93`
- `GameServer/GameSessionManager.cpp:75`
- `GameServer/GameSessionManager.cpp:100`

### 근거 코드
- `LoginServer/S2SPacketHandler.cpp`
- `GameServer/ClientPacketHandler.EnterGame.cpp`
- `GameServer/GameSessionManager.cpp`

### 검증 기록 문장
- 만료 토큰으로 `C_ENTER_GAME` 요청 시 `Invalid Token` 로그와 함께 접속이 종료되는지 확인했다.
- 유효 토큰에서만 `BindPlayerId`가 수행되고, 비유효 토큰 경로에서는 세션 식별자 바인딩이 발생하지 않는지 확인했다.
- `token:name:{token}`가 함께 저장되고 입장 경로에서 조회되는지 확인했다.
- 동일 플레이어 재접속 시 최신 세션 매핑이 유지되는지 확인했다.

---

## Page 31. Redis Write-Back + AutoCommit

### 페이지 핵심 메시지
- 게임 로직은 Redis를 즉시 갱신하고 Dirty Set에 저장 예약만 수행하며, 실제 DB 반영은 AutoCommit 워커가 분리 처리한다.

### 이 기술을 선택한 이유
- 플레이 중 상태 변경 빈도가 높아 매 요청마다 DB I/O를 수행하면 게임 루프 지연이 급격히 증가한다.
- Redis Hash는 필드 단위 갱신이 가능해 전체 레코드 재직렬화 없이 저비용으로 상태를 반영할 수 있다.
- Dirty Set은 Set 특성으로 PID 중복을 자동 제거해 배치 저장 대상 선별 비용을 줄인다.
- AutoCommit 워커 분리는 게임 로직 스레드의 레이턴시를 DB 부하로부터 분리하는 데 핵심적이다.
- 코어/인벤/퀵슬롯을 개별 저장 패킷으로 분리해, 특정 도메인 실패가 전체 저장을 막지 않도록 설계했다.
- 저장 전송 함수를 콜백으로 주입해 `AutoCommitService`가 DB 세션 객체에 직접 의존하지 않도록 결합도를 낮췄다.
- `RequestFlushNow`는 종료 직전 변경분을 빠르게 밀어넣는 보조 안전장치로 운영상 유효하다.

### 핵심 키 계약 (Prime·Dirty·Gate)
| 구분 | 키/구조 | 역할 |
| --- | --- | --- |
| Prime 대상 | `p:{pid}:core/inv/qs` | 접속 시 재적재해 시작 상태 고정 |
| Dirty 집계 | `dirty:player/inv/qs` | 도메인별 변경 PID 수집 |
| 즉시 대상 | `_flushNow` | 종료/이벤트 PID 우선 반영 |
| 전송 게이트 | `_inflightCount` | 응답 대기 PID 중복 전송 차단 |
| Prime 정리 | `p:{pid}:invdel` | 이전 세션 Tombstone 정리 |

### Prime 정리 규칙
1. 접속 시점에 `p:{pid}:core/inv/qs`를 재적재해 런타임 기준 데이터를 먼저 고정한다.
2. 이전 세션의 `dirty:*`, `p:{pid}:invdel` 잔재를 먼저 비워 시작 오염을 막는다.
3. Prime 이후 변경분만 Dirty로 집계되도록 라운드 시작선을 명확히 맞춘다.

### Dirty 집계 규칙
1. Runtime 변경은 Redis Hash에 즉시 반영하고 `dirty:player/inv/qs`에 `pid`를 기록한다.
2. 커밋 대상은 `dirty:* + _flushNow` 합집합으로 계산해 라운드 기준을 단일화한다.
3. Set 특성으로 동일 PID 중복을 자동 제거해 불필요한 대상 확장을 막는다.

### In-Flight 게이트 규칙
1. `_inflightCount[pid]`가 존재하면 해당 PID는 이번 라운드에서 제외한다.
2. 도메인 전송 건수만큼 in-flight를 증가시키고, 응답마다 감소시켜 게이트를 닫는다.
3. 게이트가 열린 PID만 다음 라운드 재진입이 가능해 중복 전송 경쟁을 구조적으로 차단한다.

### 응답 수렴 규칙
1. 성공 응답 도메인만 Dirty를 해제해 정상 반영 경로를 즉시 닫는다.
2. 인벤토리 성공 시 `p:{pid}:invdel`까지 함께 정리해 삭제 상태를 동기화한다.
3. 실패 응답 도메인은 Dirty를 유지해 다음 라운드 자동 재시도로 연결한다.
4. `OnCommitFinished`에서 in-flight를 감소시켜 다음 라운드 진입 가능 상태를 회복한다.

### 31페이지 전용 배치
- 상단 좌측: 왜 이 구조를 선택했는가
- 상단 우측: 핵심 키 계약(Prime·Dirty·Gate)
- 하단 좌측: 필수 규칙 4개(Prime/Dirty/In-Flight/응답 수렴)
- 하단 우측: AutoCommit 워커 파이프라인(기존 가로 폭의 약 2/3)

### 결론 (짧게)
- Prime으로 시작 상태를 고정하고, Dirty 집계와 In-Flight 게이트로 중복 없는 커밋 라운드를 유지한다.
- 그 결과 고빈도 변경 구간에서도 Write-Back 경로가 안정적으로 수렴한다.

### 삽입 다이어그램
```mermaid
flowchart LR
  A[Game Logic Update] --> B[PersistenceService Update Redis]
  B --> C[Mark Dirty Sets]
  C --> D[AutoCommit Worker 120s or FlushNow Wake]
  E[Disconnect FlushNow] --> D
  D --> F[Collect Targets dirty+flushNow]
  F --> G[Skip pid if inflightCount exists]
  G --> H[BuildSnapshot Core Inv QuickSlot]
  H --> I[S2S_REQ_SAVE_PLAYER_CORE]
  H --> J[S2S_REQ_SAVE_INVENTORY]
  H --> K[S2S_REQ_SAVE_QUICKSLOT]
  I --> L[S2S_RES_SAVE_PLAYER_CORE]
  J --> M[S2S_RES_SAVE_INVENTORY]
  K --> N[S2S_RES_SAVE_QUICKSLOT]
  L --> O{success?}
  M --> O
  N --> O
  O -->|yes| P[Clear Dirty On Success]
  O -->|no| Q[Keep Dirty Retry Next Tick]
  P --> R[OnCommitFinished]
  Q --> R
```

---

## Page 32. DBAgent 트랜잭션 경로

### 페이지 핵심 메시지
- 게임 서버는 상태 스냅샷만 전달하고, DBAgent는 Connection Pool + Prepared Statement + 트랜잭션으로 최종 커밋 책임을 전담한다.

### 문제 정의
- 게임 로직 스레드에서 직접 SQL을 수행하면 락 경합과 장애 전파 범위가 커진다.
- 인벤토리/퀵슬롯/거래는 다중 쿼리 원자성이 필요하므로 단일 UPDATE 모델로는 정합성 보장이 어렵다.

### 이 기술을 선택한 이유
- DBAgent 계층 분리는 게임 서버의 실시간 처리 경로에서 DB 지연/장애를 격리하기 위해 필요하다.
- Connection Pool은 연결 생성/종료 오버헤드를 제거하고, DB 사용량을 제어 가능한 자원으로 제한한다.
- Pool이 비는 순간 `Pop` 대기로 백프레셔를 걸어 과도한 요청 구간을 완충할 수 있다.
- Prepared Statement 패턴은 반복 쿼리 경로의 안정성과 실행 비용을 동시에 관리하기 유리하다.
- Inventory/QuickSlot/Trade는 다중 테이블/다중 행 갱신이므로 트랜잭션 경계 없이 정합성을 보장할 수 없다.
- `ROLLBACK TRAN` 수렴 경로를 명시해야 부분 성공 상태(half-commit)를 차단할 수 있다.
- `SQL_NO_DATA`를 정상 실행으로 처리해 UPDATE 0건 경로를 Upsert 전략과 자연스럽게 결합할 수 있다.
- 요청/쿼리/풀대기 메트릭을 함께 남기면 운영 구간에서 병목 원인 추적이 쉬워진다.

### 구현 요점
1. DBAgent는 `DBConnectionPool::Pop/Push`로 연결을 대여/반납하고, 풀 고갈 시에는 대기(`condition_variable`)로 수요를 완충한다.
2. 모든 SQL 경로는 `Prepare -> BindParam/BindCol -> Execute -> Unbind` 순서를 고정한다.
3. PlayerCore 저장은 단일 UPDATE로 처리하며, `SQL_NO_DATA`는 정상 실행(0 row)로 취급한다.
4. Inventory 저장은 `BEGIN TRAN` 후 Tombstone DELETE -> Snapshot UPDATE를 수행하고, 영향 행 0건이면 INSERT로 보완한 뒤 COMMIT/ROLLBACK 한다.
5. QuickSlot 저장은 `BEGIN TRAN` 후 기존 슬롯 전체 DELETE + 유효 슬롯만 INSERT로 재구성하고 COMMIT/ROLLBACK 한다.
6. QuickSlot 경로는 빈 슬롯(`QS_NONE`/`refId=0`)과 비정상 슬롯 인덱스를 DB 반영 전에 필터링한다.
7. Trade Commit은 양측 인벤토리 DELETE/UPSERT + 양측 골드 UPDATE를 단일 트랜잭션으로 묶어 원자성을 유지한다.
8. Trade 응답은 `success`와 함께 `failcode` 및 `tradeId/requestId/channel/map/instance`를 반환해 상위 복구 경로를 명확히 한다.

### 트랜잭션 정책 카드 (페이지 표)
| 작업 | 경계 | 실패 시 동작 | 성공 응답 |
| --- | --- | --- | --- |
| PlayerCore Save | 단일 UPDATE | `success=false` 반환 | `S2S_RES_SAVE_PLAYER_CORE` |
| Inventory Save | `BEGIN/COMMIT` | `ROLLBACK TRAN` | `S2S_RES_SAVE_INVENTORY` |
| QuickSlot Save | `BEGIN/COMMIT` | `ROLLBACK TRAN` | `S2S_RES_SAVE_QUICKSLOT` |
| Trade Commit | 단일 트랜잭션 | `ROLLBACK TRAN` + `TRADE_FAIL_INTERNAL` | `S2S_RES_TRADE_COMMIT(success/failcode + context ids)` |

### 응답 계약 (핵심)
| 응답 | 공통 필드 | 추가 필드 | 목적 |
| --- | --- | --- | --- |
| `S2S_RES_SAVE_PLAYER_CORE` | `playerId`, `success` | - | 코어 저장 성공/실패 판정 |
| `S2S_RES_SAVE_INVENTORY` | `playerId`, `success` | - | 인벤토리 저장 수렴 판정 |
| `S2S_RES_SAVE_QUICKSLOT` | `playerId`, `success` | - | 퀵슬롯 저장 수렴 판정 |
| `S2S_RES_TRADE_COMMIT` | `success`, `requestId` | `failcode`, `tradeId/channelId/mapId/instanceId` | 거래 실패 원인/컨텍스트 복원 |

### 운영 관측 포인트
- 패킷 타입별 요청 처리 시간 메트릭
- 쿼리 실행 시간(`ObserveQueryDuration`) 메트릭
- 풀 대기 시간/사용량(`ObservePoolWait`, `ObservePoolState`) 메트릭

### 32페이지 전용 배치
- 상단 가로: GameServer -> DBAgent -> SQL Server 책임 분리 다이어그램.
- 하단 좌측: Connection Pool/Prepared Statement 설명 카드.
- 하단 우측: Inventory/QuickSlot/Trade 트랜잭션 규칙 표.

### 삽입 다이어그램
```mermaid
flowchart LR
  A[GameServer S2S_REQ_SAVE_*] --> B[DBAgentPacketHandler]
  B --> C[DBConnectionPool Pop wait if empty]
  C --> D[Prepare Bind Execute]
  D --> E{Transaction?}
  E -->|No| F[Single Update Path]
  E -->|Yes| G[BEGIN and COMMIT or ROLLBACK]
  F --> H[Build S2S_RES]
  G --> H
  H --> I[Pool Push and Send Response]
```

### 증명 스니펫
- `DBAgent/DBConnectionPool.cpp:89`
- `DBAgent/DBConnectionPool.cpp:96`
- `DBAgent/DBConnectionPool.cpp:118`
- `DBAgent/DBConnection.cpp:56`
- `DBAgent/DBConnection.cpp:85`
- `DBAgent/DBConnection.cpp:68`
- `DBAgent/DBConnection.cpp:157`
- `DBAgent/DBAgentPacketHandler.cpp:443`
- `DBAgent/DBAgentPacketHandler.cpp:514`
- `DBAgent/DBAgentPacketHandler.cpp:573`
- `DBAgent/DBAgentPacketHandler.cpp:581`
- `DBAgent/DBAgentPacketHandler.cpp:603`
- `DBAgent/DBAgentPacketHandler.cpp:750`
- `DBAgent/DBAgentPacketHandler.cpp:773`
- `DBAgent/DBAgentPacketHandler.cpp:780`
- `DBAgent/DBAgentPacketHandler.cpp:805`
- `DBAgent/DBAgentPacketHandler.cpp:856`
- `DBAgent/DBAgentPacketHandler.cpp:849`
- `DBAgent/DBAgentPacketHandler.cpp:1025`
- `DBAgent/DBAgentPacketHandler.cpp:1029`

### 근거 코드
- `DBAgent/DBAgentPacketHandler.cpp`
- `DBAgent/DBConnectionPool.cpp`
- `DBAgent/DBConnection.cpp`
- `DBAgent/DBAgentMetrics.cpp`
- `DBAgent/DBAgent.cpp`

### 검증 기록 문장
- Inventory 저장 중 중간 쿼리 실패를 유도했을 때 `ROLLBACK TRAN`으로 수렴하는지 확인했다.
- Inventory UPDATE 영향 행 0건 케이스에서 INSERT 보완 경로로 정상 저장 수렴하는지 확인했다.
- QuickSlot 저장에서 비정상 슬롯 인덱스가 DB 저장 경로에서 필터링되는지 확인했다.
- Trade Commit 실패 시 양측 골드/아이템이 부분 반영되지 않는지 확인했다.
- Trade 실패 응답에서 `failcode`와 `requestId` 컨텍스트가 함께 전달되는지 확인했다.
- 부하 상황에서 Pool 대기 시간 메트릭이 기록되고 연결 누수가 발생하지 않는지 확인했다.

---

## Page 33. 부팅 데이터 동기화 (DB Template + JSON 월드 데이터)

### 페이지 핵심 메시지
- 서버 부팅 시점에 DB 템플릿 데이터와 로컬 JSON 월드 데이터를 분리 로드해, 전투 규칙과 맵 규칙을 동시에 초기화한다.

### 문제 정의
- 템플릿(Stat/Item/Skill)과 월드 설정(Map/Monster/Spawn/Drop)을 한 경로에 혼합하면 장애 원인 분리가 어렵다.
- 부팅 시 초기화 순서가 불명확하면 입장 시점의 검증 로직이 불완전한 상태로 동작할 수 있다.

### 이 기술을 선택한 이유
- DB 템플릿과 JSON 월드 데이터는 변경 주기와 관리 주체가 다르므로 로드 경로를 분리해야 운영이 단순해진다.
- 템플릿은 DB 기반으로 중앙 관리하고, 월드 지형/스폰은 파일 기반으로 버전 관리하는 편이 협업에 유리하다.
- 부팅 단계에서 두 데이터를 명시적으로 순차 로드하면 장애 시 원인 구간(DB/JSON)을 빠르게 특정할 수 있다.
- JSON 실패 시 fallback 경로를 유지해야 개발/테스트 환경에서 서버 하드다운을 줄일 수 있다.
- 입장 처리 전에 맵/템플릿이 모두 준비되어야 이동 검증/전투 계산의 기준 데이터가 흔들리지 않는다.
- 템플릿 캐시를 clear 후 재적재하는 스냅샷 방식이 부분 갱신 오염을 막고, 부팅 기준 데이터를 일관되게 고정한다.
- 부팅 데이터는 런타임에서 즉시 소비되어야 의미가 있으므로, 입장 시 맵 검증/스폰 좌표 계산 경로와 직접 연결되는 구조가 필요하다.

### 구현 요점
1. GameServer가 DBAgent 연결 직후 `S2S_REQ_LOAD_GAME_DATA`를 전송한다.
2. DBAgent는 `STAT_TEMPLATE`, `ITEM_TEMPLATE`, `SKILL_TEMPLATE`를 조회해 `S2S_RES_LOAD_GAME_DATA`로 반환한다.
3. GameServer는 응답 수신 후 `DataManager::LoadFromPacket`으로 템플릿 캐시를 구축한다.
4. 별도 경로로 `Maps.json`, `MonsterTemplates.json`, `SpawnTables.json`, `DropTables.json`을 로드한다.
5. JSON 실패 시 로그를 남기고 기본 레지스트리/보정 경로를 사용해 부팅 실패를 완화한다.
6. `LoadFromPacket`은 기존 `Stat/Item/Skill` 캐시를 먼저 비우고 재적재해 부팅 시점 기준 스냅샷을 고정한다.
7. JSON 로더는 데이터 정규화 규칙(중복 `spawnId` 제거, `maxAlive`/`respawnSec` 보정, 드랍 `min/max` 보정)을 적용해 잘못된 입력을 흡수한다.
8. 입장 경로는 `IsValidMapId`/`IsWorldMapId` 검증 후 기본 월드 맵으로 보정하고, 최종 스폰 좌표를 `MapConfig`에서 재계산한다.

### 초기화 순서 (페이지 타임라인)
1. 패킷 핸들러 초기화.
2. JSON 월드 데이터 로드(Map -> Monster -> Spawn -> Drop).
3. DB 세션 연결 성공 시 템플릿 로드 요청.
4. 템플릿 응답 수신 후 DataManager 메모리 적재.
5. 이후 클라이언트 입장 처리에서 맵/템플릿 검증 경로 활성화.

### 운영 Ready 판정 기준
- `MapConfigs/MonsterTemplates/SpawnTables/DropTables loaded` 로그가 모두 확인되는지 점검한다.
- `Load Complete. Stats/Items/Skills` 로그로 템플릿 캐시 적재 완료를 확인한다.
- 맵 설정 누락 시 `InitMapRegistry` + 기본 월드 맵 보정 경로가 활성화되는지 확인한다.

### 33페이지 전용 배치
- 상단: 부팅 시퀀스 타임라인(Init -> Load -> Ready).
- 좌측: DB 템플릿 로드 경로 카드.
- 우측: JSON 월드 데이터 로드 경로 카드.
- 하단: 실패 시 fallback 규칙 요약 박스.

### 삽입 다이어그램
```mermaid
flowchart TD
  A[GameServer Start] --> B[Load Maps.json]
  B --> C[Load Monster Spawn Drop JSON]
  C --> D[DBSession Connected]
  D --> E[S2S_REQ_LOAD_GAME_DATA]
  E --> F[DBAgent Query STAT ITEM SKILL]
  F --> G[S2S_RES_LOAD_GAME_DATA]
  G --> H[DataManager LoadFromPacket]
  H --> I[Runtime Ready]
```

### 증명 스니펫
- `GameServer/DBSession.cpp:14`
- `DBAgent/DBAgentPacketHandler.cpp:184`
- `DBAgent/DBAgentPacketHandler.cpp:207`
- `DBAgent/DBAgentPacketHandler.cpp:242`
- `DBAgent/DBAgentPacketHandler.cpp:292`
- `GameServer/S2SPacketHandler.cpp:87`
- `GameServer/S2SPacketHandler.cpp:92`
- `GameServer/DataManager.cpp:61`
- `GameServer/DataManager.cpp:140`
- `GameServer/DataManager.cpp:215`
- `GameServer/DataManager.cpp:272`
- `GameServer/DataManager.cpp:344`
- `GameServer/GameServer.cpp:192`
- `GameServer/GameServer.cpp:212`
- `GameServer/GameServer.cpp:227`
- `GameServer/GameServer.cpp:242`

### 근거 코드
- `GameServer/DBSession.cpp`
- `DBAgent/DBAgentPacketHandler.cpp`
- `GameServer/S2SPacketHandler.cpp`
- `GameServer/DataManager.cpp`
- `GameServer/GameServer.cpp`

### 검증 기록 문장
- 서버 부팅 로그에서 JSON 로드와 DB 템플릿 로드가 모두 완료된 후 런타임 진입하는지 확인했다.
- DB 템플릿 응답 실패 시 템플릿 캐시가 비정상 상태로 남지 않는지 확인했다.
- 맵 설정 파일 누락 시 fallback 로그와 기본 맵 레지스트리 경로가 동작하는지 확인했다.
- SpawnTables에서 중복 `spawnId`가 자동 제거되고, `maxAlive`/`respawnSec` 보정이 적용되는지 확인했다.
- 잘못된 입장 맵 ID 입력 시 기본 월드 맵과 기본 스폰 좌표로 안전하게 보정되는지 확인했다.

---

## Page 34. GameItem UID 시드 부트스트랩

### 페이지 핵심 메시지
- 아이템 UID는 서버 재시작과 무관하게 단조 증가해야 하므로, 부팅 시 DB의 최대 UID 다음 값을 시드로 받아 원자적으로 발급한다.
- DB 연결 직후 템플릿 로드와 UID 시드 요청을 함께 트리거해, 런타임 진입 전에 데이터 기준과 발급 기준을 동시에 고정한다.

### 문제 정의
- 재시작 후 UID 생성기가 초기값으로 되돌아가면 기존 아이템과 충돌해 인벤토리 정합성이 깨진다.
- 런타임마다 DB에 UID를 질의하면 성능이 급락하므로 메모리 상의 고속 발급기가 필요하다.

### 이 기술을 선택한 이유
- 아이템 UID는 전역 유일성이 필요하므로, 재시작 이후에도 마지막 발급 지점에서 연속성이 보장돼야 한다.
- 부팅 시 `MAX(game_item_uid)+1` 시드 확보는 충돌 없는 시작점을 가장 단순하게 보장하는 방식이다.
- 런타임 발급을 atomic `fetch_add`로 처리하면 DB 왕복 없이 고속/스레드 안전하게 UID를 생성할 수 있다.
- 테이블이 비어 있을 때 `999999 + 1` 기본값을 두면 초기 배포에서도 일관된 시작 정책을 유지할 수 있다.
- `next_uid == 0` 차단 조건은 잘못된 시드로 전체 발급 체계가 오염되는 상황을 방지한다.

### 구현 요점
1. DB 연결 직후 GameServer가 `S2S_REQ_GAME_ITEM_UID_SEED`를 전송한다.
2. DBAgent는 `SELECT ISNULL(MAX(game_item_uid), 999999) + 1`로 `next_uid`를 계산한다.
3. GameServer는 응답 성공 시 `GameItemUidGen::Init(next_uid)`로 시드를 초기화한다.
4. 런타임 아이템 생성은 `GameItemUidGen::Alloc()`의 atomic `fetch_add`로 락 없이 발급한다.
5. 시드 응답 실패 또는 0 값 수신 시 로그를 남기고 방어적으로 실패 경로를 유지한다.
6. 시드 초기화는 `store(release)`, 발급은 `fetch_add(relaxed)`, 관측은 `load(acquire)`로 설계해 비용 대비 동시성 안전성을 확보한다.

### 시드 응답 계약 (핵심)
| 응답 | 필드 | 성공 조건 | GameServer 동작 |
| --- | --- | --- | --- |
| `S2S_RES_GAME_ITEM_UID_SEED` | `success`, `next_uid` | `success=true` && `next_uid > 0` | `GameItemUidGen::Init(next_uid)` 수행 |
| `S2S_RES_GAME_ITEM_UID_SEED` | `success`, `next_uid` | 그 외 케이스 | 오류 로그 출력 + 초기화 생략(기존 발급기 상태 유지) |

### 운영 관측 포인트
- `S2S_REQ_GAME_ITEM_UID_SEED` 요청 처리 메트릭
- `Seed initialized. next_uid=...` 초기화 성공 로그
- `Seed load failed` 방어 경로 로그

### 34페이지 전용 배치
- 좌측: "충돌 위험 시나리오" 카드 (재시작 전/후 UID 비교).
- 우측 상단: 부트스트랩 쿼리 + 초기화 코드 스니펫.
- 우측 하단: 런타임 Alloc 원자성 설명 카드.
- 하단: 운영 검증 체크리스트(재시작/연속 생성/중복 탐지).

### 삽입 다이어그램
```mermaid
sequenceDiagram
  participant GS as GameServer
  participant DBA as DBAgent
  participant DB as SQL DB
  GS->>DBA: S2S_REQ_GAME_ITEM_UID_SEED
  DBA->>DB: SELECT ISNULL(MAX(game_item_uid),999999)+1
  DB-->>DBA: next_uid
  DBA-->>GS: S2S_RES_GAME_ITEM_UID_SEED(next_uid)
  GS->>GS: GameItemUidGen::Init(next_uid)
  GS->>GS: Alloc() = fetch_add(1)
```

### 증명 스니펫
- `GameServer/DBSession.cpp:14`
- `GameServer/DBSession.cpp:19`
- `DBAgent/DBAgentPacketHandler.cpp:625`
- `DBAgent/DBAgentPacketHandler.cpp:647`
- `DBAgent/DBAgentPacketHandler.cpp:654`
- `GameServer/S2SPacketHandler.cpp:165`
- `GameServer/S2SPacketHandler.cpp:172`
- `GameServer/GameItemUidGen.h:12`
- `GameServer/GameItemUidGen.h:14`
- `GameServer/GameItemUidGen.h:19`
- `GameServer/GameItemUidGen.h:27`
- `GameServer/GameItemUidGen.cpp:7`

### 근거 코드
- `GameServer/DBSession.cpp`
- `DBAgent/DBAgentPacketHandler.cpp`
- `GameServer/S2SPacketHandler.cpp`
- `GameServer/GameItemUidGen.h`
- `GameServer/GameItemUidGen.cpp`

### 검증 기록 문장
- 서버 재시작 전후로 `next_uid`가 역행하지 않는지 확인했다.
- 동시 아이템 생성 구간에서 UID 중복이 발생하지 않는지 확인했다.
- UID 시드 응답 실패 시 오류 로그가 즉시 출력되는지 확인했다.
- `ITEMS` 테이블이 비어 있는 초기 배포 상태에서 `next_uid=1000000`으로 시작하는지 확인했다.
- 시드 응답이 비정상(`success=false` 또는 `next_uid=0`)인 경우 `Init`이 수행되지 않고 방어 경로로 수렴하는지 확인했다.

---

## Section 4 마무리 문장 (섹션 마지막 박스)
- Section 4는 인증, 캐시, 트랜잭션, 부팅 동기화, UID 발급까지 데이터 정합성의 전체 수명주기를 닫는 설계다.
- 핵심은 "게임 로직과 영속화의 책임을 분리"하면서도, 실패 경로에서 데이터 손실과 상태 오염을 최소화한 점이다.
