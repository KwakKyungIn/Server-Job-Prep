## Section 6: 신뢰성 사례 & 마무리 (Page 36~37)

Section 6는 "기능이 많다"가 아니라 "문제가 생겨도 무너지지 않게 설계했고, 실제로 복구 가능한 구조를 갖췄다"를 증명하는 파트다.
Page 36은 방어 도구와 트러블슈팅 사례를 함께 묶어 기술 신뢰도를 보여주고, Page 37은 역량과 증거 링크를 심사자가 빠르게 추적할 수 있도록 정리한다.

---

## Page 36. 안정성 도구 + 트러블슈팅

### 페이지 핵심 메시지
- 이 프로젝트의 안정성은 추상적 주장보다 `탐지 도구 -> 차단 규칙 -> 재현 사례`로 설명된다.

### 이 페이지가 필요한 이유
- 제출 심사에서는 "잘 동작함"보다 "어떻게 실패를 조기에 감지하고 손실을 막았는가"가 핵심 평가 포인트다.
- 본 페이지는 개발 단계 도구(DeadLockProfiler/ASSERT_CRASH/StompAllocator)와 런타임 사례(투사체/거래)를 한 화면에서 연결해 신뢰성을 입증한다.

### 운영 안정화 도구 3종 (코드 강제 규칙)
| 도구 | 적용 위치 | 탐지/차단 대상 | 제출 문장 포인트 |
| --- | --- | --- | --- |
| DeadLockProfiler | Lock 획득/해제 경로 (`PushLock/PopLock`) | 락 순서 사이클, unlock 순서 위반 | "락 순서 그래프를 런타임으로 수집해 순환 즉시 감지" |
| ASSERT_CRASH | 세션/송신/리스너 등 핵심 경계 | 불가능해야 할 상태(invariant 위반) | "잘못된 상태를 조용히 무시하지 않고 즉시 실패로 표면화" |
| StompAllocator | `_STOMP` 디버그 경로 | 메모리 오버런/언더런 | "메모리 손상을 초기 단계에서 재현 가능하게 고정" |

### 도구 A. DeadLockProfiler
- `Lock::WriteLock/ReadLock` 진입 시 `GDeadLockProfiler->PushLock`, 해제 시 `PopLock`을 호출한다.
- `PushLock`은 `prev -> curr` 락 순서를 그래프에 기록하고, 새 에지가 생길 때마다 `CheckCycle`을 수행한다.
- DFS 중 back-edge가 발견되면 즉시 `CRASH("DEADLOCK_DETECTED")`로 중단해 교착을 조기 노출한다.

### 도구 B. ASSERT_CRASH
- `ASSERT_CRASH`는 조건 위반 시 즉시 crash를 유발해 상태 오염을 조용히 누적하지 않는다.
- 리스너 디스패치 타입 검증, 세션 집합 정리, 송신 버퍼 경계 체크 등 핵심 경로에서 일관되게 사용한다.
- 제출 문서에서는 "실패 은폐가 아니라 Fail-Fast 정책"으로 표현한다.

### 도구 C. StompAllocator
- `_STOMP` 활성화 시 `Memory/ObjectPool`이 일반 풀 경로 대신 `StompAllocator` 경로를 사용한다.
- `VirtualAlloc` 페이지 기반 할당/해제로 메모리 경계 침범을 조기에 드러낸다.
- 기본 릴리스 경로와 분리되어 있어 성능과 진단을 상황별로 선택할 수 있다.

### 트러블슈팅 사례 1. 투사체 중복 히트
#### 문제 상황
- 고속 투사체/다중 대상 교전에서 동일 투사체가 같은 대상에 중복 데미지를 주는 위험이 있었다.

#### 원인 분석
- 투사체는 틱 기반으로 연속 충돌 판정을 수행하므로, "이미 맞은 대상"을 런타임 상태로 유지하지 않으면 중복 타격이 발생할 수 있다.
- 풀링 재사용 시 피격 기록 초기화가 누락되면 이전 생애의 피격 정보가 잔존해 오판정이 발생할 수 있다.

#### 해결 방식
- `Projectile`에 `_hitVictims` 집합을 두고 `HasAlreadyHit`로 선검증한다.
- 실제 데미지 적용 직후 `MarkHit`를 호출해 동일 대상 재타격을 차단한다.
- `Projectile::Init`에서 `ResetHitState`를 호출해 재사용 시 상태를 초기화한다.

#### 결과 문장 (복붙용)
- `투사체 피격 대상은 서버 런타임 집합으로 관리하여 동일 대상 중복 히트를 구조적으로 차단했다.`

### 트러블슈팅 사례 2. 거래 중 아이템 중복/불일치
#### 문제 상황
- 거래 진행 중 인벤토리 조작(사용/장착/드래그)이 허용되면, 거래 오퍼 스냅샷과 실제 인벤 상태가 달라질 수 있다.

#### 원인 분석
- 거래는 `Active -> Locked -> Committing` 상태머신으로 진행되는데, 인벤토리 조작이 병행되면 커밋 계획과 실제 상태가 어긋난다.
- Disconnect/MapChange 중 거래가 정리되지 않으면 세션 단절 시점에 상태 불일치가 커질 수 있다.

#### 해결 방식
- 인벤 관련 핸들러(`UseItem`, `Equip`, `InvDragDrop`)에서 `ActiveTradeId != 0`이면 즉시 차단한다.
- 거래는 `Locked` 이후 수정 불가, `Committing` 중 외부 취소 불가로 상태 전이를 고정한다.
- Disconnect/MapChange 시 `CancelTrade_ActorOnly`로 단일 정리 경로를 강제한다.
- 최종 커밋은 DBAgent에서 단일 SQL 트랜잭션(`BEGIN/COMMIT/ROLLBACK`)으로 처리해 원자성을 보장한다.

#### 결과 문장 (복붙용)
- `거래 중 인벤토리 조작을 상태머신 경계에서 차단하고, DB 커밋을 단일 트랜잭션으로 묶어 아이템 중복/유실 위험을 낮췄다.`

### 36페이지 전용 배치
- 상단 전체: `문제는 발생한다. 중요한 것은 감지와 수렴 속도다.` 메시지 배너.
- 좌측 40%: 안정성 도구 3종 카드(DeadLockProfiler/ASSERT_CRASH/StompAllocator).
- 우측 60% 상단: 사례 1(투사체 중복 히트) 카드.
- 우측 60% 하단: 사례 2(거래 중 인벤 조작) 카드.
- 하단 가로: `원인 -> 차단 규칙 -> 검증 결과` 3열 표.

### 시각 스타일 가이드
- 도구 카드 색상: `남색 계열`, 사례 카드 색상: `주황/적갈 계열`로 분리해 "예방"과 "대응"을 구분한다.
- 강조 키워드(`Fail-Fast`, `State Lock`, `Txn Commit`)만 굵게 처리하고, 본문은 단문 중심으로 유지한다.
- 코드 스니펫은 각 사례 1개씩만 크게 배치하고 나머지는 하단 `증명 스니펫` 목록으로 정리한다.
- 아이콘은 `shield`, `alert`, `wrench` 3종으로 제한해 시각 밀도를 조절한다.

### 삽입 다이어그램
```mermaid
flowchart LR
  A[Stability Tooling] --> B[DeadLockProfiler]
  A --> C[ASSERT_CRASH]
  A --> D[StompAllocator]
  B --> E[Detect Lock Cycle]
  C --> F[Fail Fast on Invariant Break]
  D --> G[Detect Memory Boundary Fault]
  E --> H[Troubleshooting Cases]
  F --> H
  G --> H
  H --> I[Projectile Duplicate-Hit Block]
  H --> J[Trade Inventory Mutation Block]
  I --> K[Reliability Evidence]
  J --> K
```

### 증명 스니펫
- `ServerCore/Lock.cpp:10`
- `ServerCore/Lock.cpp:51`
- `ServerCore/Lock.cpp:69`
- `ServerCore/Lock.cpp:103`
- `ServerCore/DeadLockProfiler.cpp:47`
- `ServerCore/DeadLockProfiler.cpp:79`
- `ServerCore/DeadLockProfiler.cpp:154`
- `ServerCore/CoreMacro.h:33`
- `ServerCore/Listener.cpp:65`
- `ServerCore/Service.cpp:74`
- `ServerCore/SendBuffer.cpp:28`
- `ServerCore/Allocator.cpp:27`
- `ServerCore/Memory.cpp:67`
- `ServerCore/ObjectPool.h:16`
- `ServerCore/Types.h:47`
- `GameServer/Projectile.h:53`
- `GameServer/Projectile.cpp:46`
- `GameServer/GameRoom.Projectile.cpp:403`
- `GameServer/GameRoom.Projectile.cpp:475`
- `GameServer/GameRoom.Items.cpp:255`
- `GameServer/GameRoom.Items.cpp:407`
- `GameServer/GameRoom.Items.cpp:542`
- `GameServer/GameRoom.h:299`
- `GameServer/GameRoom.h:305`
- `GameServer/GameRoom.Trade.cpp:489`
- `GameServer/GameRoom.Trade.cpp:572`
- `GameServer/GameRoom.EnterLeave.cpp:167`
- `GameServer/GameRoom.MapChange.cpp:53`
- `DBAgent/DBAgentPacketHandler.cpp:856`
- `DBAgent/DBAgentPacketHandler.cpp:1025`

### 근거 코드
- `ServerCore/DeadLockProfiler.cpp`
- `ServerCore/Lock.cpp`
- `ServerCore/CoreMacro.h`
- `ServerCore/Allocator.cpp`
- `ServerCore/Memory.cpp`
- `ServerCore/ObjectPool.h`
- `GameServer/Projectile.h`
- `GameServer/Projectile.cpp`
- `GameServer/GameRoom.Projectile.cpp`
- `GameServer/GameRoom.Items.cpp`
- `GameServer/GameRoom.Trade.cpp`
- `GameServer/GameRoom.EnterLeave.cpp`
- `GameServer/GameRoom.MapChange.cpp`
- `DBAgent/DBAgentPacketHandler.cpp`

### 검증 기록 문장
- 동일 투사체가 동일 대상을 연속 틱에서 다시 타격하지 않는지 `_hitVictims` 경로로 확인했다.
- 거래 중 아이템 사용/장착/드래그 입력이 서버에서 즉시 차단되는지 패킷 재생으로 확인했다.
- 거래 커밋 실패 시 DB 트랜잭션이 `ROLLBACK`으로 수렴하고, 성공 시에만 메모리 반영이 진행되는지 확인했다.

---

## Page 37. 역량 요약 & 참고 링크

### 페이지 핵심 메시지
- 본 프로젝트는 "기능 구현"을 넘어 "정합성, 신뢰성, 운영 검증"까지 닫힌 형태로 완성됐다.

### 상단 카피 (복붙용)
- 제목: `Section 6. 마무리: 신뢰성 중심 서버 개발 역량`
- 서브카피: `서버 권위 설계부터 운영 검증까지, 구현과 근거를 함께 제시`
- 한 줄 결론: `핵심 기능 구현, 실패 대응 설계, 운영 관측 체계를 하나의 서버 제품 관점으로 연결했다.`

### 핵심 역량 요약 (제출 문장)
1. `서버 권위/정합성 중심 설계`: 이동·전투·거래 결과를 서버 상태 전이로 확정한다.
2. `동시성/실패 경계 제어`: IOCP + Actor/JobQueue + Fail-Fast 규칙으로 경합과 오류 전파를 제어한다.
3. `데이터 영속화 완결성`: Redis Write-Back과 DBAgent 트랜잭션으로 저장 경로를 분리하고 수렴시킨다.
4. `운영 가능성 증명`: Prometheus/Grafana 계측과 DummyClient 부하 보고로 재현 가능한 근거를 제시한다.

### 역량-증거 매핑 표
| 역량 | 구현 근거 | 검증/관측 근거 | 연결 섹션 |
| --- | --- | --- | --- |
| 서버 권위 판정 | 이동/전투/거래 서버 커밋 경로 | 좌표 보정/중복 타격 차단 로그 | Section 2, 3 |
| 동시성 제어 | Actor + JobQueue + IOCP 분리 | 큐 처리/세션 수명 분기 점검 | Section 3 |
| 데이터 정합성 | Redis Dirty + DBAgent Txn | Commit/Retry/Rollback 수렴 확인 | Section 4 |
| 운영 검증 | `/metrics`, 대시보드, 부하 시나리오 | p95/throughput/failure 비교표 | Section 5 |

### 참고 링크 구성 (제출 형식)
- GitHub 저장소: 실제 제출 저장소 URL 1개만 기재.
- 대표 문서 링크:
  - 아키텍처 개요 문서
  - 데이터 정합성/영속화 문서
  - 모니터링 대시보드 문서
  - 부하 테스트 보고서
- 선택 보조 자료:
  - 1~2분 내외 동작 영상(로그인 -> 입장 -> 전투 -> 거래 -> 저장 확인)

### 37페이지 전용 배치
- 상단 25%: 제목/서브카피/한 줄 결론.
- 중단 45% 좌측: 핵심 역량 4개 카드.
- 중단 45% 우측: 역량-증거 매핑 표.
- 하단 30%: 참고 링크 + "읽는 순서 가이드"(아키텍처 -> 기능 -> 정합성 -> 운영 검증).

### 시각 스타일 가이드
- 역량 카드는 `청색 계열` 4단 톤으로 통일해 안정감을 준다.
- 링크 영역은 `회색 배경 + 단색 아이콘`으로 처리해 본문과 시각적 위계를 분리한다.
- 문장 길이는 카드당 2줄 이내로 제한해 마지막 페이지 가독성을 높인다.
- "핵심 결론"은 문장 하나만 크게 배치하고, 과장 표현은 사용하지 않는다.

### 삽입 다이어그램
```mermaid
flowchart LR
  A[Server Authority] --> B[Concurrency Control]
  B --> C[Data Integrity]
  C --> D[Observability and Load Validation]
  D --> E[Production-Ready Portfolio Evidence]
```

### 제출용 문장 톤 가이드
- 구어체 대신 사실형 문장 사용: `~했다`, `~를 확인했다`.
- 과장형 표현 금지: `완벽`, `압도적`, `무조건` 같은 단어는 제거한다.
- 주장 뒤에는 반드시 근거 경로를 연결한다: 기능명 단독 서술 금지.
- "내가 무엇을 설계했고 어떤 위험을 줄였는지"를 한 문장에 함께 담는다.

### 최종 체크리스트 (페이지 제출 전)
- 코드 근거 경로가 모든 주장에 대응되는지 확인
- 링크가 실제 접근 가능한지 확인 (사내 경로/로컬 경로 제외)
- 비교표에 단위(ms, %, count)가 명시되어 있는지 확인
- 섹션 간 용어가 일치하는지 확인 (예: TradeState, Dirty, Commit)

### 근거 문서 자산
- `docs/portfolio/section2/portfolio_outline_section2.md`
- `docs/portfolio/section3/portfolio_outline_section3.md`
- `docs/portfolio/section4/portfolio_outline_section4.md`
- `docs/portfolio/section5/portfolio_outline_section5.md`
- `docs/portfolio/Portfolio_FeatureList.md`
- `docs/portfolio/Portfolio_Techniques.md`

### Section 6 마무리 문장 (섹션 마지막 박스)
- `이 포트폴리오는 기능 시연을 넘어, 실패를 감지하고 수렴시키는 서버 설계 역량을 코드와 지표로 함께 제시한다.`
