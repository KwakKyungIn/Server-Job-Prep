## Section 3: 서버 엔진 설계 (Page 22~29)

Section 3는 기능 목록이 아니라, 서버가 실제 운영 조건에서 무너지지 않게 만든 실행 구조를 설명하는 파트다.
Page 22~29는 서로 다른 기술 질문을 다루며, 페이지마다 전개 방식과 배치를 다르게 잡는다.

---

## Page 22. Actor + JobQueue 직렬화 모델

### 먼저 보여줄 한 문장
- 동시 입력을 "잠금 확장"으로 버티지 않고, 상태 변경 경로를 Actor 큐로 고정해 정합성을 유지했다.

### 경합이 실제로 생기는 지점
- 한 플레이어에서 이동, 스킬, 거래, 맵 전이 요청이 근접한 시점에 도착한다.
- 처리 순서가 흔들리면 좌표/HP/인벤토리가 서로 다른 타이밍의 값으로 커밋된다.

### 내가 선택한 구조
- `Session Actor`, `LobbyRoom Actor`, `GameRoom Actor`를 분리하고, 상태 커밋은 각 Actor의 JobQueue 내부 실행으로 제한했다.
- 패킷 수신 스레드는 상태를 직접 수정하지 않고 `Post`, `PostRoom`, `PushJob`으로 위임만 수행한다.

### 코드 흐름(입력 1건이 커밋되기까지)
1. `ClientPacketHandler::Handle_C_MOVE`가 요청 수신
2. `PlayerSession::PostRoom`으로 룸 Actor 위임
3. `GameRoom::HandleMoveById -> HandleMove` 실행
4. `JobQueue::Push` 적재 후 `JobQueue::Execute` 순차 처리
5. 룸 Actor 내부에서 상태 확정

### 22페이지 전용 배치
- 왼쪽: 경합 사례 3개와 직렬화 적용 후 결과 비교표
- 오른쪽 위: 호출 흐름 다이어그램
- 오른쪽 아래: 위임 경로 스니펫

### 삽입 다이어그램
```mermaid
flowchart LR
  A[Client Packet] --> B[ClientPacketHandler]
  B --> C[PlayerSession::PostRoom]
  C --> D[RoomActor::Push]
  D --> E[JobQueue::Push]
  E --> F[GlobalQueue]
  F --> G[DoGlobalQueueWork]
  G --> H[JobQueue::Execute]
  H --> I[GameRoom::Handle* Commit]
```

### 증명 스니펫
- `GameServer/ClientPacketHandler.GamePlay.cpp:8`
- `GameServer/PlayerSession.h:139`

### 근거 코드
- `GameServer/ClientPacketHandler.GamePlay.cpp`
- `GameServer/PlayerSession.h`
- `GameServer/GameRoom.Move.cpp`
- `ServerCore/JobQueue.cpp`
- `ServerCore/GlobalQueue.cpp`

### 검증 기록 문장
- 연속 이동 입력에서 `seq` 처리 순서와 상태 커밋 순서가 동일하게 유지됨을 로그로 확인했다.
- 세션 종료와 룸 작업이 겹친 상황에서도 `LeaveById` 단일 경로로 정리됨을 확인했다.

---

## Page 23. Hybrid 스레드 모델

### 관찰된 병목 현상으로 시작
- 단일 루프 구조에서는 I/O burst 발생 시 패킷 소비 지연이 로직 실행 지연으로 바로 전파됐다.

### 스레드 분할 기준(실제 적용 수식)
- `threadCount = std::thread::hardware_concurrency()`로 시작하고, 2 미만이면 2로 보정한다.
- `networkThreadCount = threadCount / 2`
- `logicThreadCount = threadCount - networkThreadCount`
- 서버 시작 시 위 수식으로 lane별 스레드를 생성한다.

### 분리한 실행면(Execution Lanes)
- Network Lane: `while (GIsRunning) core->Dispatch(10)` 루프로 IOCP 완료 통지를 소비
- Logic Lane: `DoGlobalQueueWork`에서 GlobalQueue를 `Pop`하고 `JobQueue::Execute` 실행
- Main Tick Lane: 메인 루프에서 50ms 주기로 `RoomManager::UpdateAll` 호출

### 이렇게 나눈 이유
- 지연 원인을 I/O 문제와 로직 문제로 분해해야 운영 중 병목 위치를 정확히 판단할 수 있다.
- 코어 수 기반 `networkThreadCount`/`logicThreadCount` 분할로 머신별 튜닝 지점을 확보했다.

### Lane 실행 계약
- Network Lane은 완료 통지 소비/패킷 라우팅만 수행하고, 게임 상태를 직접 커밋하지 않는다.
- Logic Lane은 Actor JobQueue 실행을 통해 상태 커밋을 처리한다.
- Main Tick Lane은 `room->Update()`를 직접 호출하지 않고 `room->Push(...)`로 Job을 적재한다.

### Logic Lane 스케줄링 구조
- GlobalQueue는 32개 shard로 분할된다.
- 각 worker는 `LThreadId % shardCount`로 자신의 우선 shard에서 먼저 `Pop`한다.
- 우선 shard가 비어 있으면 다른 shard를 순회하며 steal을 시도한다.
- 이 방식으로 특정 shard 편중 시에도 로직 worker 유휴 시간을 줄이도록 구성했다.

### 런타임에서 실제 돌아가는 순서
- 서버 시작 시 스레드 수 계산 및 lane별 스레드 생성
- 네트워크 스레드: `Dispatch(10)` 반복
- 로직 스레드: 글로벌 큐에서 작업 `Pop/Execute`, 필요 시 다른 shard steal
- 메인 루프: 50ms 주기로 `UpdateAll` 실행 후 각 룸에 `room->Push([room]{ room->Update(); })` 적재
- IOCP 이벤트 내부 전달/분기 규칙은 Page 25에서 상세히 기술

### 23페이지 전용 배치
- 상단 가로 전체: 3-Lane 관계 다이어그램
- 하단 왼쪽: 분리 전/후 병목 비교 카드
- 하단 오른쪽: 스레드 분할 수식 + GlobalQueue shard/steal 규칙

### 삽입 다이어그램
```mermaid
flowchart LR
  A[Network Lane: Dispatch(10)] --> B[Packet Routing]
  B --> C[GlobalQueue Shards x32]
  E[Main Tick 50ms: UpdateAll] --> F[room->Push(Update)]
  F --> C
  C --> D[Logic Lane: Pop Execute]
  H[Local Shard Miss] --> I[Steal Other Shard]
  I --> D
```

### 증명 스니펫
- `GameServer/GameServer.cpp:340`
- `GameServer/GameServer.cpp:349`
- `GameServer/GameServer.cpp:356`
- `GameServer/GameServer.cpp:372`
- `GameServer/GameServer.cpp:375`
- `ServerCore/GlobalQueue.cpp:114`
- `ServerCore/GlobalQueue.cpp:141`
- `GameServer/RoomManager.cpp:95`
- `GameServer/RoomManager.cpp:111`

### 근거 코드
- `GameServer/GameServer.cpp`
- `ServerCore/ThreadManager.cpp`
- `ServerCore/GlobalQueue.cpp`
- `GameServer/RoomManager.cpp`

### 검증 기록 문장
- 네트워크 burst 구간에서도 Main Tick이 50ms 주기로 `UpdateAll`을 적재하는지 로그로 확인했다.
- 로직 스레드가 우선 shard miss 시 steal 경로로 넘어가 작업을 이어받는 흐름을 확인했다.

---

## Page 24. 패킷 신뢰 경로 (수신 검증 + 송신 봉인)

### 페이지 핵심 메시지
- 패킷 처리 품질은 개별 핸들러 코드가 아니라, 공통 검증 경로의 강제 여부로 결정된다.

### 프레이밍 단계: TCP 스트림에서 패킷 경계 확정
- `PacketSession::OnRecv`가 `header.size` 기준으로 완성 패킷만 분리한다.
- 헤더만 도착했거나 본문이 덜 온 경우는 즉시 처리하지 않고 다음 수신까지 누적 대기한다.
- 경계가 확정된 패킷만 `OnRecvPacket`으로 넘겨 검증/디스패치 단계에 진입시킨다.

### 허용 목록 기반 디스패치
- `Init()`에서 `GPacketHandler` 전체를 `Handle_INVALID`로 초기화한다.
- 실제로 처리할 패킷 ID만 명시적으로 바인딩해 허용 목록(whitelist) 방식으로 운용한다.
- `header->id`로 테이블을 조회하므로, 미등록 ID는 기본 차단 경로(`Handle_INVALID`)로 빠진다.

### RX 파트: 들어오는 패킷을 어떻게 걸러내는가
- `HandlePacket<T>`에서 CRC -> Seq -> XOR -> Parse 순서를 고정한다.
- 어느 단계든 실패하면 핸들러 진입 없이 즉시 종료한다.

### TX 파트: 나가는 패킷을 어떻게 완성하는가
- `MakeSendBuffer`에서 payload 직렬화/XOR 수행
- `Session::Send`에서 `seq/crc` 최종 작성 후 전송

### 설계 선택 이유
- 검증을 핸들러마다 흩어 놓으면 신규 패킷 추가 시 단계 누락이 발생한다.
- 공통 템플릿 기반 경로를 사용하면 패킷 타입이 늘어나도 동일한 검증 정책을 유지할 수 있다.
- PacketGenerator를 적용해 핸들러 테이블 생성 누락 위험을 줄였다.

### 삽입 다이어그램
```mermaid
flowchart LR
  A[PacketSession::OnRecv] --> B[header.size 기반 프레이밍]
  B --> C[OnRecvPacket]
  C --> D[Dispatch Table by header.id]
  D --> E[HandlePacket<T>]
  E --> F[CRC Check]
  F --> G[Seq Check]
  G --> H[XOR Decrypt]
  H --> I[Parse]
  I --> J[Handle_C_* / Handle_S2S_*]
  J --> K[MakeSendBuffer]
  K --> L[Session::Send seq/crc]
```

### 24페이지 전용 배치
- 좌측 상단: 프레이밍 + 허용 목록 디스패치
- 좌측 하단: RX/TX 검증/봉인 경로
- 우측 상단: 검증 실패 지점별 차단 규칙 표
- 우측 하단: `HandlePacket<T>` 스니펫

### 증명 스니펫
- `ServerCore/Session.cpp:508`
- `ServerCore/Session.cpp:523`
- `ServerCore/Session.cpp:527`
- `GameServer/ClientPacketHandler.h:84`
- `GameServer/ClientPacketHandler.h:119`
- `GameServer/ClientPacketHandler.h:202`
- `GameServer/ClientPacketHandler.h:213`
- `GameServer/ClientPacketHandler.h:221`
- `GameServer/S2SPacketHandler.h:79`
- `GameServer/S2SPacketHandler.h:96`

### 근거 코드
- `GameServer/ClientPacketHandler.h`
- `GameServer/S2SPacketHandler.h`
- `ServerCore/Session.cpp`
- `Tools/PacketGenerator/Templates/PacketHandler.h`
- `Tools/PacketGenerator/PacketGenerator.py`

### 검증 기록 문장
- 분할 수신(헤더만 먼저 도착, 본문 지연) 상황에서 `header.size` 기준으로 완성 패킷만 핸들러로 전달되는지 확인했다.
- 미등록 패킷 ID 입력 시 `Handle_INVALID` 경로로 빠져 실제 처리 핸들러가 호출되지 않는지 확인했다.
- CRC 불일치/역순 seq 입력이 핸들러 미진입으로 차단되는지 확인했다.
- 신규 패킷 추가 시 생성기 결과와 실제 핸들러 테이블 반영이 일치하는지 점검했다.

---

## Page 25. IOCP 완료 통지 파이프라인

### 페이지 핵심 질문
- 완료 이벤트가 성공/실패 상황에서 어떤 경로로 분기되고, 객체 수명과 재등록 루프를 어떻게 안정적으로 유지하는가?

### 1) Accept 선등록 + 종료 가드
- `Listener::StartAccept`는 `GetMaxSessionCount()`만큼 AcceptEvent를 생성해 `RegisterAccept`를 선등록한다.
- `ProcessAccept`는 `SetUpdateAcceptSocket`과 `getpeername`을 통과한 세션에 `session->SetNetAddress`를 적용한 뒤 `session->ProcessConnect`를 호출한다.
- `session->ProcessConnect`는 `AddSession -> OnConnected -> RegisterRecv` 순으로 세션 활성화를 완료한다.
- `SetUpdateAcceptSocket` 또는 `getpeername` 실패 시에도 즉시 `RegisterAccept`로 되돌아가 Accept 파이프를 비우지 않는다.
- 정상 경로에서도 `session->ProcessConnect` 이후 즉시 `RegisterAccept`를 다시 호출해 Accept 파이프를 유지한다.
- 서버 종료 시 `CloseAccept`가 `_socket`을 `INVALID_SOCKET`으로 바꾸고, `RegisterAccept`가 조기 return 하도록 만들어 종료 중 재등록 루프를 차단한다.

### 2) GQCS 디스패치의 성공/실패 분기
- `IocpCore::Dispatch`는 `GetQueuedCompletionStatus` 성공 시 `iocpEvent->owner->Dispatch(iocpEvent, numOfBytes)`로 바로 전달한다.
- `WAIT_TIMEOUT`은 이벤트 미수신으로 처리하고 `false`를 반환해 루프가 다음 tick으로 넘어가게 한다.
- timeout 외 오류에서는 OVERLAPPED가 유효한 경우 동일하게 `owner->Dispatch`를 호출해 객체별 오류 정리 경로를 타게 한다.

### 3) 이벤트 객체 수명 규칙 (`owner` reference)
- `RegisterRecv/RegisterSend/RegisterDisconnect/RegisterConnect`에서 `event.owner = shared_from_this()`로 참조를 잡아 비동기 완료 시점까지 객체 생존을 보장한다.
- `ProcessRecv/ProcessSend/ProcessDisconnect/ProcessConnect` 진입 시 `event.owner = nullptr`로 참조를 해제해 수명을 정리한다.
- 이 규칙으로 완료 통지 지연 구간에서도 use-after-free 위험을 줄였다.

### 4) Recv 완료 처리 파이프라인
- `ProcessRecv`는 `numOfBytes == 0`이면 즉시 `Disconnect`로 수렴한다.
- 정상 수신은 `RecvBuffer::OnWrite -> OnRecv -> OnRead -> Clean` 순으로 처리한다.
- `OnWrite/OnRead` 검증 실패 시에도 `Disconnect` 경로로 수렴시켜 버퍼 비정상 상태를 남기지 않는다.
- 처리 후 `RegisterRecv`를 다시 호출해 수신 루프를 유지한다.

### 5) Send 완료 처리 파이프라인
- `Send`는 `_sendRegistered.exchange(true)` 게이트를 사용해 동시에 1개의 `WSASend`만 in-flight 상태가 되도록 제한한다.
- `RegisterSend`는 송신 큐를 배치로 묶어 `WSASend`(scatter-gather)로 등록한다.
- `WSASend` 등록이 `WSA_IO_PENDING` 외 오류로 실패하면 `_sendRegistered=false`로 복구해 다음 등록이 가능하도록 만든다.
- `ProcessSend`는 완료 후 send buffer 참조를 해제하고, 큐 잔량이 있으면 `RegisterSend`를 재호출한다.
- 큐가 비면 `_sendRegistered=false`로 내려 다음 송신 등록이 가능해지고, `Send 0`/소켓 오류는 `Disconnect` 또는 `HandleError`로 수렴한다.

### 6) Disconnect 완료 경로 + 중복 차단
- `Session::Disconnect`는 `_connected.exchange(false)`로 중복 호출을 차단한다.
- 차단을 통과한 1회 호출만 `RegisterDisconnect`를 등록해 IOCP 완료 이벤트를 발생시킨다.
- `ProcessDisconnect`에서 `OnDisconnected -> ReleaseSession` 순으로 마무리해 세션 정리 경로를 단일화한다.

### 삽입 다이어그램
```mermaid
flowchart LR
  A[StartAccept pre-post N] --> B[Accept Complete]
  B --> C[Listener::ProcessAccept]
  C --> D[ProcessConnect: AddSession -> OnConnected -> RegisterRecv]
  C --> E[RegisterAccept again]
  F[GQCS] --> G{Dispatch result}
  G -->|success| H[owner->Dispatch(eventType)]
  G -->|WAIT_TIMEOUT| I[return false]
  G -->|error with overlapped| H
  H --> J[ProcessRecv]
  J --> K[OnWrite -> OnRecv -> OnRead/Clean]
  K --> L[RegisterRecv]
  H --> M[ProcessSend]
  M --> N{send queue remain}
  N -->|yes| O[RegisterSend]
  N -->|no| P[_sendRegistered false]
  J -->|Recv 0 / overflow| Q[Disconnect]
  M -->|Send 0 / socket error| Q
  Q --> R[RegisterDisconnect]
  R --> S[ProcessDisconnect]
  S --> T[OnDisconnected -> ReleaseSession]
```

### 25페이지 전용 배치
- 좌측 상단: Accept 선등록/재등록 + 종료 가드
- 좌측 하단: GQCS 성공/실패 분기
- 우측 상단: `owner` 참조 획득/해제 수명 규칙
- 우측 하단: Recv/Send/Disconnect 완료 수렴 루프

### 증명 스니펫
- `ServerCore/IocpCore.cpp:39`
- `ServerCore/IocpCore.cpp:51`
- `ServerCore/IocpCore.cpp:58`
- `ServerCore/Listener.cpp:49`
- `ServerCore/Listener.cpp:75`
- `ServerCore/Listener.cpp:108`
- `ServerCore/Listener.cpp:116`
- `ServerCore/Session.cpp:151`
- `ServerCore/Session.cpp:274`
- `ServerCore/Session.cpp:356`
- `ServerCore/Session.cpp:375`
- `ServerCore/Session.cpp:381`
- `ServerCore/Session.cpp:404`
- `ServerCore/Session.cpp:443`
- `ServerCore/Session.cpp:469`
- `ServerCore/Session.cpp:172`
- `ServerCore/Session.cpp:247`
- `ServerCore/Session.cpp:388`

### 근거 코드
- `ServerCore/IocpCore.h`
- `ServerCore/IocpCore.cpp`
- `ServerCore/IocpEvent.h`
- `ServerCore/Listener.cpp`
- `ServerCore/Session.cpp`
- `ServerCore/RecvBuffer.cpp`

### 검증 기록 문장
- 접속 burst와 종료 시나리오를 교차 실행해 `CloseAccept` 이후 Accept 재등록이 반복되지 않는지 확인했다.
- 반쪽/다중 패킷 수신 및 연속 송신 상황에서 Recv/Send 재등록 루프가 끊기지 않는지 확인했다.

---

## Page 26. 로비 게이트: 입장 합류 조건 설계

### 페이지 질문
- 로그인 직후 즉시 월드 입장을 막고, 왜 로비에서 합류 조건을 기다리도록 만들었는가?

### 로비를 별도로 둔 설계 이유
- **비동기 로딩 장벽**: 스탯/인벤/퀵슬롯이 모두 준비되기 전에는 월드에 진입시키지 않기 위해, 로비를 “준비 완료 판정 지점”으로 분리했다.
- **소유권 버퍼**: 플레이어 객체를 로비가 먼저 소유하고, 월드 이관 실패 시 다시 `Adopt`로 복구할 수 있게 만들어 전이 중 유실을 막았다.
- **컨텍스트 강제 지점**: S2S 응답은 네트워크 스레드에서 직접 처리하지 않고 로비 Actor 큐로 모아, 로딩 완료 플래그와 진입 판정을 단일 실행면에서 처리했다.
- **전이 브릿지 재사용**: 맵 전이 체인에서도 `GameRoom -> Lobby -> NewRoom` 순서를 사용해, 로그인 입장과 맵 전이를 같은 중간 완충 구조로 통일했다.
- **채널 단위 격리**: `GetOrCreateLobby(channelId)` 구조로 채널별 대기 공간을 분리해, 잘못된 채널 라우팅이 월드 입장으로 직결되지 않게 했다.

### 입장 요청 시작점
- `Handle_C_ENTER_GAME`에서 토큰 유효성을 검증하고, 플레이어를 세션에 바인딩한다.
- 같은 경로에서 `PendingEnter(channel/map)`를 기록해 비동기 DB 응답의 라우팅 키로 사용한다.
- 이후 `LOAD_PLAYER_DATA`, `ITEMS_LOAD`, `QUICKSLOT_LOAD`를 병렬 요청한다.

### 입장 컨텍스트 정규화/복귀 정책
- `channelId <= 0` 요청은 기본 채널로 보정해 라우팅 키를 고정한다.
- 월드 외 맵/잘못된 맵 ID는 기본 월드맵으로 교정하고, 스폰 좌표도 맵 설정 기준으로 재계산한다.
- 파티/인스턴스 정리 과정에서 `ForceReturn`이 걸린 플레이어는 로그인 직후 기본 월드 스폰으로 강제 복귀시킨다.

### 비동기 응답 라우팅 규칙
- S2S 응답은 `gamesessionid`로 원 세션을 찾는다.
- 세션에서 `GetPendingChannelId_AnyThread()`로 로비를 찾고, 로비 Actor로 전달한다.
- 네트워크 스레드에서 직접 상태를 만지지 않고 `lobby->Push(...)`로 컨텍스트를 강제한다.

### 라우팅 드롭 규칙 (stale 응답 차단)
- `FindBySessionId` 실패(이미 종료된 세션)는 즉시 무시한다.
- `playerId == 0`, `pending channel <= 0`, `lobby 없음` 케이스는 처리 경로에 진입시키지 않는다.
- 유효한 pending 컨텍스트가 확인된 응답만 로비 Actor로 전달한다.

### 합류 게이트 본체
- 로비는 `statLoaded`, `itemsLoaded`, `quickLoaded`를 독립 플래그로 관리한다.
- `TryEnterWorldIfReady`는 세 플래그가 모두 true일 때만 Detach -> World Enter를 실행한다.
- 월드 이관 직전 세션의 `PendingEnter`를 clear해 중복 진입 가능성을 차단한다.

### 중복 진입 차단 + 복구 규칙
- `MapChanging` 진행 중이거나 이미 ready 상태인 플레이어의 `EnterGame` 재호출은 차단한다.
- 게이트 통과 후에도 세션/월드 확보가 실패하면 플레이어를 다시 로비에 `Adopt`해 소유권 유실을 막는다.
- 즉, “준비 완료”와 “월드 이관 성공”을 동일시하지 않고, 이관 성공 시점까지 복구 가능한 상태를 유지한다.

### 삽입 다이어그램
```mermaid
flowchart LR
  A[C_ENTER_GAME] --> A1[Normalize channel/map/spawn]
  A1 --> A2[ForceReturn override if needed]
  A2 --> B[Bind Player + SetPendingEnter]
  B --> C1[REQ_LOAD_PLAYER_DATA]
  B --> C2[REQ_ITEMS_LOAD]
  B --> C3[REQ_QUICKSLOT_LOAD]
  C1 --> D1[S2S route by gameSessionId]
  C2 --> D2[S2S route by gameSessionId]
  C3 --> D3[S2S route by gameSessionId]
  D1 --> R{Route valid?}
  D2 --> R
  D3 --> R
  R -->|No| X[Drop stale response]
  R -->|Yes| E[OnStatLoaded]
  R -->|Yes| F[OnItemsLoaded]
  R -->|Yes| G[OnQuickSlotsLoaded]
  E --> H[TryEnterWorldIfReady]
  F --> H
  G --> H
  H -->|All true| I[Detach and Enter World]
  H -->|Not ready| J[Wait in Lobby]
  H -->|World/Session unavailable| K[Re-Adopt Lobby]
```

### 26페이지 전용 배치
- 상단: 요청 시작점 + 컨텍스트 정규화/복귀 정책
- 본문 좌측: 병렬 로딩 합류 흐름도(드롭/복구 분기 포함)
- 본문 우측: 라우팅 드롭 규칙 + 게이트 통과 조건 표
- 하단: 중복 진입 차단/복구 규칙 요약

### 증명 스니펫
- `GameServer/RoomManager.h:36`
- `GameServer/RoomManager.cpp:70`
- `GameServer/ClientPacketHandler.EnterGame.cpp:37`
- `GameServer/ClientPacketHandler.EnterGame.cpp:50`
- `GameServer/ClientPacketHandler.EnterGame.cpp:71`
- `GameServer/ClientPacketHandler.EnterGame.cpp:92`
- `GameServer/ClientPacketHandler.EnterGame.cpp:97`
- `GameServer/S2SPacketHandler.cpp:36`
- `GameServer/S2SPacketHandler.cpp:43`
- `GameServer/LobbyRoom.cpp:106`
- `GameServer/LobbyRoom.cpp:24`
- `GameServer/LobbyRoom.cpp:121`
- `GameServer/GameRoom.MapChange.cpp:44`
- `GameServer/GameRoom.MapChange.cpp:123`

### 근거 코드
- `GameServer/ClientPacketHandler.EnterGame.cpp`
- `GameServer/S2SPacketHandler.cpp`
- `GameServer/LobbyRoom.cpp`
- `GameServer/GameSessionManager.cpp`

### 검증 기록 문장
- 3개 응답의 도착 순서를 변경해도 최종 입장 결과가 동일함을 확인했다.
- `PendingEnter`가 없는 세션은 로딩 응답을 받아도 월드 이관이 일어나지 않음을 확인했다.
- 로딩 응답 도착 전에 세션을 종료했을 때, stale 응답이 로비 상태를 다시 오염시키지 않는지 확인했다.
- 월드 생성/획득 실패 구간에서 플레이어 소유권이 로비로 복구되는지 확인했다.

---

## Page 27. 로딩 완료 후 동기화/정규화 + 실패 수렴

### 페이지 질문
- 로딩 응답을 받은 직후, 어떤 보정과 동기화를 거쳐 플레이 가능한 상태를 확정하는가?

### 로딩 후 처리 원칙
- 아이템/스탯/퀵슬롯은 각각 독립 콜백에서 처리해 데이터 범위가 섞이지 않게 구성했다.
- 각 콜백은 `메모리 반영 -> 보정/재계산 -> Redis priming -> 클라이언트 동기화` 순서를 유지한다.
- 콜백별 실패 분기는 `OnDbLoadFailed`로 수렴시켜 실패 응답 형식과 종료 동작을 고정했다.

### Items 로딩 후 정규화
- `OnItemsLoaded`에서 DB 아이템 목록을 플레이어 메모리에 반영한다.
- 장비 슬롯 정책(무기/방어구/투구)을 기준으로 중복 장착을 검사하고, 중복 항목은 장착 해제 상태로 정규화한다.
- 정규화로 변경된 항목은 `UpdateInventoryItem(...)`로 즉시 영속화 큐에 반영한다.
- 정규화가 끝나면 `RefreshStats`로 파생 스탯을 재계산하고 `S_ITEM_LIST`를 전송한다.

### Stat 로딩 후 동기화
- `OnStatLoaded`에서 `statinfo`와 `gold`를 반영한다.
- 기본 스탯과 장착 보정을 합산하기 위해 `RefreshStats`를 다시 수행한다.
- 이후 `PrimeFromDb_PlayerCore`로 레벨/HP/경험치/골드 기준값을 캐시에 맞춘다.

### QuickSlot 로딩 후 필터링
- `OnQuickSlotsLoaded`는 응답 슬롯을 그대로 쓰지 않고 인덱스 범위를 먼저 검증한다.
- `slotIndex < 0` 또는 `slotIndex >= QS_MAX` 항목은 폐기해 UI 오염을 방지한다.
- 유효 슬롯만 `S_QUICKSLOT_LIST`로 전송해 클라이언트 초기 UI를 확정한다.

### 실패 수렴 경로 (로딩 단계 한정)
- `OnItemsLoaded`/`OnStatLoaded`/`OnQuickSlotsLoaded` 중 하나라도 실패하면 `OnDbLoadFailed(playerId, reason)`를 호출한다.
- 실패 처리를 단일 함수로 묶어 로딩 실패 응답 포맷과 후속 종료 처리의 일관성을 유지한다.

### 삽입 다이어그램
```mermaid
flowchart LR
  A[OnItemsLoaded] --> B[SetItems]
  B --> C[Equip sanitize]
  C --> D[RefreshStats]
  D --> E[PrimeFromDb_Inventory + Send S_ITEM_LIST]

  F[OnStatLoaded] --> G[Apply statinfo + gold]
  G --> H[RefreshStats]
  H --> I[PrimeFromDb_PlayerCore]

  J[OnQuickSlotsLoaded] --> K[PrimeFromDb_QuickSlot]
  K --> L[Filter invalid slotIndex]
  L --> M[Send S_QUICKSLOT_LIST]

  N[Any callback fail] --> O[OnDbLoadFailed(reason)]
  O --> P[Send S_ENTER_GAME(false)]
```

### 27페이지 전용 배치
- 상단: 로딩 후 처리 원칙(3줄)
- 본문 좌측: Items/Stat/QuickSlot 처리 3개 블록
- 본문 우측: 실패 수렴 경로 + 데이터 품질 규칙

### 데이터 품질 규칙
- 중복 장착 데이터는 로딩 직후 서버에서 즉시 정규화한다.
- 퀵슬롯 인덱스는 범위 검증 후 통과 데이터만 동기화한다.
- 파생 스탯 계산은 아이템/스탯 반영 이후에만 수행한다.

### 증명 스니펫
- `GameServer/LobbyRoom.cpp:207`
- `GameServer/LobbyRoom.cpp:224`
- `GameServer/LobbyRoom.cpp:303`
- `GameServer/LobbyRoom.cpp:415`
- `GameServer/LobbyRoom.cpp:160`

### 근거 코드
- `GameServer/LobbyRoom.cpp`
- `GameServer/PersistenceService.*`

### 검증 기록 문장
- 중복 장착 상태 데이터가 로딩 단계에서 자동 정규화되는지 확인했다.
- 잘못된 퀵슬롯 인덱스가 클라이언트 동기화 패킷에서 제외되는지 확인했다.
- 3개 로딩 콜백 중 1개 실패 시 `OnDbLoadFailed` 단일 경로로 수렴하는지 확인했다.

---

## Page 28. 맵 전이 FSM + ACK 검증

### 페이지 질문
- 맵 전이의 실제 룸 이동을 시작하기 전에, 요청/ACK 구간에서 어떤 계약으로 상태 오염을 차단하는가?

### 왜 FSM + 토큰 ACK 검증을 선택했는가
- 맵 전이는 좌표/채널/룸 소유권이 함께 바뀌는 고비용 작업이라, 검증 없이 실행하면 롤백 비용이 크다.
- 클라이언트 재전송/중복 입력/지연 ACK가 섞이면 단순 플래그 방식으로는 정상 ACK와 stale ACK를 구분하기 어렵다.
- 그래서 세션에 전이 상태를 명시적으로 두고, `REQ -> BEGIN(token) -> ACK(token)` 계약을 통과한 경우에만 다음 단계로 넘기도록 설계했다.

### 차단 대상(위협 모델)
- 같은 세션에서 연속 전이 요청이 겹쳐 들어오는 경우
- 이전 전이에서 발급된 오래된 ACK가 뒤늦게 도착하는 경우
- ACK는 왔지만 세션의 `playerId`가 이미 해제된 경우
- ACK 시점의 현재 룸이 유효하지 않거나 `GameRoom`이 아닌 경우

### FSM 상태 계약
- `NONE`: `TryBeginMapChange` 1회만 허용, 성공 시 토큰/목적지 스냅샷 저장 후 `WAITING_ACK`로 전이
- `WAITING_ACK`: `TryConsumeMapChangeAck`에서 상태 + 토큰 동시 일치 시에만 `SWITCHING` 진입
- `SWITCHING`: 완료(`EndMapChange`) 또는 실패(`CancelMapChange`) 전까지 신규 Begin/ACK 소비를 차단
- `CancelMapChange`: 토큰/목적지/상태를 한 번에 초기화해 다음 전이를 깨끗한 상태에서 시작

### 진입 검증 실행 순서 (완료 체인 이전)
1. `Handle_C_MAP_CHANGE_REQ`가 `targetMapId` 유효성(`IsValidMapId`, `IsWorldMapId`)을 확인한다.
2. Session Actor에서 토큰을 생성하고 `TryBeginMapChange`로 상태를 `WAITING_ACK`로 전이한다.
3. 서버가 `S_MAP_CHANGE_BEGIN(token, spawn)`을 전송한다.
4. `Handle_C_MAP_CHANGE_ACK`가 Session Actor에서 `TryConsumeMapChangeAck`를 호출한다.
5. 상태/토큰 검증 통과 후에만 목적지 컨텍스트를 꺼내고, `playerId/room kind` 재검증을 수행한다.
6. 검증을 모두 통과한 경우에만 룸 전이 엔트리(`TransferMapChangeById`)로 전달한다.

### 실패/예외 수렴 규칙 (검증 단계)
- `TryBeginMapChange` 실패(이미 전이 중)는 무시하고 새 전이를 시작하지 않는다.
- `TryConsumeMapChangeAck` 실패(상태 불일치/토큰 불일치)는 무시하고 상태를 진행시키지 않는다.
- ACK 이후 `playerId == 0` 또는 현재 룸이 무효면 `CancelMapChange`로 즉시 초기화한다.
- 검증 실패는 모두 Session FSM 초기화 규칙으로 수렴해 반쯤 전이된 상태를 남기지 않는다.

### 토큰 신뢰 근거
- 토큰은 `playerId`, `sessionId`, 전역 증가 시퀀스, 시간값을 조합해 생성한다.
- ACK는 세션 내부에 저장된 토큰과 정확히 일치할 때만 소비된다.
- 동일 플레이어라도 세션이 바뀌면 토큰 축이 달라져 이전 ACK 재사용이 어렵다.

### 삽입 다이어그램
```mermaid
stateDiagram-v2
  [*] --> NONE
  NONE --> WAITING_ACK: TryBeginMapChange(token)
  NONE --> NONE: duplicate req reject
  WAITING_ACK --> WAITING_ACK: stale/invalid ACK reject
  WAITING_ACK --> SWITCHING: TryConsumeMapChangeAck(token match)
  WAITING_ACK --> NONE: CancelMapChange(error path)
  SWITCHING --> SWITCHING: new req/ack reject
  SWITCHING --> NONE: EndMapChange or CancelMapChange
```

### 28페이지 전용 배치
- 상단: 왜 FSM을 썼는지 + 차단 대상(위협 모델)
- 좌측: 상태 계약 표(`NONE / WAITING_ACK / SWITCHING`)
- 우측: 실패/예외 수렴 규칙 + 토큰 신뢰 근거
- 하단: REQ~ACK 검증 경로 다이어그램

### 증명 스니펫
- `GameServer/ClientPacketHandler.MapChange.cpp:31`
- `GameServer/ClientPacketHandler.MapChange.cpp:67`
- `GameServer/ClientPacketHandler.MapChange.cpp:70`
- `GameServer/ClientPacketHandler.MapChange.cpp:106`
- `GameServer/ClientPacketHandler.MapChange.cpp:112`
- `GameServer/ClientPacketHandler.MapChange.cpp:119`
- `GameServer/PlayerSession.cpp:119`
- `GameServer/PlayerSession.cpp:152`
- `GameServer/ClientPacketHandler.MapChangeUtil.cpp:22`

### 근거 코드
- `GameServer/ClientPacketHandler.MapChange.cpp`
- `GameServer/PlayerSession.cpp`
- `GameServer/ClientPacketHandler.MapChangeUtil.cpp`

### 검증 기록 문장
- 전이 진행 중(`WAITING_ACK`, `SWITCHING`) 추가 요청이 상태를 다시 열지 않는지 확인했다.
- 잘못된 토큰 ACK가 전이를 통과하지 못하는지 확인했다.
- WAITING_ACK 상태가 아닐 때 들어온 ACK가 무시되는지 확인했다.
- ACK 직후 `playerId` 해제/룸 무효 상황에서 `CancelMapChange`로 초기화되는지 확인했다.

---

## Page 29. 전이 완료 체인 + Disconnect 정리 보장

### 페이지 질문
- 전이 완료와 연결 종료가 겹치는 구간에서, 룸/세션/저장 상태를 어떻게 일관되게 정리하는가?

### 왜 이 페이지를 별도로 두었는가
- 맵 전이 성공 경로와 disconnect 예외 경로는 서로 다른 스레드 경계(Session/Room/Instance)를 동시에 건드린다.
- 두 경로를 분리하지 않으면 “전이는 끝났는데 세션 매핑이 남아 있음” 같은 반쯤 정리된 상태가 생긴다.
- 그래서 이 페이지는 전이 완료 자체보다, **충돌 상황에서도 정리 순서를 유지하는 동작 계약**을 설명한다.

### 전이 완료 체인: 고정한 순서와 이유
- `TransferMapChangeById`는 `Leave -> (channel/map/instance 갱신) -> Lobby Adopt -> NewRoom EnterMapChange -> EndMapChange` 순서를 고정한다.
- `Leave`를 먼저 수행해 이전 룸의 시야/그리드/플레이어 목록에서 끊고, 그 다음 목적지 컨텍스트로 갱신해 이중 소속을 방지한다.
- `Lobby Adopt`를 사이에 둬 소유권 완충 구간을 만들고, 새 룸 입장 실패 시에도 복구 가능한 경로를 유지한다.
- `EnterMapChange`는 `S_MAP_CHANGE_END` 이후 AOI/파티 재동기화를 수행해, 맵 전이 직후 화면/상태 기준을 새 룸으로 확정한다.
- `EnterRegister` 실패 등 중간 예외에서는 `CancelMapChange`로 즉시 수렴해 전이 상태 고착을 차단한다.

### Disconnect 정리 체인: 고정한 순서와 이유
- 시작점에서 `GameSessionManager::Remove`를 먼저 호출해 새 패킷 라우팅 진입점을 끊는다.
- Session Actor 정리 루틴에서 `CancelMapChange`를 먼저 수행해 전이 상태를 `NONE`으로 되돌린다.
- 그 다음 `Dirty mark + RequestFlushNow`를 호출해 종료 직전 변경분 저장 요청을 보낸다.
- 이후 `UnbindPlayerId`와 `ClearPlayerId`로 세션-플레이어 결합을 해제한다.
- 룸 정리는 `GameRoom::LeaveById` 단일 엔트리로 위임해, disconnect 시에도 일반 퇴장 경로와 동일한 정리 함수를 재사용한다.
- 마지막으로 인스턴스 멤버였던 경우에만 `InstanceActor::OnMemberOffline`를 연결해 빈 방 close 플래그로 연계한다.

### 정리 이후 불변조건
- 세션 매니저에서 `sessionId/playerId` 역인덱스가 제거되어 stale 라우팅이 발생하지 않는다.
- 플레이어는 이전 룸 자료구조(`_players`, zone, visible set)에서 제거되어 유령 객체가 남지 않는다.
- 맵 전이 FSM은 `NONE`으로 복귀해 다음 전이를 새 요청으로만 시작한다.
- 인스턴스 멤버였다면 오프라인 반영 후 빈 인스턴스 종료 조건까지 전달된다.

### 삽입 다이어그램
```mermaid
flowchart LR
  A[TransferMapChangeById] --> B[Leave old room]
  B --> C[Update channel/map/instance]
  C --> D[Lobby Adopt]
  D --> E[NewRoom EnterMapChange]
  E --> F[EndMapChange]

  G[OnDisconnected] --> H[GameSessionManager::Remove]
  H --> I[Session cleanup post]
  I --> J[CancelMapChange]
  J --> K[Dirty mark + RequestFlushNow]
  K --> L[UnbindPlayerId + ClearPlayerId]
  L --> M[GameRoom::LeaveById]
  M --> N[InstanceActor::OnMemberOffline]
```

### 29페이지 전용 배치
- 상단: 왜 이 페이지를 분리했는지(충돌 구간 정의)
- 좌측: 전이 완료 체인(순서+이유)
- 우측: disconnect 정리 체인(순서+이유)
- 하단: 정리 이후 불변조건 + 검증 결과

### 증명 스니펫
- `GameServer/GameRoom.MapChange.cpp:14`
- `GameServer/GameRoom.MapChange.cpp:59`
- `GameServer/GameRoom.EnterLeave.cpp:95`
- `GameServer/GameRoom.EnterLeave.cpp:102`
- `GameServer/GameRoom.EnterLeave.cpp:236`
- `GameServer/PlayerSession.cpp:24`
- `GameServer/PlayerSession.cpp:29`
- `GameServer/PlayerSession.cpp:36`
- `GameServer/PlayerSession.cpp:53`
- `GameServer/PlayerSession.cpp:58`
- `GameServer/PlayerSession.cpp:70`
- `GameServer/PlayerSession.cpp:82`
- `GameServer/GameSessionManager.cpp:27`
- `GameServer/GameSessionManager.cpp:109`
- `GameServer/InstanceManagerCore.cpp:136`

### 근거 코드
- `GameServer/GameRoom.MapChange.cpp`
- `GameServer/GameRoom.EnterLeave.cpp`
- `GameServer/PlayerSession.cpp`
- `GameServer/GameSessionManager.cpp`
- `GameServer/InstanceManagerCore.cpp`

### 검증 기록 문장
- `TransferMapChangeById` 실행 중 disconnect가 겹쳐도 `CancelMapChange` 이후 상태가 `NONE`으로 복귀하는지 확인했다.
- disconnect 직후 재접속에서 `FindByPlayerId`가 이전 세션을 반환하지 않는지 확인했다.
- disconnect 이후 `LeaveById` 경로를 통해 이전 룸 visible/grid에서 플레이어가 제거되는지 확인했다.
- 인스턴스 마지막 멤버 disconnect 시 `OnMemberOffline` 이후 room close 플래그가 연계되는지 확인했다.
