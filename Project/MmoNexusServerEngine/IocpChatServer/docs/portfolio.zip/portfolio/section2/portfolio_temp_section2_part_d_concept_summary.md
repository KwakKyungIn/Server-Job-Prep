# Section2 Part D 개념 정리 (면접 대비용)

기준 문서: `portfolio_temp_section2.html`의 Part D(맵 전이·파티·인스턴스 던전 정합성 처리)

## Part D 핵심 개념 정리 (면접 대비용)

이 문서는 Part D를 실제 코드 기준으로 정리한 학습 노트입니다.  
목표는 "이 문서만 보고도 Part D 기본 면접 질문(맵 전이 핸드셰이크, 파티 정합성, 인스턴스 수명주기)에 답할 수 있는 상태"를 만드는 것입니다.

### 0) 30초 요약

- 핵심 문제: 맵 전이/파티 변경/인스턴스 생성·종료는 동시에 여러 요청이 들어오면 상태가 쉽게 꼬인다.
- 핵심 해법: 세션·룸·파티·인스턴스를 각각 Actor Queue로 직렬화하고, 상태 전이 가드(FSM/transition flag/version)로 중복·역전 요청을 차단한다.
- 핵심 흐름:
`S_MAP_CHANGE_BEGIN(token) -> C_MAP_CHANGE_ACK(token) -> TransferMapChangeById -> S_MAP_CHANGE_END`
`PartyActor 직렬화 -> inDungeonTransition 잠금 -> InstanceActor 생성/정리 -> ForceReturn`
- 핵심 수렴:
실패는 `CancelMapChange`/상태 원복, 성공은 `EndMapChange`/상태 확정으로 종료 경계를 고정한다.

### 1) Part D에서 다루는 범위

- 맵 전이:
세션 FSM + 토큰 기반 BEGIN/ACK/END 핸드셰이크.
- 파티:
PartyActor 단일 큐 직렬화, version 기반 동기화, 던전 전이 중 변경 잠금.
- 인스턴스 던전:
CreateOrGet/Close/Eject/Timeout/Purge까지 수명주기 전체.
- 오프라인/예외 복구:
`MarkForceReturn` + 로그인 시 `ConsumeForceReturn` 복구 경로.

### 2) 코드 구조 한눈에 보기

#### 2-1. Actor별 책임

- `PlayerSession`(Session Actor):
맵 전이 FSM 상태와 pending 목적지 데이터 관리.
- `GameRoom`(Room Actor):
플레이어 실제 Leave/Enter, AOI 동기화, 맵 전이 실행.
- `PartyActor`:
파티 상태 변경 직렬화, 인스턴스 연계 오케스트레이션.
- `InstanceActor`:
인스턴스 메타데이터 생성/종료/타임아웃 정리 직렬화.
- `RoomManager`:
실제 `GameRoom` 생성/조회 및 최종 purge.

핵심:
"상태 쓰기"는 각 도메인의 Actor 큐 안에서만 수행한다.

#### 2-2. Part D 핵심 파일

- 맵 전이 세션 FSM:
`GameServer/PlayerSession.h`, `GameServer/PlayerSession.cpp`
- 맵 전이 패킷 핸들러:
`GameServer/ClientPacketHandler.MapChange.cpp`
- 실제 방 이동 실행:
`GameServer/GameRoom.MapChange.cpp`, `GameServer/GameRoom.EnterLeave.cpp`
- 맵 전이 유틸/강제 귀환:
`GameServer/ClientPacketHandler.MapChangeUtil.cpp`
- 파티 코어/액터:
`GameServer/PartyManagerCore.h`, `GameServer/PartyManagerCore.cpp`, `GameServer/PartyActor.cpp`
- 파티 패킷 핸들러:
`GameServer/ClientPacketHandler.Party.cpp`
- 던전 입장/퇴장 핸들러:
`GameServer/ClientPacketHandler.Dungeon.cpp`
- 인스턴스 코어/액터:
`GameServer/InstanceManagerCore.h`, `GameServer/InstanceManagerCore.cpp`, `GameServer/InstanceActor.h`
- 최종 방 정리:
`GameServer/RoomManager.cpp`, `GameServer/GameRoom.LifeTime.cpp`

### 3) 맵 전이: 세션 FSM + 토큰 핸드셰이크

#### 3-1. 세션 FSM 상태

`PlayerSession`의 맵 전이 상태:

1. `MAP_CHANGE_NONE`
2. `MAP_CHANGE_WAITING_ACK`
3. `MAP_CHANGE_SWITCHING`

전이 규칙:
`NONE -> WAITING_ACK -> SWITCHING -> NONE`

#### 3-2. 핵심 함수

- `TryBeginMapChange(token, channel, map, instance, spawn)`:
`NONE`일 때만 pending 목적지 저장 + `WAITING_ACK`.
- `TryConsumeMapChangeAck(token, ...)`:
`WAITING_ACK` + 토큰 일치일 때만 목적지 consume + `SWITCHING`.
- `EndMapChange()`:
성공 종료 후 상태 초기화.
- `CancelMapChange()`:
실패/예외에서 상태 초기화.

#### 3-3. BEGIN/ACK/END 패킷 흐름

1. 클라 `C_MAP_CHANGE_REQ`.
2. 서버 검증 후 `S_MAP_CHANGE_BEGIN(token, targetMapId, spawn, instanceId, targetChannelId)`.
3. 클라 로딩 완료 후 `C_MAP_CHANGE_ACK(token)`.
4. 서버가 토큰/상태 검증 후 실제 이동 실행.
5. 입장 완료 시 `S_MAP_CHANGE_END(token, mapId, pos, instanceId, targetChannelId)`.

면접 포인트:
"ACK 없는 즉시 전이보다, 토큰 기반 2단계 전이가 상태 역전·중복 실행을 줄입니다."

### 4) 맵 전이 실행 경로 (실제 이동)

핵심 함수: `GameRoom::TransferMapChangeById`.

#### Step 1. 사전 가드

- `session`/`GRoomManager` 유효성.
- 현재 방 `_players`에 해당 플레이어 존재 확인.
- 목적지 `lobby`/`newRoom` 확보 실패 시 취소.

#### Step 2. 전이 전 정리

- 거래 중이면 `CancelTrade_ActorOnly(..., TRADE_CANCEL_MAP_CHANGE)`.
- 현재 방 `Leave(session, player)` 호출.
- 플레이어 `channel/map/instance/pos` 갱신.

#### Step 3. 부활 pending 특수 처리

- `HasPendingRespawn()`이면 HP 회복/상태 초기화/이동 stamp reset.
- `S_CHANGE_HP` 전송 + 영속화 갱신 후 pending clear.

#### Step 4. Actor 체인 실행

`lobby->Adopt -> newRoom->EnterMapChange -> session SetCurrentRoom/EndMapChange -> lobby->Detach`

핵심:
한 함수에서 "데이터 갱신 + 큐 체인"으로 전이 경계를 고정한다.

### 5) 맵 전이 실패/차단 기준

- 중복 전이:
`IsMapChanging()`이면 요청 무시.
- 잘못된 목적지:
`IsValidMapId`/`IsWorldMapId` 실패 시 거절.
- ACK 위조/역전:
`TryConsumeMapChangeAck`의 token/state 검증 실패로 차단.
- 룸/세션 불일치:
ACK 처리 중 `room` 없거나 GameRoom 아님 -> `CancelMapChange`.
- 목적지 room 확보 실패:
`CancelMapChange`.

실패 수렴 원칙:
"실패는 상태 초기화(`CancelMapChange`)로 수렴해 세션이 잠긴 채 남지 않게 한다."

### 6) 파티 정합성: PartyActor 직렬화 + 버전 동기화

#### 6-1. Core 데이터 구조

`PartyManagerCore::Party` 주요 필드:

- `partyId`, `leaderId`
- `version`
- `members`(HashSet)
- `inDungeonTransition`
- `instanceId`
- `dungeonState`(`NONE/ENTERING/IN_DUNGEON/EXITING`)

#### 6-2. 직렬화 원칙

모든 변경 연산(Create/Invite/Accept/Leave/Kick/Disband)은 `PartyActor::Push`로만 실행한다.

면접 포인트:
"락을 세밀하게 거는 대신, 변경 경로를 단일 큐로 강제해 정합성을 얻었습니다."

#### 6-3. version 증가 시점

- Create 시 시작 version 세팅.
- 멤버 변경/던전 상태 변경마다 version 증가.
- `S_PARTY_INFO_NTF`, `S_PARTY_RESULT`에 version을 담아 클라 동기화 기준 제공.

### 7) 파티 변경 규칙 (핵심 가드)

#### 7-1. Invite/Accept 가드

- 대상이 이미 파티 소속이면 실패.
- `inDungeonTransition == true`면 실패.
- `instanceId != 0`(이미 던전 내부)면 실패.
- 초대 TTL 60초(`expireTick`) 만료 시 실패/폐기.

#### 7-2. Leave/Kick/Disband 가드

- 전이 중(`inDungeonTransition`)이면 변경 금지.
- Kick/Disband는 리더 권한 재검증.
- 리더 탈퇴 시 남은 멤버 최소 ID로 위임.
- 멤버 0명 되면 파티 해산.

#### 7-3. 던전 연계 후처리

`PartyActor::LeaveAndHandleInstance`, `KickAndHandleInstance`, `DisbandAndHandleInstance`에서
InstanceActor와 연동해 Eject/Close를 수행하고 필요시 `ForceReturnToWorld`까지 연결한다.

### 8) 인스턴스 던전 수명주기

#### 8-1. Core 인덱스 3종

`InstanceManagerCore`는 아래 매핑을 동시에 유지한다.

1. `_partyToInstance` (`partyId -> instanceId`)
2. `_instances` (`instanceId -> InstanceInfo`)
3. `_playerToInstance` (`playerId -> instanceId`)

핵심:
종료 시 3개 인덱스를 함께 정리해야 유령 상태가 남지 않는다.

#### 8-2. 생성 경로

- `CreateOrGetForParty`:
이미 있으면 재사용, 없으면 신규 생성.
- ID 생성:
`GenerateInstanceId = (GetTickCount64 << 16) | seq`.
- 멤버를 `members`와 `_playerToInstance`에 등록.

#### 8-3. 종료 경로

- `CloseForParty`:
파티 기준으로 인스턴스 종료 + 역인덱스 정리.
- `EjectMember`:
특정 멤버 제거, empty 여부 반환.
- `CloseByInstanceId`:
instanceId 직접 종료(강퇴/마지막 인원 처리용).

#### 8-4. 타임아웃/최종 purge

- `CollectExpired`:
생성 후 30분(`kInstanceTimeoutMs`) 지난 인스턴스 수집.
- `InstanceActor::TickTimeout`:
만료 인스턴스 close 후 room `MarkClosing(true)`.
- 실제 메모리 제거:
`RoomManager::PurgeInstanceRooms` + `GameRoom::ShouldPurge`.

### 9) 던전 입장/퇴장 파이프라인

#### 9-1. 입장 (`Handle_C_DUNGEON_ENTER_REQ`)

1. 던전 map 유효성 검증.
2. requester의 room/player 문맥 검증.
3. PartyActor에서 party 존재/중복입장 여부 검사.
4. `TryBeginDungeonTransition(ENTERING)`.
5. InstanceActor `CreateOrGetForParty`.
6. 성공 시 `SetPartyInstance + EndDungeonTransition(IN_DUNGEON)`.
7. 요청자 성공 응답 + 멤버 전원 `SendMapChangeBegin` 전파.
8. 기존 위치는 `SaveReturnLocation_ActorOnly`로 저장.

#### 9-2. 퇴장 (`Handle_C_DUNGEON_EXIT_REQ`)

1. requester가 실제 인스턴스 내부인지 확인.
2. PartyActor에서 `TryBeginDungeonTransition(EXITING)`.
3. InstanceActor `CloseForParty`.
4. 실패 시 `EndDungeonTransition(IN_DUNGEON)` 롤백.
5. 성공 시 room closing 마킹.
6. `ClearPartyInstance + EndDungeonTransition(NONE)`.
7. 요청자 성공 응답(`S_DUNGEON_EXIT_RES`).
8. 멤버 전원 `MakeSafeReturn + SendMapChangeBegin`.

### 10) Force Return(온라인/오프라인 복구)

#### 10-1. 온라인 복구

- `MapChangeUtil::ForceReturnToWorld`:
현재 player 문맥에서 귀환 좌표 계산 후 맵 전이 BEGIN 발송.

#### 10-2. 오프라인 복구

- 즉시 세션이 없으면 `MarkForceReturn(playerId)`.
- 로그인 핸들러 `Handle_C_ENTER_GAME`에서 `ConsumeForceReturn` 확인.
- flag가 있으면 기본 월드 스폰으로 강제 진입.

의미:
"즉시 복귀가 불가능한 오프라인 유저도 다음 로그인 시 정합성 복구."

### 11) Part D 핵심 불변조건

1. 맵 전이는 `token + FSM` 둘 다 통과한 ACK만 실행한다.
2. 맵 전이 실패는 `CancelMapChange`, 성공은 `EndMapChange`로 종료한다.
3. 파티 변경은 PartyActor 단일 큐에서만 상태를 쓴다.
4. 던전 전이 중(`inDungeonTransition`) 파티 멤버 변경은 차단한다.
5. 인스턴스 생성/종료 시 party/player 역매핑을 함께 갱신한다.
6. 인스턴스 room 제거는 `MarkClosing -> ShouldPurge` 조건 충족 후 수행한다.
7. 오프라인 강제귀환은 flag로 보존했다가 로그인 때 소비한다.

### 12) 면접 답변 프레임 (Part D)

#### Q1. 왜 맵 전이에 ACK 토큰이 필요한가?

- 한 줄 답:
"클라 로딩 완료 시점을 서버가 검증 가능한 신호로 받아야 상태 역전/중복 전이를 막을 수 있기 때문입니다."

#### Q2. 왜 파티 변경을 Actor로 직렬화했나?

- 한 줄 답:
"동시 요청이 많은 도메인이라 락 분산보다 단일 큐 직렬화가 상태 일관성과 디버깅에 유리했기 때문입니다."

#### Q3. 던전 전이 중 멤버 변경을 막는 이유는?

- 한 줄 답:
"입장/퇴장 트랜잭션 중 멤버셋이 바뀌면 매핑 누락과 미아 상태가 생기기 쉬워 잠금이 필요합니다."

#### Q4. 인스턴스 종료에서 중요한 포인트는?

- 한 줄 답:
"party/instance/player 세 인덱스를 동시에 정리하고 room closing-purge 경계까지 맞추는 것입니다."

#### Q5. 오프라인 강퇴/복귀는 어떻게 처리하나?

- 한 줄 답:
"즉시 처리 불가능하면 force-return flag를 남기고 로그인 시점에 반드시 소비해 월드로 복귀시킵니다."

### 13) 디버깅 체크리스트 (실무형)

- 맵 전이 stuck 시:
세션 FSM(`IsMapChanging`, token, pending target)부터 확인.
- ACK 무시 이슈:
`TryConsumeMapChangeAck` 실패 사유(state/token) 로그화.
- 파티 상태 꼬임:
`version`, `partyId`, `inDungeonTransition`, `instanceId` 동시 확인.
- 던전 유령 방:
`CloseForParty` 호출 여부 + `MarkClosing` + `ShouldPurge` 조건 확인.
- 강퇴 후 잔류:
`EjectMember`, `ForceReturnToWorld`, `MarkForceReturn/ConsumeForceReturn` 경로 확인.

### 14) 면접 직전 암기 포인트

- "맵 전이는 `BEGIN/ACK/END + 세션 FSM`으로 확정한다."
- "파티 변경은 PartyActor 직렬화와 version 동기화가 핵심이다."
- "던전 전이는 `transition 잠금 -> 인스턴스 반영 -> 상태 확정` 순서다."
- "종료는 `Close + ClosingMark + Purge조건`까지 완료돼야 진짜 종료다."
- "온라인/오프라인 모두 ForceReturn 경로로 최종 정합성을 회수한다."

---

## Part D 면접 질문 세트 (총 170문제)

## 1. 기본 개념 문제 (35문제)

1. Part D에서 말하는 "정합성"을 한 문장으로 설명해보세요.

정합성은 같은 플레이어에 대한 상태가 세션, 룸, 파티, 인스턴스, 클라이언트 UI에 서로 모순 없이 반영되고, 실패가 나더라도 결국 하나의 안정된 상태로 수렴하는 것을 뜻합니다.

2. 맵 전이에서 세션 FSM을 두는 이유는 무엇인가요?

맵 전이는 패킷이 비동기로 오고, 클라이언트 로딩 시간도 개입되기 때문에 단순 플래그만으로는 "지금 요청을 받아도 되는지"와 "어느 단계까지 갔는지"를 구분하기 어렵습니다. 그래서 이 프로젝트에서는 `PlayerSession`이 `NONE -> WAITING_ACK -> SWITCHING` 상태를 직접 들고 있게 해서 중복 요청, 오래된 ACK, 역순 도착 패킷을 세션 단에서 먼저 차단합니다.

3. `MAP_CHANGE_NONE`, `WAITING_ACK`, `SWITCHING` 상태 의미를 각각 설명해보세요.

`MAP_CHANGE_NONE`은 맵 전이가 진행 중이 아니어서 새 요청을 받아도 되는 상태입니다. `MAP_CHANGE_WAITING_ACK`는 서버가 `S_MAP_CHANGE_BEGIN`을 보냈고, 아직 클라이언트의 로딩 완료 ACK를 기다리는 구간입니다. `MAP_CHANGE_SWITCHING`은 ACK 검증까지 끝나서 실제로 `Leave`, 방 이동, `EnterMapChange` 같은 서버 측 전이 작업을 수행 중인 상태입니다.

4. `IsMapChanging()` 가드가 어떤 문제를 막나요?

이 가드는 같은 세션에서 맵 이동 요청을 연타하거나, 채널 이동과 던전 입장 같은 전이 요청이 겹쳐 들어오는 상황을 먼저 잘라냅니다. 결과적으로 중복 `BEGIN` 발급, 중복 `Leave`, AOI 이중 등록, 세션 잠김 같은 2차 오류를 막는 가장 바깥쪽 방어선 역할을 합니다.

5. `TryBeginMapChange`는 어떤 시점에서 호출되고 무엇을 저장하나요?

`TryBeginMapChange`는 맵 ID, 채널, 스폰 좌표 같은 사전 검증이 끝난 뒤, 실제 `S_MAP_CHANGE_BEGIN`을 보내기 직전에 호출됩니다. 여기서 토큰, 대상 채널 ID, 대상 맵 ID, 대상 인스턴스 ID, 스폰 좌표를 세션에 pending 상태로 저장하고, 상태를 `WAITING_ACK`로 바꿉니다.

6. `TryConsumeMapChangeAck`가 성공하려면 어떤 조건이 필요하나요?

세션 상태가 반드시 `WAITING_ACK`여야 하고, 클라이언트가 보낸 토큰이 세션에 저장된 현재 전이 토큰과 정확히 일치해야 합니다. 이 두 조건을 통과하면 pending 목적지 정보가 꺼내지고, 상태는 `SWITCHING`으로 전이됩니다.

7. `EndMapChange`와 `CancelMapChange`의 역할 차이는 무엇인가요?

둘 다 내부적으로는 토큰과 pending 목적지를 비우고 상태를 `NONE`으로 되돌리는 공통 역할을 합니다. 다만 의미가 다릅니다. `EndMapChange`는 전이가 정상 완료됐다는 확정 신호이고, `CancelMapChange`는 가드 실패, 룸 확보 실패, 세션 불일치 같은 예외 상황에서 실패 수렴 지점으로 쓰입니다.

8. `S_MAP_CHANGE_BEGIN` 토큰은 왜 필요한가요?

토큰은 "이번 전이 요청"을 유일하게 식별하는 키입니다. 클라이언트가 뒤늦게 ACK를 보내거나 악의적으로 예전 ACK를 재전송해도, 현재 세션이 기다리던 토큰과 다르면 소비되지 않습니다. 즉, 토큰은 로딩 완료 확인과 재전송 방어를 동시에 담당합니다.

9. `C_MAP_CHANGE_ACK`는 서버에 어떤 의미를 주나요?

이 ACK는 "클라이언트가 새 맵 로딩을 마쳤으니 서버가 이제 실제 방 전이를 실행해도 된다"는 승인 신호입니다. 그래서 이 프로젝트에서는 `REQ`만으로는 플레이어를 옮기지 않고, ACK가 와야 `TransferMapChangeById`까지 진입합니다.

10. `S_MAP_CHANGE_END` 패킷은 어떤 완료 신호인가요?

`S_MAP_CHANGE_END`는 서버 쪽에서도 새 방 등록과 세션 전이 경계가 거의 끝났다는 완료 신호입니다. 실제 코드 기준으로는 `EnterMapChange`에서 플레이어를 새 방 자료구조에 등록한 뒤 전송하고, 그 다음 AOI 풀 스냅샷과 파티 정보 재동기화를 이어서 보냅니다.

11. 맵 전이에서 `Leave -> EnterMapChange` 순서를 지키는 이유는 무엇인가요?

먼저 현재 방에서 빠져야 플레이어가 두 방에 동시에 존재하는 상태를 만들지 않을 수 있습니다. 이 순서를 지키면 현재 룸의 Grid, AOI, 플레이어 목록에서 깨끗하게 제거한 뒤 새 룸에 등록하므로, 중복 스폰, 잘못된 가시성, 거래/전투 잔존 같은 부작용을 줄일 수 있습니다.

12. `TransferMapChangeById`의 핵심 책임은 무엇인가요?

이 함수의 핵심 책임은 "검증된 맵 전이를 실제 데이터 이동으로 확정하는 것"입니다. 구체적으로는 현재 방에 플레이어가 있는지 재확인하고, 목적지 로비와 룸을 확보하고, 필요하면 거래를 취소하고, `Leave -> 플레이어 메타데이터 갱신 -> 로비 경유 -> 새 방 Enter -> 세션 종료 처리`까지 한 흐름으로 이어줍니다.

13. 맵 전이 중 거래를 강제 취소하는 이유는 무엇인가요?

거래는 두 플레이어와 인벤토리 상태를 함께 묶는 민감한 흐름이라서, 전이 중 한 명이 다른 룸이나 채널로 빠지면 중간 상태가 남기 쉽습니다. 그래서 맵 전이가 시작되면 `TRADE_CANCEL_MAP_CHANGE` 또는 disconnect 취소 경로로 묶어서, 아이템 증발이나 중복 반영 가능성을 없애는 쪽이 안전합니다.

14. 채널 이동에서 인스턴스 룸을 막는 이유는 무엇인가요?

인스턴스 던전은 `partyId`, `instanceId`, 멤버 집합을 기준으로 독립된 공간이라, 일반 월드처럼 채널만 바꾸는 개념이 맞지 않습니다. 인스턴스 내부에서 채널 이동을 허용하면 "같은 인스턴스인데 채널만 다른 룸" 같은 모순이 생기거나, 파티/인스턴스 매핑이 깨질 수 있어서 정책적으로 차단했습니다.

15. 맵 전이 실패 시 세션 상태를 원복하지 않으면 어떤 문제가 생기나요?

세션이 계속 `WAITING_ACK`나 `SWITCHING`에 머무르면 이후 모든 이동 요청이 `IsMapChanging()`에서 막히게 됩니다. 사용자 입장에서는 이동이 영구적으로 안 되는 것처럼 보이고, 서버 입장에서는 해당 세션이 잠긴 채 남아 복구가 어려운 장애가 됩니다.

16. `MapChangeUtil::MakeMapChangeToken`의 목적은 무엇인가요?

이 함수는 플레이어 ID, 세션 ID, 시간, 전역 시퀀스를 조합해 충돌 가능성이 매우 낮은 전이 토큰을 만듭니다. 목적은 단순 난수 생성이 아니라, 같은 세션에서 연속 전이가 발생해도 각 전이를 명확히 구분할 수 있는 고유 식별자를 만드는 것입니다.

17. `MapChangeUtil::SendMapChangeBegin`은 어떤 공통 로직을 묶나요?

이 유틸은 토큰 생성, `TryBeginMapChange`, `S_MAP_CHANGE_BEGIN` 패킷 구성, 세션 전송까지를 한 번에 묶습니다. 던전 입장, 던전 강제귀환, 일반 맵 전이처럼 여러 흐름에서 같은 준비 코드를 반복하지 않도록 공통화한 것입니다.

18. `MapChangeUtil::MakeSafeReturn`이 필요한 이유는 무엇인가요?

던전에서 복귀할 때 저장해 둔 귀환 맵이나 좌표가 더 이상 유효하지 않을 수 있기 때문입니다. 예를 들어 맵 설정이 바뀌었거나 잘못된 값이 들어가 있으면 그대로 복귀시키는 순간 유저가 미아가 됩니다. 그래서 이 함수가 저장된 복귀 정보를 검증하고, 이상하면 기본 월드 스폰으로 보정합니다.

19. `MapChangeUtil::ForceReturnToWorld`는 언제 쓰나요?

이 함수는 던전 퇴장, 파티 탈퇴/강퇴/해산, 던전 내 사망 후 월드 복귀처럼 "지금 위치를 유지시키면 정합성이 깨지는 경우"에 사용합니다. 세션 -> 현재 룸 -> 다시 세션으로 흐름을 돌면서 안전한 복귀 좌표를 계산하고, 최종적으로 `SendMapChangeBegin`을 발송합니다.

20. `PartyActor`와 `PartyManagerCore`의 역할 분리는 어떻게 되나요?

`PartyActor`는 파티 관련 요청을 한 줄로 세워 실행 순서를 보장하는 오케스트레이터입니다. 반면 `PartyManagerCore`는 실제 파티 데이터 구조와 변경 로직을 가진 순수 코어입니다. 즉, Actor는 "언제 실행할지", Core는 "무엇을 바꿀지"를 담당한다고 보면 됩니다.

21. 파티 `version` 필드가 필요한 이유는 무엇인가요?

파티는 생성, 초대 수락, 탈퇴, 강퇴, 던전 전이만으로도 상태가 자주 바뀌기 때문에, 클라이언트가 어느 스냅샷이 최신인지 판단할 기준이 필요합니다. `version`은 그 기준점 역할을 하며, `S_PARTY_INFO_NTF`나 `S_PARTY_RESULT`에 같이 내려줘서 UI가 구버전 알림에 덮어씌워지지 않게 합니다.

22. `inDungeonTransition` 플래그는 어떤 잠금 역할을 하나요?

이 플래그는 던전 입장/퇴장 트랜잭션이 진행 중일 때 파티 멤버 구성을 얼리는 잠금입니다. 전이 중에 Invite, Accept, Leave, Kick, Disband가 들어오면 인스턴스 멤버셋과 파티 멤버셋이 서로 다른 상태가 되기 쉬우므로, 이 구간에서는 멤버 변경을 막아야 합니다.

23. `DungeonState`(`ENTERING/IN_DUNGEON/EXITING`)는 왜 필요하나요?

단순히 "던전 안이다/아니다"만으로는 전이 중간 상태를 설명할 수 없습니다. `ENTERING`과 `EXITING`을 분리해야 현재 단계가 입장 잠금인지, 실제 플레이 중인지, 종료 롤백이 필요한지 명확해집니다. 면접에서는 이 값을 파티 단위의 미니 FSM이라고 설명하면 좋습니다.

24. 초대 TTL(`expireTick`)을 두는 이유는 무엇인가요?

초대장을 무기한 유지하면 오래된 팝업을 뒤늦게 수락해서 현재 파티 상태와 어긋나는 문제가 생깁니다. 그래서 서버 시간이 기준인 `expireTick`으로 60초 만료를 두고, 만료된 초대는 수락 시점에 다시 걸러 stale request가 반영되지 않게 합니다.

25. 파티 리더가 나갔을 때 리더 위임 규칙은 무엇인가요?

현재 구현에서는 남아 있는 멤버 중 ID가 가장 작은 사람에게 리더 권한을 넘깁니다. 가장 단순하지만 결정적이고 재현 가능한 규칙이어서, 별도 투표나 우선순위 테이블 없이도 리더 부재 상태를 즉시 정리할 수 있습니다.

26. `Leave/Kick/Disband`가 던전 처리와 함께 묶이는 이유는 무엇인가요?

파티에서 멤버를 빼는 논리 처리만 하고 실제 인스턴스 멤버를 그대로 두면, 파티 상태와 던전 상태가 서로 어긋납니다. 그래서 이 프로젝트에서는 탈퇴, 강퇴, 해산이 일어나면 `EjectMember`, `CloseForParty`, `ForceReturnToWorld`, `MarkForceReturn`까지 묶어서 실제 위치와 메타데이터를 함께 정리합니다.

27. `InstanceManagerCore`의 3개 인덱스는 각각 무엇을 뜻하나요?

`_partyToInstance`는 어떤 파티가 어느 인스턴스를 소유하는지 찾는 매핑입니다. `_instances`는 `instanceId`를 기준으로 채널, 맵, 멤버 목록 같은 인스턴스 본문 정보를 저장합니다. `_playerToInstance`는 개별 플레이어가 현재 어느 인스턴스에 속해 있는지 빠르게 찾기 위한 역인덱스입니다.

28. `CreateOrGetForParty`가 "생성 또는 재사용"인 이유는 무엇인가요?

던전 입장 요청은 재시도나 중복 입력이 들어올 수 있기 때문에, 매번 새 인스턴스를 만들면 같은 파티에 여러 던전이 생길 수 있습니다. 그래서 이미 생성된 인스턴스가 있으면 그대로 돌려주고, 없을 때만 새로 만드는 방식으로 idempotent하게 설계했습니다.

29. `CloseForParty`가 종료 시 반드시 해야 하는 정리는 무엇인가요?

핵심은 `_partyToInstance`, `_instances`, `_playerToInstance` 세 인덱스를 함께 정리하는 것입니다. 하나라도 남아 있으면 파티는 던전이 끝났는데 플레이어는 여전히 인스턴스 안이라고 판단되거나, 반대로 유령 인스턴스가 살아 있는 것처럼 보일 수 있습니다.

30. `EjectMember`는 어떤 상황에서 사용되나요?

`EjectMember`는 인스턴스를 통째로 닫지 않고 특정 멤버만 던전에서 빼야 할 때 사용합니다. 대표적으로 던전 내부에서 파티 탈퇴, 강퇴, 오프라인 이탈이 발생했을 때 이 함수로 멤버 집합과 `_playerToInstance` 역인덱스를 먼저 정리합니다.

31. `OnMemberOffline`는 어떤 종료 시나리오를 다루나요?

이 함수는 인스턴스 내부 플레이어가 접속 종료나 튕김으로 사라졌을 때를 다룹니다. 해당 플레이어를 인스턴스 멤버 목록에서 제거하고, 그 결과 마지막 인원이 빠졌다면 인스턴스를 자동 종료하는 후속 시나리오까지 책임집니다.

32. `CollectExpired`와 `TickTimeout`은 무엇을 위한 로직인가요?

`CollectExpired`는 만료 조건을 만족한 인스턴스를 수집하는 코어 로직이고, `TickTimeout`은 그 목록을 실제로 닫고 룸에 `MarkClosing(true)`를 적용하는 실행 로직입니다. 즉, 전자는 "무엇이 만료됐는가"를 판별하고, 후자는 "그 만료된 인스턴스를 어떻게 정리할 것인가"를 수행합니다.

33. `MarkClosing`과 `ShouldPurge`의 관계를 설명해보세요.

`MarkClosing`은 인스턴스 룸을 즉시 삭제하지 않고 "이 방은 종료 수순에 들어갔다"는 상태로 바꾸는 표시입니다. 이후 `ShouldPurge`가 인스턴스 방인지, closing 상태인지, 인원이 0명인지, 빈 상태가 일정 시간 유지됐는지를 확인해 최종 삭제 가능 여부를 판단합니다.

34. 오프라인 강제귀환(`MarkForceReturn/ConsumeForceReturn`)은 왜 필요하나요?

강퇴나 해산 시점에 대상이 오프라인이면 즉시 `MapChangeBegin`을 보낼 수 없기 때문에, 원하는 최종 상태를 어딘가에 보관해야 합니다. 그래서 현재 프로젝트는 ForceReturn 플래그를 기록해 두고, 다음 로그인 시 `ConsumeForceReturn`으로 소비하면서 기본 월드로 강제 복귀시켜 eventual consistency를 맞춥니다.

35. Part D를 한 문장으로 요약하면 무엇인가요?

Part D는 맵 전이, 파티 변경, 인스턴스 생성·종료처럼 동시성에 취약한 흐름을 Actor 직렬화와 상태 전이 가드로 묶어, 실패해도 항상 하나의 정상 상태로 수렴시키는 설계입니다.

## 2. 어려운 개념 질문 (10문제)

1. ACK 지연으로 오래된 토큰이 뒤늦게 도착할 때 현재 구조가 어떻게 안전성을 보장하는지 설명해보세요.

현재 구조는 "토큰 일치"만 보는 것이 아니라 "세션 상태가 아직 `WAITING_ACK`인가"까지 함께 확인합니다. 그래서 한 번 ACK를 소비해 `SWITCHING`으로 넘어갔거나, 실패 수렴으로 `NONE`으로 돌아간 뒤에 늦게 들어온 오래된 ACK는 통과할 수 없습니다. 즉, 토큰과 FSM을 둘 다 검증해서 늦은 패킷을 무해한 패킷으로 만듭니다.

2. `SessionActor -> RoomActor -> PartyActor -> InstanceActor` 체인에서 분산 트랜잭션 없이 정합성을 지키는 설계 포인트를 설명해보세요.

핵심은 각 도메인의 상태 쓰기를 해당 Actor 큐 안으로 한정하는 것입니다. 세션은 전이 의도와 토큰을 소유하고, 룸은 플레이어 실제 소속과 AOI를 바꾸고, 파티는 멤버십과 던전 상태를 바꾸고, 인스턴스는 생성·종료 매핑을 바꿉니다. 분산 트랜잭션 대신 각 단계 앞에 가드와 중간 잠금을 두고, 실패 시에는 `CancelMapChange`, `EndDungeonTransition` 롤백, `ForceReturn` 같은 명확한 수렴 지점을 마련해 전체 일관성을 유지합니다.

3. 던전 입장 중 `TryBeginDungeonTransition` 이후 실패했을 때 롤백 경계를 어디로 잡아야 하는지 설명해보세요.

롤백 기준은 "파티가 다시 `instanceId=0`, `inDungeonTransition=false`, `dungeonState=NONE`인 안정 상태로 돌아왔는가"입니다. 현재 구현에서도 `TryBeginDungeonTransition(ENTERING)` 이후 `CreateOrGetForParty`가 실패하면 `EndDungeonTransition(NONE)`과 `ClearPartyInstance`를 호출해 이 경계로 되돌립니다. 만약 인스턴스가 일부라도 만들어진 뒤 실패한다면, 그 인스턴스 매핑까지 닫고 나서 같은 안정 상태로 수렴시켜야 완전한 롤백입니다.

4. 파티 version이 빠르게 증가하는 상황에서 클라이언트 UI 갱신 순서가 꼬일 수 있는 위험을 어떻게 줄일 수 있나요?

가장 기본은 클라이언트가 마지막으로 적용한 `version`보다 작은 패킷을 버리게 만드는 것입니다. 그리고 파티 상태를 delta가 아니라 스냅샷 형태로 내려주면 중간 패킷 하나가 유실돼도 최신 스냅샷 하나로 회복할 수 있습니다. 추가로 version gap이 감지되면 `C_PARTY_STATUS_REQ`나 전체 재조회 경로를 태워 강제 재동기화를 하게 만드는 것이 안전합니다.

5. 인스턴스 종료와 멤버 강제귀환이 비동기로 분리될 때 발생 가능한 레이스를 설명해보세요.

논리적으로는 인스턴스가 이미 닫혔는데, 물리적으로는 플레이어가 아직 그 방에 남아 있거나 반대로 이미 다른 위치로 이동한 뒤 강제귀환 요청이 늦게 도착하는 레이스가 생길 수 있습니다. 이 프로젝트는 `RequestForceReturnToWorld(playerId, expectedInstanceId)`에서 플레이어의 현재 `instanceId`가 기대값과 같은지 다시 확인해, 이미 다른 곳으로 나온 유저에게 늦은 귀환을 덮어쓰지 않도록 방어합니다. 오프라인이면 즉시 이동 대신 ForceReturn 플래그로 넘겨 다음 로그인 때 정리합니다.

6. `CloseForParty` 성공 후 `MarkClosing`만 하고 즉시 삭제하지 않는 이유를 수명주기 관점에서 설명해보세요.

인스턴스 논리 상태를 닫는 순간에도 방 객체에는 아직 플레이어 참조, 남은 Job, AOI 정리, 네트워크 지연 같은 잔여 작업이 남아 있을 수 있습니다. 그래서 `CloseForParty`는 메타데이터를 먼저 정리하고, `MarkClosing`으로 더 이상 새 입장을 받지 않게 만든 뒤, 빈 방과 유예 시간 조건이 모두 충족됐을 때 `ShouldPurge`를 통해 최종 삭제합니다. 이 두 단계 분리가 있어야 use-after-free나 방 재생성 플랩을 줄일 수 있습니다.

7. 오프라인 강퇴 대상에 대해 `ForceReturn` 플래그 방식이 eventual consistency를 어떻게 보장하는지 설명해보세요.

오프라인 상태에서는 세션도 없고 현재 룸 액터에도 접근할 수 없어서 즉시 강제귀환을 실행할 수 없습니다. 대신 "이 플레이어는 다음에 보이면 월드로 보내야 한다"는 의도를 ForceReturn 플래그로 저장해 둡니다. 이후 로그인이라는 재관측 시점에 `ConsumeForceReturn`을 수행하면서 최종 상태를 강제 적용하므로, 즉시는 아니어도 결국은 원하는 상태로 수렴합니다.

8. timeout 기반 종료(`CollectExpired`)가 활성 플레이와 충돌할 수 있는 케이스를 어떻게 방어할지 설명해보세요.

현재 구현처럼 `createdTick` 기준 고정 만료만 쓰면, 플레이어가 활발히 플레이 중이어도 생성 후 30분이 지나면 종료 후보가 될 수 있다는 한계가 있습니다. 이를 방어하려면 최소한 `lastActiveTick`, 현재 멤버 수, 보스 전투 여부 같은 활동 지표를 함께 반영해야 합니다. 또한 만료 직전 한 번 더 `GetPlayerCountApprox`, 파티 상태, 최근 이벤트 시간을 재확인하는 2차 검증이 필요합니다.

9. 파티 변경과 맵 전이를 동시에 누르는 악성 입력에 대해 어떤 순서로 방어해야 하는지 설명해보세요.

가장 먼저 세션 단에서 `IsMapChanging()`와 맵 전이 FSM으로 중복 전이 자체를 잘라야 합니다. 그 다음 파티 관련 요청은 `PartyActor` 단일 큐로 모으고, `inDungeonTransition`이나 `instanceId != 0` 가드로 전이 중 멤버 변경을 막아야 합니다. 마지막으로 룸/인스턴스 단계에서 현재 플레이어가 정말 해당 방과 인스턴스에 속해 있는지 재검증해야, 악성 입력이 여러 경로로 들어와도 중간 상태가 남지 않습니다.

10. 멀티 채널/멀티 맵 환경에서 `targetChannelId`, `targetMapId`, `instanceId` 조합 검증의 핵심 리스크를 설명해보세요.

이 세 값은 함께 룸의 주소를 이루기 때문에 하나라도 잘못 조합되면 전혀 다른 공간으로 잘못 진입할 수 있습니다. 예를 들어 월드 맵인데 `instanceId`가 0이 아니거나, 인스턴스 던전인데 채널 정책과 맞지 않는 조합을 허용하면 유저 격리와 파티 정합성이 무너집니다. 그래서 월드 전이는 `instanceId=0`, 인스턴스 전이는 유효한 `instanceId`와 파티 문맥이 있는지, 채널은 현재 또는 허용된 값인지 묶어서 검증해야 합니다.

## 3. 기술/개념 선택 이유 질문 (30문제)

1. 왜 맵 전이에 토큰 기반 핸드셰이크를 선택했나요?

맵 전이는 클라이언트 로딩이라는 외부 시간이 개입되기 때문에, 요청만 받자마자 서버가 전이를 확정하면 로딩이 끝나지 않은 클라이언트와 서버 상태가 어긋날 수 있습니다. 토큰 기반 핸드셰이크를 쓰면 "서버가 시작한 전이"와 "클라이언트가 완료를 알린 ACK"를 같은 전이 단위로 묶을 수 있어서, 중복 실행과 오래된 ACK 재도착을 함께 막을 수 있습니다.

2. 왜 `C_MAP_CHANGE_REQ`와 `C_MAP_CHANGE_ACK`를 분리했나요?

`REQ`는 플레이어의 의도, `ACK`는 클라이언트가 실제로 새 맵 로딩을 끝냈다는 준비 완료 신호라 의미가 다릅니다. 이를 분리하면 서버는 승인과 실제 실행을 나눌 수 있고, 로딩 지연이나 재전송 상황에서도 안전하게 전이 타이밍을 제어할 수 있습니다.

3. 왜 맵 전이 상태를 세션에 저장하나요?

맵 전이는 네트워크 패킷 단위의 프로토콜 상태이기 때문에 가장 자연스러운 소유자는 연결 객체인 세션입니다. 실제로 어떤 토큰을 기다리는지, 어느 목적지로 갈 예정인지, 지금 전이가 진행 중인지 같은 정보는 플레이어보다 세션 수명주기와 더 밀접합니다.

4. 왜 `TryBeginMapChange`에서 pending 목적지 정보를 저장하나요?

전이 요청 시점과 ACK 소비 시점 사이에는 시간 차이가 있고, 그 사이에 여러 비동기 작업이 끼어들 수 있습니다. 그래서 서버가 승인한 정확한 목적지 정보를 세션에 pending으로 저장해 두고, ACK가 왔을 때 그 값을 다시 꺼내 써야 일관된 전이가 가능합니다.

5. 왜 ACK 소비 시 `WAITING_ACK` 상태를 강제하나요?

ACK는 아무 때나 받아주면 안 되고, 반드시 서버가 `BEGIN`을 발행한 직후에만 유효해야 합니다. `WAITING_ACK` 상태를 강제하면, 이미 전이가 끝난 뒤 늦게 도착한 ACK나 애초에 시작되지 않은 전이에 대한 위조 ACK를 모두 무시할 수 있습니다.

6. 왜 전이 실패 시 즉시 `CancelMapChange`로 수렴시키나요?

맵 전이 실패는 대부분 "계속 진행할수록 더 꼬이는" 성격이라 미완료 상태를 남기는 것이 가장 위험합니다. 그래서 이 프로젝트는 예외 발생 시 빠르게 `CancelMapChange`로 모아서 세션을 다시 `NONE`으로 돌리고, 다음 정상 요청을 받을 수 있는 상태를 우선 회복합니다.

7. 왜 `TransferMapChangeById`를 현재 방(`GameRoom`)에서 실행하나요?

플레이어가 현재 어느 방에 속해 있는지, `_players`에 실제로 있는지, `Leave` 시 어떤 AOI와 Grid 정리가 필요한지는 현재 방만 가장 정확히 알고 있습니다. 따라서 현재 방 액터 안에서 `Leave`를 수행하고 목적지로 넘겨야, 공유 상태를 외부 스레드에서 건드리지 않고 안전하게 이동시킬 수 있습니다.

8. 왜 목적지 room을 먼저 확보한 뒤 Leave를 수행하나요?

먼저 현재 방에서 빼버리고 나서 목적지 룸 생성이나 조회에 실패하면 플레이어가 어느 방에도 속하지 않는 미아 상태가 됩니다. 그래서 이 프로젝트는 `GetOrCreateLobby`, `GetOrCreateRoom`을 먼저 성공시킨 뒤 `Leave`를 실행해, 실패하면 현재 방에 남겨두고 취소할 수 있게 설계했습니다.

9. 왜 맵 전이 중 거래를 강제 취소하나요?

거래는 두 플레이어의 인벤토리와 골드를 함께 묶는 사실상 작은 트랜잭션입니다. 이 상태에서 맵 전이를 허용하면 한쪽만 다른 방으로 이동하거나 세션이 끊기면서 절반만 반영된 상태가 남을 수 있으므로, 전이 시작 시점에 강제 취소로 수렴시키는 편이 훨씬 안전합니다.

10. 왜 맵 전이 중간에 로비 `Adopt` 단계를 거치나요?

이 프로젝트에서 로비는 채널 단위 게이트이자 임시 소유권 이전 지점 역할을 합니다. 현재 방에서 바로 새 방으로 붙이는 대신 로비를 거치면, 세션의 현재 룸과 플레이어의 소속을 안정적으로 넘기면서 채널 내 이동 경계를 통일된 방식으로 처리할 수 있습니다.

11. 왜 `S_MAP_CHANGE_END`에서 토큰을 다시 내려주나요?

`BEGIN` 때 발급한 토큰을 `END`에서도 다시 내려주면, 클라이언트는 자신이 완료 통지를 받은 전이가 현재 진행하던 전이와 같은 것인지 다시 확인할 수 있습니다. 즉, 시작과 끝을 같은 식별자로 묶어 주는 프로토콜 완결성 측면에서 의미가 있습니다.

12. 왜 채널 변경에서 인스턴스 룸 이동을 금지했나요?

월드맵 채널 이동은 동일한 맵을 다른 인원 분산 채널로 옮기는 개념이지만, 인스턴스 던전은 파티 전용 공간이라 채널을 따로 바꾸는 정책 자체가 맞지 않습니다. 인스턴스에서 채널 변경을 허용하면 같은 `instanceId`를 여러 채널이 공유하는 이상한 상황이 생길 수 있어 금지했습니다.

13. 왜 강제귀환 위치 계산을 `MakeSafeReturn` 유틸로 분리했나요?

강제귀환은 던전 퇴장, 파티 탈퇴, 강퇴, 해산, 던전 사망 복귀 등 여러 흐름에서 재사용됩니다. 이때 저장된 복귀 위치가 항상 유효하다고 가정하면 중복 버그가 생기기 쉬우므로, 맵 검증과 기본 스폰 보정을 `MakeSafeReturn` 하나로 모아 공통 안전장치로 둔 것입니다.

14. 왜 파티 변경을 `PartyActor` 단일 큐로 직렬화했나요?

파티는 생성, 초대, 수락, 탈퇴, 강퇴, 해산, 던전 상태 변경이 자주 얽히는 도메인이라 락 기반 병렬 처리보다 순서 보장이 더 중요했습니다. 단일 큐 직렬화를 사용하면 어느 요청이 먼저 반영됐는지 명확해지고, 리더 변경이나 version 증가처럼 순차성이 중요한 로직을 단순하게 만들 수 있습니다.

15. 왜 파티 코어(`PartyManagerCore`)를 순수 데이터 로직으로 분리했나요?

Actor 안에 모든 로직을 넣으면 실행 순서와 데이터 연산이 한 군데 섞여서 테스트와 유지보수가 어려워집니다. `PartyManagerCore`를 분리하면 파티 자료구조와 상태 전이 규칙을 독립적으로 읽고 검증할 수 있고, Actor는 큐 직렬화와 타 도메인 연계에 집중할 수 있습니다.

16. 왜 파티에 `version`을 두고 응답마다 내려주나요?

파티는 UI에 보이는 정보가 많고, 상태 변경도 잦기 때문에 클라이언트 입장에서는 "이 응답이 최신인가"를 구분할 근거가 필요합니다. `version`을 모든 결과와 알림에 같이 넣으면, 클라이언트가 늦게 도착한 응답이나 중복 알림을 안전하게 무시할 수 있습니다.

17. 왜 `inDungeonTransition` 상태에서 Invite/Accept/Leave/Kick/Disband를 막나요?

던전 입장과 퇴장 구간은 파티 멤버 집합이 인스턴스 멤버 집합으로 복사되거나 반대로 정리되는 구간이라, 이 시점에 멤버가 바뀌면 매핑 누락이 발생하기 쉽습니다. 따라서 전이 중에는 멤버셋을 freeze해 두고, 전이가 끝난 뒤에만 변경 요청을 받는 것이 정합성에 유리합니다.

18. 왜 초대장을 target 기준 단일 pending으로 관리하나요?

동시에 여러 초대장을 허용하면 수락 시 어느 초대를 선택한 것인지, 오래된 초대가 최신 상태를 덮어쓰지 않는지 관리가 복잡해집니다. 대상 기준으로 하나만 유지하면 사용자는 최신 초대만 보게 되고, 서버도 `targetId` 하나만 보면 되므로 수락 검증이 훨씬 단순해집니다.

19. 왜 초대 만료 시간을 서버 tick으로 관리하나요?

클라이언트 시간을 기준으로 하면 시간 조작이나 클럭 차이 때문에 만료 판정이 흔들릴 수 있습니다. 서버 tick을 기준으로 두면 모든 사용자가 같은 시간축을 공유하게 되어, 초대 TTL과 만료 판정을 서버 권위로 일관되게 통제할 수 있습니다.

20. 왜 리더 권한을 모든 변경 요청에서 재검증하나요?

클라이언트 UI는 지연되거나 stale 상태일 수 있어서, 사용자가 자신이 아직 리더라고 믿고 강퇴나 해산을 시도할 수 있습니다. 서버가 매 요청마다 현재 `leaderId`를 다시 확인해야, 오래된 UI나 위조 패킷이 권한 없는 변경을 일으키지 못합니다.

21. 왜 Leave/Kick/Disband에서 인스턴스 처리까지 함께 수행하나요?

파티 변경은 단순히 멤버 목록만 바꾸는 게 아니라, 이미 던전 안에 있던 물리적 위치와 인스턴스 매핑까지 함께 바꿔야 끝난 것입니다. 그래서 멤버 제거 후 `EjectMember`, `CloseForParty`, `ClearPartyInstance`, `ForceReturnToWorld`를 같이 수행해야 논리 상태와 실제 위치가 일치합니다.

22. 왜 인스턴스 매핑을 party/player 두 축으로 유지하나요?

조회 패턴이 두 가지이기 때문입니다. 파티 기준으로는 "이 파티가 어느 던전을 돌고 있는가"를 빨리 알아야 하고, 플레이어 기준으로는 "이 유저가 현재 어느 인스턴스에 묶여 있는가"를 빨리 찾아야 합니다. 쓰기 비용이 조금 늘더라도 읽기 경로를 O(1)에 가깝게 유지하는 것이 실무적으로 유리합니다.

23. 왜 `CreateOrGetForParty` 방식으로 재사용을 허용했나요?

던전 입장 요청은 네트워크 재시도, 버튼 연타, 응답 유실 때문에 같은 요청이 여러 번 들어올 수 있습니다. 이때 매번 새 인스턴스를 만들면 파티 하나에 여러 던전이 생기므로, 기존 매핑이 있으면 그대로 반환하는 idempotent 설계가 필요했습니다.

24. 왜 인스턴스 ID 생성에 시간+시퀀스 조합을 사용했나요?

단순 증가 정수만 쓰면 서버 재시작 시 충돌 가능성이 있고, 순수 랜덤만 쓰면 디버깅과 추적성이 떨어질 수 있습니다. 시간 상위 비트와 시퀀스 하위 비트를 조합하면 짧은 시간 내 충돌을 피하면서도 생성 시점 추론이 가능한 ID를 만들 수 있습니다.

25. 왜 던전 입장에서 `TryBeginDungeonTransition(ENTERING)`을 먼저 수행하나요?

외부 부작용을 만들기 전에 먼저 파티 상태를 잠가야 중복 입장과 멤버 변경을 막을 수 있기 때문입니다. 다시 말해 인스턴스 생성보다 잠금이 먼저여야, 생성 도중 다른 초대나 탈퇴 요청이 끼어들어 파티와 인스턴스 멤버셋이 달라지는 상황을 막을 수 있습니다.

26. 왜 던전 퇴장에서 실패 시 `IN_DUNGEON`으로 롤백하나요?

퇴장 트랜잭션이 실패했다는 것은 실제로는 아직 던전 플레이 상태가 유지된다는 뜻입니다. 그래서 `EXITING` 상태를 그대로 남기면 파티가 잠긴 채 아무 작업도 못 하게 되므로, 논리적으로 가장 가까운 안정 상태인 `IN_DUNGEON`으로 되돌려 계속 플레이 가능하게 만드는 것이 맞습니다.

27. 왜 인스턴스 종료 즉시 삭제 대신 `MarkClosing` 후 purge를 택했나요?

메타데이터를 닫는 시점과 메모리 객체를 해제하는 시점은 분리하는 편이 안전합니다. 즉시 삭제하면 남은 Job, 지연 패킷, 빈 방 판정 타이밍과 충돌할 수 있으므로, 먼저 closing 상태로 전환하고 빈 방+유예 시간 조건을 만족한 후 안전하게 `PurgeInstanceRooms`에서 제거하도록 했습니다.

28. 왜 오프라인 대상은 즉시 처리 대신 `MarkForceReturn`을 기록하나요?

오프라인 유저는 세션도 없고 현재 룸 액터에도 접근할 수 없어서 지금 당장 `SendMapChangeBegin`을 보낼 방법이 없습니다. 이런 경우 억지로 즉시 처리하려고 하면 실패만 남기므로, 일단 원하는 최종 상태를 기록해 두고 다음 로그인에서 소비하는 쪽이 실제 운영에서는 더 견고합니다.

29. 왜 로그인 시 `ConsumeForceReturn`을 먼저 확인하나요?

로그인 직후가 오프라인 상태에서 남은 불일치를 회수할 수 있는 가장 빠른 시점이기 때문입니다. 이 시점에 강제귀환 플래그를 먼저 소비해야, 유저를 기존 잘못된 맵으로 입장시키지 않고 바로 기본 월드 스폰으로 보정할 수 있습니다.

30. 왜 Part D를 Actor 체인 기반 오케스트레이션으로 설계했나요?

Part D는 세션, 룸, 파티, 인스턴스가 각자 다른 소유권과 동시성 경계를 가진 도메인이라 하나의 전역 락이나 거대한 함수로 처리하기 어렵습니다. Actor 체인 기반 오케스트레이션을 쓰면 각 도메인의 쓰기 책임을 유지한 채 순서만 연결할 수 있고, 실패 수렴 지점도 도메인별로 명확하게 둘 수 있습니다.

## 4. 파트 흐름 질문 (30문제)

1. `C_MAP_CHANGE_REQ` 수신 후 `S_MAP_CHANGE_BEGIN` 전송까지의 흐름을 설명해보세요.

먼저 세션 핸들러에서 `IsMapChanging()`와 `playerId`를 확인해 중복 요청을 걸러냅니다. 그다음 `DataManager`로 대상 맵이 유효한 월드 맵인지 확인하고, 맵 설정에서 스폰 좌표를 얻습니다. 검증이 끝나면 세션 Actor로 돌아가 현재 룸 기준 채널을 정하고, `MakeMapChangeToken -> TryBeginMapChange`를 수행한 뒤 `S_MAP_CHANGE_BEGIN`을 전송합니다.

2. `S_MAP_CHANGE_BEGIN` 이후 `C_MAP_CHANGE_ACK`가 들어왔을 때 처리 순서를 설명해보세요.

ACK를 받으면 먼저 세션 Actor에서 `TryConsumeMapChangeAck`로 상태와 토큰을 검증합니다. 성공하면 pending 목적지 정보를 꺼내고, `playerId`와 현재 룸이 유효한 `GameRoom`인지 다시 확인합니다. 그 후 현재 방 Actor로 작업을 넘겨 `TransferMapChangeById`를 실행하게 합니다.

3. `TryConsumeMapChangeAck` 성공 후 `TransferMapChangeById` 호출까지의 흐름을 설명해보세요.

`TryConsumeMapChangeAck`가 성공하면 세션은 이미 `SWITCHING` 상태가 되고, 대상 채널·맵·인스턴스·스폰 좌표를 확보한 상태가 됩니다. 세션은 현재 `RoomActor`를 가져와 그것이 `GameRoom`인지 확인한 뒤, 해당 룸의 큐에 `TransferMapChangeById` Job을 넣습니다. 즉, ACK 소비는 세션 책임이고 실제 플레이어 이동은 현재 방 책임으로 분리됩니다.

4. `TransferMapChangeById`에서 사전 가드 실패 시 어떤 경로로 종료되는지 설명해보세요.

이 함수는 세션이나 `GRoomManager`가 없을 때, 현재 방 `_players`에 플레이어가 없을 때, 목적지 로비나 새 방을 확보하지 못했을 때 즉시 실패합니다. 이때 공통적으로 세션 Actor로 다시 돌아가 `CancelMapChange`를 호출하고, 더 이상의 이동 작업은 수행하지 않습니다. 즉, 실패는 모두 세션 FSM 초기화로 수렴합니다.

5. 맵 전이 성공 경로에서 `Leave -> player 정보 갱신 -> EnterMapChange` 순서를 설명해보세요.

현재 방에서 먼저 `Leave`를 호출해 AOI와 룸 자료구조에서 플레이어를 제거합니다. 그다음 플레이어 객체의 `channelId`, `mapId`, `instanceId`, 위치 정보를 목적지 기준으로 갱신합니다. 이후 로비를 거쳐 새 방의 `EnterMapChange`를 호출해 새 룸에 등록하고, 거기서 완료 패킷과 스냅샷을 전송합니다.

6. `EnterMapChange`에서 `S_MAP_CHANGE_END`와 AOI full snapshot 전송 순서를 설명해보세요.

`EnterMapChange`는 먼저 `EnterRegister`로 플레이어를 방 자료구조에 등록합니다. 등록이 성공하면 즉시 `S_MAP_CHANGE_END`를 보내 전이 완료를 알리고, 그 다음 `UpdateAOI(forceFullSnapshot=true)`로 주변 몹과 플레이어 전체 스냅샷을 전송합니다. 이후 파티가 있으면 `S_PARTY_INFO_NTF`를 다시 보내 UI까지 맞춥니다.

7. 맵 전이 완료 후 세션 `SetCurrentRoom`, `EndMapChange` 호출 흐름을 설명해보세요.

새 방의 `EnterMapChange`가 끝나면, `TransferMapChangeById` 내부 Job 체인에서 세션 Actor로 다시 돌아옵니다. 세션은 `SetCurrentRoom(newRoom)`으로 현재 룸 참조를 확정하고, 이어서 `EndMapChange()`를 호출해 토큰과 pending 상태를 비우고 FSM을 `NONE`으로 돌립니다. 마지막으로 로비 Actor가 staging 상태의 플레이어를 `Detach`합니다.

8. 채널 변경 요청이 들어왔을 때 인스턴스 룸 차단까지의 흐름을 설명해보세요.

세션 핸들러는 먼저 맵 전이 중인지, `playerId`가 유효한지, 목표 채널이 양수인지 확인합니다. 이후 세션 Actor에서 현재 룸을 읽어 현재 채널과 동일하면 무시하고, `GameRoom::IsInstanceRoom()`이면 정책상 바로 차단합니다. 월드맵인 경우에만 룸 Actor에서 현재 좌표를 읽고, 그 좌표를 스폰으로 써서 `S_MAP_CHANGE_BEGIN`을 보내는 동일한 FSM 흐름으로 들어갑니다.

9. 던전에서 월드로 강제귀환할 때 `ForceReturnToWorld` 내부 흐름을 설명해보세요.

먼저 세션 Actor에서 현재 `playerId`와 현재 룸을 확인합니다. 현재 룸이 `GameRoom`이면 그 룸 Actor로 들어가 플레이어를 찾고, `MakeSafeReturn`으로 복귀 맵과 좌표를 계산합니다. 마지막으로 다시 세션 Actor로 돌아와 `SendMapChangeBegin`을 호출해 월드 복귀용 `S_MAP_CHANGE_BEGIN`을 발송합니다.

10. `MakeSafeReturn`이 잘못된 맵 ID를 보정하는 흐름을 설명해보세요.

우선 플레이어가 저장해 둔 `returnMapId`, `returnInstanceId`, `returnPos`를 읽습니다. 그 다음 `DataManager`로 맵 ID가 실제로 유효한지 검사하고, 유효하지 않거나 맵 설정을 찾을 수 없으면 기본 월드 맵 ID와 해당 스폰 좌표로 보정합니다. 이때 인스턴스 ID는 0으로 되돌려 월드 복귀 상태를 확정합니다.

11. 파티 생성 요청에서 `core.Create -> S_PARTY_RESULT -> BroadcastPartyInfo` 흐름을 설명해보세요.

파티 생성 요청은 세션에서 `IsMapChanging()`과 `leaderId`를 확인한 뒤 `PartyActor`로 넘어갑니다. `PartyActor`는 이미 파티 소속인지 확인하고, 아니면 `core.Create`로 새 파티를 만들고 version을 읽습니다. 그 결과를 요청자에게 `S_PARTY_RESULT`로 보내고, 성공했다면 `BroadcastPartyInfo`를 호출해 리더의 파티 UI를 최신 스냅샷으로 맞춥니다.

12. 파티 초대 요청에서 대상 해석/오프라인 차단/Invite 실행 순서를 설명해보세요.

먼저 세션 핸들러에서 초대자 ID를 확인하고, 패킷에 대상 ID가 없으면 이름 기반으로 온라인 유저를 해석합니다. 대상이 없거나 자기 자신이거나, 세션 매니저에서 오프라인으로 판단되면 바로 실패 응답을 보냅니다. 그 이후에만 `PartyActor`로 넘어가 초대자가 실제 파티원인지 확인하고 `core.Invite`를 실행한 뒤, 초대자에게 결과를 보내고 대상에게 `S_PARTY_INVITE_NTF`를 전송합니다.

13. 파티 초대 수락에서 `AcceptInvite` 성공 시 브로드캐스트 흐름을 설명해보세요.

수락 요청이 오면 `PartyActor`에서 `core.AcceptInvite(targetId, partyId, accept, after)`를 호출해 펜딩 초대와 현재 파티 상태를 동시에 검증합니다. 성공하면 먼저 요청자에게 `S_PARTY_RESULT`를 보내고, `accept=true`인 경우 새 파티 스냅샷 기준으로 `BroadcastPartyInfo(after.partyId)`를 실행합니다. 그래서 기존 멤버와 새 멤버가 같은 version의 파티 정보를 동시에 받게 됩니다.

14. 파티 탈퇴에서 `LeaveAndHandleInstance` 호출 후 결과 전송 흐름을 설명해보세요.

탈퇴 요청은 먼저 `PartyActor`에서 현재 파티와 던전 여부를 스냅샷으로 확보합니다. 그 후 `LeaveAndHandleInstance`가 파티에서 멤버를 제거하고, 필요하면 `EjectMember`, 빈 인스턴스 종료, `ClearPartyInstance`, `RequestForceReturnToWorld`까지 연쇄 처리합니다. 핸들러는 멤버 매핑이 실제로 사라졌는지 확인한 뒤 요청자에게 `S_PARTY_RESULT`를 보내고, 본인에게는 no-party 정보, 남은 멤버에게는 `BroadcastPartyInfo`를 보냅니다.

15. 파티 강퇴에서 `KickAndHandleInstance` 이후 강퇴 대상 후처리 흐름을 설명해보세요.

리더의 요청이 유효하면 `KickAndHandleInstance`가 먼저 파티 멤버 제거를 수행하고, 던전 안이었다면 인스턴스에서 대상 플레이어를 `EjectMember`로 제거합니다. 비어 버린 인스턴스면 닫고, 대상이 온라인이면 `ForceReturnToWorld`, 오프라인이면 `MarkForceReturn`을 기록합니다. 이후 리더에게 결과를 보내고, 남은 파티원에게는 새 파티 정보, 강퇴 대상에게는 no-party 알림을 전송합니다.

16. 파티 해산에서 멤버 snapshot을 먼저 잡는 이유와 흐름을 설명해보세요.

파티 해산이 성공하면 `core.Disband`가 파티 본문과 `_playerToParty` 매핑을 지워 버리기 때문에, 그 이후에는 멤버 목록을 안전하게 다시 읽기 어렵습니다. 그래서 해산 전에 `before.members`를 벡터로 백업해 두고, 해산 및 인스턴스 종료 처리 후 그 스냅샷을 기준으로 각 멤버에게 no-party 알림과 필요 시 강제귀환을 수행합니다.

17. 던전 입장 요청에서 PartyActor 검증 단계의 흐름을 설명해보세요.

세션과 현재 룸 검증이 끝난 뒤 `PartyActor`로 들어가면, 먼저 요청자가 실제 파티에 속해 있는지 확인합니다. 그다음 `GetDungeonInfo`로 현재 `instanceId`와 전이 중 여부를 확인해 이미 던전 내부이거나 전이 중인 경우를 차단합니다. 통과하면 `TryBeginDungeonTransition(ENTERING)`으로 파티 상태를 잠그고, 멤버 목록을 모아 다음 `InstanceActor` 단계로 넘깁니다.

18. 던전 입장에서 `TryBeginDungeonTransition(ENTERING)` 후 실패 시 원복 흐름을 설명해보세요.

입장 잠금까지는 성공했는데 `CreateOrGetForParty`가 실패하면, `PartyActor`로 다시 돌아가 `EndDungeonTransition(NONE)`과 `ClearPartyInstance`를 호출합니다. 이렇게 해서 파티가 전이 중 플래그에 갇히지 않게 풀고, instanceId도 0으로 정리합니다. 이후 요청자에게 `S_DUNGEON_ENTER_RES` 실패 응답을 보내고 흐름을 종료합니다.

19. 던전 입장에서 `CreateOrGetForParty` 성공 후 파티 상태 확정 흐름을 설명해보세요.

`InstanceActor`가 인스턴스를 만들거나 기존 것을 가져오면, 반환된 `instanceId`를 기준으로 다시 `PartyActor`가 실행됩니다. 여기서 `SetPartyInstance(partyId, instanceId, IN_DUNGEON)`으로 파티의 인스턴스 소속을 적고, `EndDungeonTransition(IN_DUNGEON)`으로 잠금을 해제하며 최종 상태를 확정합니다. 그 후 요청자에게 성공 응답을 보내고, 멤버 전원에게 실제 맵 전이 시작을 전파합니다.

20. 던전 입장 성공 후 파티원 전원 `SendMapChangeBegin` 전파 흐름을 설명해보세요.

성공이 확정되면 서버는 멤버 목록을 순회하면서 각 플레이어의 세션을 찾습니다. 세션이 살아 있으면 현재 룸 Actor로 들어가 `SaveReturnLocation_ActorOnly`를 호출해 복귀 지점을 저장하고, 현재 채널 정보를 읽어 다시 세션 Actor로 돌아와 `SendMapChangeBegin`을 보냅니다. 현재 룸을 찾지 못한 경우에도 최소한 기본 채널 값으로 `SendMapChangeBegin`을 보내 던전 진입을 시도합니다.

21. 던전 퇴장 요청에서 requester가 던전 내부인지 확인하는 흐름을 설명해보세요.

세션 Actor는 먼저 현재 룸이 `GameRoom`인지 확인합니다. 그 다음 해당 룸 Actor에서 플레이어를 실제로 찾고, `player->GetInstanceId()`가 0인지 아닌지를 검사합니다. 0이면 던전 내부가 아니므로 현재 맵/인스턴스 정보를 담아 `DUNGEON_EXIT_FAIL_NOT_IN_DUNGEON`으로 실패 응답을 보냅니다.

22. 던전 퇴장에서 `TryBeginDungeonTransition(EXITING)` 실패 시 종료 흐름을 설명해보세요.

`PartyActor`에서 파티를 찾은 뒤 `TryBeginDungeonTransition(EXITING)`에 실패했다는 것은 이미 다른 입·퇴장 트랜잭션이 진행 중이라는 의미입니다. 이 경우 추가 작업은 하지 않고, 요청자에게 `S_DUNGEON_EXIT_RES` 실패 응답을 보내며 종료합니다. 즉, 실패 시에는 현재 진행 중인 전이를 건드리지 않는 것이 원칙입니다.

23. 던전 퇴장에서 `CloseForParty` 실패 시 롤백 흐름을 설명해보세요.

`InstanceActor`가 `CloseForParty`에 실패하면 인스턴스 메타데이터가 닫히지 않았다는 뜻이므로, 파티를 월드 상태로 밀어버리면 안 됩니다. 그래서 `PartyActor`가 다시 실행돼 `EndDungeonTransition(IN_DUNGEON)`으로 상태를 원래 플레이 중 상태로 돌려놓습니다. 그 다음 요청자에게 실패 응답을 보내고, 기존 던전 플레이를 계속할 수 있게 둡니다.

24. 던전 퇴장에서 성공 후 `ClearPartyInstance -> EndDungeonTransition(NONE)` 흐름을 설명해보세요.

인스턴스가 정상적으로 닫히면 우선 룸에 `MarkClosing(true)`를 적용해 더 이상 새 입장을 받지 않게 합니다. এরপর `PartyActor`가 `ClearPartyInstance(partyId)`로 파티의 `instanceId`를 0으로 비우고, `EndDungeonTransition(NONE)`으로 던전 상태와 잠금을 모두 해제합니다. 이 시점에 파티는 다시 월드 기준의 안정 상태로 복귀합니다.

25. 던전 퇴장 성공 시 요청자 응답과 멤버 전송 흐름 차이를 설명해보세요.

요청자는 우선 `S_DUNGEON_EXIT_RES`를 받아 "퇴장 요청이 서버에서 승인되었고, 돌아갈 맵/인스턴스 정보가 무엇인지"를 먼저 알게 됩니다. 반면 실제 멤버 이동은 별도의 `MapChangeBegin` 흐름으로 진행됩니다. 즉, 응답 패킷은 결과 통지이고, 멤버 전송은 실제 물리적 위치 이동을 위한 후속 단계입니다.

26. `InstanceActor::TickTimeout`에서 만료 인스턴스 정리 흐름을 설명해보세요.

`TickTimeout`은 현재 시간을 기준으로 `CollectExpired`를 호출해 만료 후보 인스턴스를 모읍니다. 이후 각 인스턴스에 대해 `CloseForParty`로 논리 메타데이터를 닫고, 룸 매니저에서 해당 방을 찾아 `MarkClosing(true)`를 설정합니다. 실제 메모리 삭제는 여기서 끝내지 않고, 이후 `RoomManager::PurgeInstanceRooms`가 맡습니다.

27. `RoomManager::PurgeInstanceRooms`에서 선별/삭제 2단계 흐름을 설명해보세요.

1단계에서는 Read Lock 상태로 전체 룸을 순회하면서 `instanceId != 0`인 인스턴스 룸 중 `ShouldPurge(nowMs)`가 true인 키만 수집합니다. 2단계에서는 Write Lock으로 전환해 수집한 키를 다시 확인하고, 그 사이 상태가 변하지 않았다면 실제 `_rooms` 맵에서 삭제합니다. 이렇게 두 단계로 나눈 이유는 긴 쓰기 락을 피하면서도 최종 삭제 직전 재검증을 하기 위해서입니다.

28. 오프라인 유저 강제귀환 플래그가 로그인 시 소비되는 흐름을 설명해보세요.

`Handle_C_ENTER_GAME`가 들어오면 토큰 인증과 기본 입장 맵 보정을 먼저 수행합니다. 그 다음 `PartyActor`에서 `ConsumeForceReturn(playerId)`를 호출해 플래그를 확인하고, true면 최종 입장 맵을 기본 월드 맵과 그 스폰 좌표로 강제 교체합니다. 이후 세션은 이 보정된 맵을 pending enter로 저장하고 로비 입장 및 DB 로딩을 이어갑니다.

29. Part D에서 실패 수렴(`Cancel`/롤백) 지점을 전체 흐름으로 설명해보세요.

맵 전이 쪽은 세션 불일치, 룸 확보 실패, ACK 검증 실패 같은 예외가 모두 `CancelMapChange`로 수렴합니다. 던전 입장은 `TryBeginDungeonTransition` 이후 실패하면 `EndDungeonTransition(NONE)`과 `ClearPartyInstance`로 돌아가고, 던전 퇴장은 `CloseForParty` 실패 시 `IN_DUNGEON`으로 롤백합니다. 오프라인 강제귀환은 즉시 복구가 불가능하므로 ForceReturn 플래그를 남기고 로그인에서 회수하는 지연 수렴 경로를 사용합니다.

30. Part D 전체를 "요청 -> 가드 -> 상태 전이 -> 실행 -> 수렴" 관점으로 설명해보세요.

요청 단계에서는 맵 이동, 파티 변경, 던전 입퇴장 패킷이 들어옵니다. 가드 단계에서는 `IsMapChanging`, 맵 유효성, 리더 권한, `inDungeonTransition`, 현재 룸과 인스턴스 문맥을 검증합니다. 상태 전이 단계에서는 세션 FSM이나 파티 `DungeonState`를 먼저 잠그고, 실행 단계에서 `Leave/Enter`, `CreateOrGetForParty`, `CloseForParty`, `ForceReturn`을 수행합니다. 마지막 수렴 단계에서는 성공 시 `EndMapChange`, `EndDungeonTransition`, version 브로드캐스트로 확정하고, 실패 시 `CancelMapChange`나 롤백으로 안정 상태를 회복합니다.

## 5. 관련 자유 질문 (10문제)

1. Part D에서 본인이 가장 자신 있게 설명할 수 있는 설계 포인트는 무엇인가요?

저는 맵 전이 핸드셰이크와 세션 FSM을 가장 자신 있게 설명할 수 있습니다. 이유는 이 부분이 단순 이동 기능이 아니라, 네트워크 지연과 비동기 로딩이 들어와도 서버가 전이 경계를 잃지 않게 만드는 핵심 설계이기 때문입니다. 면접에서는 `BEGIN/ACK/END`, `TryBeginMapChange`, `TryConsumeMapChangeAck`, `Cancel/EndMapChange`를 묶어서 설명하겠습니다.

2. 면접에서 "왜 이렇게 복잡하게 만들었냐"는 질문에 어떻게 답하시겠습니까?

겉으로는 복잡해 보여도, 실제로는 동시성 때문에 반드시 분리해야 할 책임을 나눈 결과라고 답하겠습니다. 맵 전이는 세션이, 실제 플레이어 소속은 룸이, 멤버십은 파티가, 인스턴스 수명주기는 인스턴스 코어가 각각 소유해야 안전합니다. 단순한 코드보다 중요한 것은 중복 요청과 실패 상황에서 상태가 꼬이지 않는 구조였고, 그 목적 때문에 지금 구조를 선택했다고 설명하겠습니다.

3. 신입이 Part D를 빠르게 이해하려면 어떤 순서로 코드를 읽어야 한다고 보나요?

먼저 `docs/portfolio/section2/portfolio_temp_section2_part_d_concept_summary.md`와 `docs/portfolio/World_Room_Instance_Channel_Architecture.md`로 전체 개념을 잡는 게 좋습니다. 그다음 `PlayerSession`의 맵 전이 상태, `ClientPacketHandler.MapChange.cpp`, `GameRoom.MapChange.cpp`, `GameRoom.EnterLeave.cpp`를 읽어 맵 전이부터 이해합니다. 이후 `PartyManagerCore/PartyActor`, `ClientPacketHandler.Party.cpp`, `ClientPacketHandler.Dungeon.cpp`, `InstanceManagerCore`, `RoomManager::PurgeInstanceRooms` 순서로 보면 흐름이 자연스럽게 이어집니다.

4. 파티/인스턴스 협업 시 클라이언트 팀과 먼저 합의해야 할 계약은 무엇인가요?

첫째, 맵 전이는 `S_MAP_CHANGE_BEGIN`을 받은 뒤 로딩 완료 시점에 같은 토큰으로 `C_MAP_CHANGE_ACK`를 반드시 보내야 한다는 프로토콜 계약이 필요합니다. 둘째, 파티 UI는 `version` 기준으로 최신 스냅샷만 적용하고, 맵 전이 직후 `S_PARTY_INFO_NTF` 재전송을 받을 수 있다는 점을 합의해야 합니다. 셋째, 던전 입퇴장 성공 응답과 실제 맵 전이 시작 패킷은 별개일 수 있으므로, UI와 씬 전환 트리거를 분리해서 처리하기로 맞춰야 합니다.

5. Part D에서 가장 위험한 운영 이슈를 하나 꼽고 예방책을 설명해보세요.

가장 위험한 이슈는 "유저가 전이 중간 상태에 갇혀 이동도 안 되고 파티/던전 상태도 꼬이는 상황"이라고 생각합니다. 이 문제는 한 번 발생하면 유저 체감이 매우 크고, 수동 복구도 어렵습니다. 예방책으로는 세션 FSM 전이 로그, 맵 전이 토큰 추적, `CancelMapChange` 누락 감시, `inDungeonTransition` 장기 유지 알람, ForceReturn 플래그 대기 수 모니터링을 먼저 두겠습니다.

6. 로그 대시보드에 Part D 관련 지표 3개를 먼저 올린다면 무엇을 고르겠나요?

첫 번째는 맵 전이 `BEGIN -> ACK -> END`까지의 단계별 성공률과 지연 시간입니다. 두 번째는 파티 연산별 실패율과 version 증가 추이, 특히 `inDungeonTransition` 중 거절 건수입니다. 세 번째는 활성 인스턴스 수, closing 상태 인스턴스 수, purge 지연 시간 또는 ForceReturn 대기 인원 수입니다.

7. 장애 대응 중 "유저 이동 불가" 이슈를 받으면 어떤 우선순위로 대응하겠습니까?

가장 먼저 해당 세션의 맵 전이 상태가 `WAITING_ACK`나 `SWITCHING`에 멈춰 있는지 확인하겠습니다. 다음으로 마지막 `S_MAP_CHANGE_BEGIN` 토큰과 `C_MAP_CHANGE_ACK` 수신 여부, `TransferMapChangeById` 가드 실패 로그, `CancelMapChange` 또는 `EndMapChange` 호출 여부를 확인합니다. 원인이 세션 잠김이면 우선 수동 상태 해제로 복구하고, 이후 어떤 실패 경로에서 수렴이 누락됐는지 추적하겠습니다.

8. Part D 설계를 다른 게임 장르에 적용하려면 무엇을 바꿔야 할까요?

핵심 원리는 그대로 가져가되, 룸과 인스턴스의 의미를 장르에 맞게 다시 정의해야 합니다. 예를 들어 매치 기반 게임이라면 파티 대신 매치 로비와 매치 인스턴스가 중심이 되고, 오픈월드 MMO라면 지역 전이와 샤드 이동이 더 중요해집니다. 그래도 `요청 -> 가드 -> 상태 잠금 -> 실행 -> 수렴` 구조와 Actor 직렬화 철학은 그대로 적용 가능합니다.

9. 현재 구조를 리팩터링한다면 어떤 모듈을 먼저 분리하겠습니까?

저라면 `MapChange`와 `DungeonTransition`의 교차 오케스트레이션을 전담하는 코디네이터 모듈을 먼저 분리하겠습니다. 지금도 책임 자체는 나뉘어 있지만, 세션/룸/파티/인스턴스를 넘나드는 흐름이 여러 핸들러에 흩어져 있어서 디버깅 상관관계를 따라가기가 어렵습니다. 전이 컨텍스트와 correlation ID를 하나로 묶는 모듈이 있으면 운영성과 테스트성이 같이 좋아질 것 같습니다.

10. Part D 경험을 신입 면접 강점으로 표현한다면 어떤 메시지로 말하겠습니까?

저는 단순 기능 구현을 넘어서, 여러 도메인이 동시에 관여하는 상태 전이를 어떻게 안전하게 설계할지 고민해 본 경험이 있다는 점을 강점으로 말하겠습니다. 특히 맵 전이, 파티, 인스턴스처럼 서로 다른 소유권을 가진 상태를 Actor와 FSM, 롤백 경계로 수렴시킨 경험은 서버 프로그래머로서 좋은 출발점이라고 생각합니다.

## 6. 생길 수 있는 문제 관련 질문 (10문제)

1. 맵 전이 토큰 검증이 약하면 어떤 보안/정합성 문제가 발생할 수 있나요?

예전 ACK를 재전송해서 서버가 의도하지 않은 시점에 전이를 다시 실행하거나, 다른 세션의 응답을 재사용해 이동을 유발하는 문제가 생길 수 있습니다. 보안 측면에서는 replay에 취약해지고, 정합성 측면에서는 플레이어가 잘못된 맵으로 이동하거나 중복 전이되는 문제가 발생합니다.

2. `CancelMapChange` 누락 시 어떤 세션 잠김 현상이 생길 수 있나요?

실패한 전이가 `WAITING_ACK`나 `SWITCHING` 상태에 남으면 이후 모든 이동 요청이 `IsMapChanging()`에서 막히게 됩니다. 그 결과 유저는 포탈, 채널 이동, 던전 진입, 강제귀환 같은 전이 기능을 전부 사용하지 못하는 "영구 이동 불가" 상태에 빠질 수 있습니다.

3. `inDungeonTransition` 가드가 없으면 어떤 파티 상태 꼬임이 생길 수 있나요?

입장 도중 누군가 초대를 수락하거나 탈퇴하면, 파티 멤버 목록과 실제 인스턴스 멤버 목록이 다른 상태가 될 수 있습니다. 그 결과 어떤 유저는 파티에는 있는데 던전에는 없고, 다른 유저는 던전에 있는데 파티에는 없는 미아 상태가 생길 수 있습니다.

4. 파티 version 전송이 누락되면 클라이언트에 어떤 문제가 생기나요?

클라이언트는 어떤 스냅샷이 최신인지 구분할 기준을 잃게 됩니다. 그러면 늦게 도착한 예전 파티 정보가 최신 UI를 덮어써서 멤버 수, 리더, 던전 상태 표시가 실제 서버 상태와 다르게 보일 수 있습니다.

5. `CloseForParty`에서 역인덱스 정리를 빼먹으면 어떤 유령 상태가 생기나요?

대표적으로 플레이어가 이미 월드로 나왔는데 `_playerToInstance`에는 여전히 인스턴스 소속으로 남는 유령 상태가 생깁니다. 이렇게 되면 재접속 시 잘못된 던전 상태로 판단되거나, 다음 입장/퇴장 요청에서 이미 인스턴스에 있는 것으로 오판할 수 있습니다.

6. `MarkClosing`만 하고 purge가 안 돌면 어떤 리소스 문제가 생기나요?

사용이 끝난 인스턴스 룸 객체가 계속 `_rooms` 맵에 남아 메모리를 점유하게 됩니다. 시간이 지나면 빈 인스턴스 방이 누적돼 룸 탐색 비용과 주기적 업데이트 비용이 증가하고, 운영 측면에서는 "종료됐는데 안 사라지는 방"이 계속 쌓이는 문제가 발생합니다.

7. 던전 입장 중복 요청을 차단하지 않으면 어떤 중복 생성 문제가 생기나요?

같은 파티가 한 번의 입장 의도에 대해 여러 번 `CreateOrGetForParty`를 트리거할 수 있고, 보호가 약하면 서로 다른 `instanceId`가 만들어질 수 있습니다. 그러면 파티는 하나인데 실제 던전이 둘 이상 생기거나, 일부 멤버만 다른 인스턴스로 가는 심각한 분기 상태가 생깁니다.

8. 오프라인 강제귀환 플래그를 저장하지 않으면 어떤 복구 누락이 생기나요?

강퇴, 해산, 인스턴스 종료 시점에 오프라인인 유저는 즉시 이동시킬 방법이 없기 때문에, 플래그가 없으면 그 유저는 다음 로그인 때도 예전 던전 상태를 들고 들어올 수 있습니다. 즉, 온라인 유저는 정리됐는데 오프라인 유저만 과거 상태를 유지하는 복구 누락이 생깁니다.

9. `MakeSafeReturn`이 없으면 어떤 잘못된 복귀 좌표 문제가 생길 수 있나요?

저장된 귀환 맵이 삭제됐거나, 잘못된 인스턴스 ID가 남아 있거나, 스폰 좌표가 비정상이어도 그대로 복귀를 시도하게 됩니다. 그러면 존재하지 않는 맵으로 입장하려다 실패하거나, 월드로 나와야 할 유저가 예전 인스턴스 좌표를 그대로 물고 있어 다시 꼬일 수 있습니다.

10. 던전 퇴장 실패 롤백이 없으면 어떤 상태 반쯤 적용 문제가 생길 수 있나요?

예를 들어 인스턴스 종료는 실패했는데 파티 상태만 `EXITING`으로 남으면, 실제로는 던전에 있으면서도 더 이상 정상 플레이도 못 하고 재시도도 어려운 잠김 상태가 됩니다. 반대로 일부 매핑만 지우고 상태를 안 돌리면 파티/인스턴스/클라이언트가 서로 다른 현실을 보게 되는 반쯤 적용 상태가 생깁니다.

## 7. 트러블슈팅 관련 질문 (5문제)

1. "맵 이동이 가끔 끝나지 않는다" 제보가 오면 어떤 로그/상태부터 확인하시겠습니까?

첫 번째로 세션의 맵 전이 상태와 현재 토큰, pending 목적지 정보를 확인하겠습니다. 두 번째로 `S_MAP_CHANGE_BEGIN`이 나간 시각, 같은 토큰의 `C_MAP_CHANGE_ACK` 수신 여부, `TryConsumeMapChangeAck` 실패 사유를 확인하겠습니다. 세 번째로 `TransferMapChangeById`의 가드 실패 로그와 최종 `EndMapChange` 또는 `CancelMapChange` 호출 여부를 보면 어디에서 전이가 끊겼는지 빠르게 좁힐 수 있습니다.

2. "파티 UI가 멤버 수와 다르다" 이슈가 있을 때 version 관점에서 어떻게 진단하시겠습니까?

먼저 서버의 현재 파티 스냅샷 `version`과 클라이언트가 마지막으로 적용한 `version`을 비교하겠습니다. 클라이언트가 더 낮은 version을 들고 있으면 늦은 패킷 덮어쓰기나 브로드캐스트 유실 가능성을 의심해야 합니다. 반대로 서버 쪽 version 증가가 비정상적으로 누락됐다면, 특정 연산에서 `BroadcastPartyInfo` 또는 version 증가가 빠졌는지 확인하겠습니다.

3. "던전에서 나왔는데 다시 접속하면 던전 상태다" 문제를 어떤 인덱스 기준으로 추적하시겠습니까?

우선 `PartyManagerCore`의 `party.instanceId`와 `dungeonState`를 확인하고, `InstanceManagerCore`의 `_partyToInstance`, `_playerToInstance`에 해당 플레이어와 파티가 남아 있는지 보겠습니다. 그다음 ForceReturn 플래그가 기록됐는지, 로그인 시 `ConsumeForceReturn`이 실제로 소비됐는지도 같이 확인해야 합니다. 즉, 파티 상태, 인스턴스 역인덱스, 로그인 복구 경로를 한 세트로 추적해야 합니다.

4. "강퇴했는데 대상이 던전에 남아있다" 이슈의 점검 순서를 설명해보세요.

먼저 `core.Kick`이 실제로 성공해 파티 멤버 목록에서 대상이 빠졌는지 확인합니다. 그다음 `before.instanceId != 0` 조건에서 `InstanceActor::EjectMember`가 성공했는지, 비어 있으면 `CloseByInstanceId`와 `ClearPartyInstance`까지 갔는지 봅니다. 마지막으로 대상이 온라인이면 `RequestForceReturnToWorld`가 실행됐는지, 오프라인이면 `MarkForceReturn`이 남았는지와 현재 `expectedInstanceId` 검증에서 걸리지 않았는지를 확인합니다.

5. "인스턴스 방이 안 지워진다" 문제를 `MarkClosing -> ShouldPurge -> PurgeInstanceRooms` 기준으로 어떻게 확인하시겠습니까?

첫 단계는 해당 인스턴스 룸에 정말 `MarkClosing(true)`가 찍혔는지 확인하는 것입니다. 두 번째는 `ShouldPurge`가 false를 반환하는 이유를 보는데, 주로 아직 인원이 남았는지, `emptySinceMs`가 0인지, 유예 시간이 덜 지났는지를 확인합니다. 마지막으로 `PurgeInstanceRooms`가 주기적으로 돌고 있는지, 1차 선별과 2차 재검증에서 같은 조건을 통과해 실제 `_rooms`에서 제거됐는지를 확인하겠습니다.

## 8. 비교/대안 유형 질문 (20문제)

1. ACK 없는 즉시 맵 전이 방식과 토큰 핸드셰이크 방식을 비교해보세요.
2. 세션 FSM 방식과 단순 불리언 플래그 방식의 안정성을 비교해보세요.
3. Actor 직렬화와 락 기반 병렬 처리의 파티 정합성 차이를 비교해보세요.
4. Party version 동기화 방식과 전체 재조회 방식의 장단점을 비교해보세요.
5. 단일 pending invite와 다중 pending invite 설계의 차이를 비교해보세요.
6. 던전 전이 잠금(`inDungeonTransition`) 방식과 낙관적 재시도 방식의 차이를 비교해보세요.
7. `CreateOrGetForParty` 재사용 방식과 항상 신규 생성 방식의 차이를 비교해보세요.
8. party 기준 close와 instanceId 기준 close의 사용 시나리오 차이를 비교해보세요.
9. 즉시 room 삭제와 closing+grace purge 방식의 차이를 비교해보세요.
10. 온라인 즉시 강제귀환과 오프라인 플래그 복구의 트레이드오프를 비교해보세요.
11. `MapChangeUtil` 공통화 방식과 핸들러별 중복 구현 방식의 차이를 비교해보세요.
12. 로비 경유 전이와 direct room enter 방식의 장단점을 비교해보세요.
13. 월드맵 채널 이동 허용과 인스턴스 채널 이동 허용 정책을 비교해보세요.
14. 파티 해산 시 일괄 종료와 멤버별 분리 종료 전략을 비교해보세요.
15. 인스턴스 timeout 기반 정리와 수동 종료 전용 방식의 차이를 비교해보세요.
16. force return 시 기본맵 고정 복귀와 마지막 안전 좌표 복귀 전략을 비교해보세요.
17. 파티 리더 위임(최소 ID) 방식과 명시적 우선순위 방식의 차이를 비교해보세요.
18. 요청-응답 중심 전이 제어와 이벤트 소싱 기반 전이 제어를 비교해보세요.
19. Part D 구조를 싱글 서버와 멀티 샤드 환경에서 비교해보세요.
20. 현재 Actor 체인 방식과 중앙 오케스트레이터 서비스 방식의 차이를 비교해보세요.

## 9. 한계/개선점 유형 질문 (10문제)

1. Part D 구조에서 가장 큰 한계를 하나 고르고 개선안을 설명해보세요.

가장 큰 한계는 전이 오케스트레이션이 여러 핸들러와 Actor 사이에 흩어져 있어서, 한 건의 맵 전이나 던전 트랜잭션을 한눈에 추적하기 어렵다는 점입니다. 개선하려면 맵 전이와 던전 전이를 위한 공통 `transition context`와 correlation ID를 도입하고, 시작부터 종료까지 같은 문맥 객체로 추적되게 만드는 것이 좋습니다.

2. 맵 전이 FSM 관측성(로그/메트릭)이 부족할 때 어떤 개선이 필요할까요?

최소한 `NONE -> WAITING_ACK -> SWITCHING -> NONE` 전이마다 토큰, 플레이어 ID, 대상 맵, 실패 이유를 구조화 로그로 남겨야 합니다. 메트릭으로는 BEGIN 발급 수, ACK 성공률, `WAITING_ACK` 체류 시간, `CancelMapChange` 사유별 카운트를 추가하면 좋습니다. 특히 일정 시간 이상 `WAITING_ACK`에 머문 세션을 자동 경고로 잡아내는 것이 운영상 큰 도움이 됩니다.

3. 파티 version 기반 동기화의 한계와 보완 전략을 제시해보세요.

`version`만으로는 "어떤 변경이 있었는지"까지는 설명하지 못하고, 중간 패킷이 유실됐을 때 왜 차이가 났는지도 직접 알려주지 못합니다. 그래서 version은 최신성 판단용으로만 쓰고, 보완 전략으로는 전체 스냅샷 재전송, version gap 감지 시 강제 재조회, 필요하면 스냅샷 해시나 변경 사유 코드를 함께 내려주는 방식을 고려할 수 있습니다.

4. `inDungeonTransition` 단일 플래그 모델의 한계와 세분화 상태 모델 개선안을 설명해보세요.

현재는 전이 중인지 아닌지만 표현하므로, "인스턴스 생성 대기", "맵 전이 패킷 전파 중", "종료는 됐지만 강제귀환 대기 중" 같은 세부 단계를 구분하기 어렵습니다. 개선하려면 `ENTER_PREPARE`, `INSTANCE_ALLOCATED`, `MAPCHANGE_BROADCASTED`, `EXIT_CLOSE_PENDING`, `FORCE_RETURN_PENDING`처럼 더 잘게 나눈 상태 모델을 두고, 각 단계별 타임아웃과 로그를 붙이는 것이 좋습니다.

5. Instance timeout 정책 고정값(30분)의 한계와 동적 정책 개선안을 제시해보세요.

고정 30분 정책은 짧은 던전에는 너무 길고, 긴 레이드형 콘텐츠에는 너무 짧을 수 있습니다. 더 큰 문제는 현재 구현이 `createdTick` 중심이라 실제 활동 여부를 반영하지 못한다는 점입니다. 개선하려면 던전 타입별 기본 TTL, `lastActiveTick`, 현재 인원 수, 보스 전투 여부를 반영한 동적 만료 정책으로 바꾸는 것이 적절합니다.

6. `ForceReturn` 플래그의 지속성 보장(재시작/장애) 측면 한계와 개선안을 설명해보세요.

현재 구조에서 ForceReturn 플래그는 메모리 기반이라 서버 재시작이나 프로세스 장애가 나면 유실될 수 있습니다. 이렇게 되면 오프라인 유저 복구가 누락됩니다. 개선하려면 Redis나 DB에 durable flag로 저장하고, 로그인 시 `consume`을 원자적으로 수행하는 방식으로 바꾸는 것이 안전합니다.

7. Actor 체인 길이가 길어질 때 디버깅 난이도 한계를 어떻게 완화할지 설명해보세요.

세션 -> 룸 -> 파티 -> 인스턴스 -> 다시 세션 같은 체인이 길어질수록 어느 단계에서 끊겼는지 찾기가 어려워집니다. 이를 완화하려면 각 단계가 같은 transition ID를 로그에 남기게 하고, 구조화 로그와 trace span처럼 흐름을 이어 볼 수 있는 도구를 도입해야 합니다. 또한 단계별 성공/실패 콜백을 표준화하면 디버깅 지점이 눈에 잘 들어옵니다.

8. Room purge 조건의 한계(오탐/미탐)를 줄이기 위한 개선 포인트는 무엇인가요?

현재 조건은 `instance room`, `closing`, `player count 0`, `emptySince + grace` 네 가지에 주로 의존합니다. 이 모델은 남은 Job이나 지연 참조를 직접 반영하지 못해 오탐 또는 미탐 가능성이 있습니다. 개선하려면 active Job 수, 마지막 네트워크 이벤트 시각, 참조 카운트, explicit room lifecycle phase를 함께 고려하는 다층 조건으로 확장하는 것이 좋습니다.

9. 던전 입퇴장 실패 롤백 코드 중복의 한계를 어떻게 정리할지 설명해보세요.

지금은 실패 시 `EndDungeonTransition`, `ClearPartyInstance`, 실패 응답 전송 같은 패턴이 여러 군데에 반복됩니다. 이 중복은 빠뜨리기 쉬운 지점을 만들고, 나중에 정책이 바뀌면 수정 누락 위험도 커집니다. `DungeonTransitionGuard` 같은 공통 헬퍼를 만들어 성공 시 commit, 실패 시 자동 rollback 되도록 정리하면 훨씬 안전해집니다.

10. 멀티 리전/멀티 샤드 확장 시 Part D 설계의 한계와 확장 방향을 설명해보세요.

현재 설계는 세션, 파티, 인스턴스가 한 서버 메모리 안에 있다는 가정이 강합니다. 멀티 샤드로 가면 `partyId -> instanceId`, `playerId -> instanceId` 같은 매핑을 로컬 메모리에만 둘 수 없고, 샤드 간 라우팅과 일관성 문제가 새로 생깁니다. 확장 방향은 샤드 인식 가능한 ID 체계, 중앙 또는 분산 파티/인스턴스 메타 서비스, 샤드 간 전이 프로토콜을 도입하는 것입니다.

## 10. CS 기초와의 연결 고리 (The CS Bridge) 질문 (10문제)

1. Part D의 Actor 모델을 운영체제 스케줄링/동시성 관점에서 설명해보세요.

Actor 모델은 공유 메모리를 여러 스레드가 동시에 직접 수정하는 대신, 메시지나 Job 단위로 일을 넘겨 한 번에 하나씩 처리하는 방식입니다. 운영체제 관점에서 보면 여러 워커 스레드가 큐에 쌓인 작업을 스케줄링하지만, 각 Actor 내부에서는 사실상 cooperative single-thread execution처럼 동작합니다. 그래서 락 경합을 줄이고, 임계구역을 "큐"라는 논리적 경계로 치환한 설계라고 설명할 수 있습니다.

2. 맵 전이 FSM을 상태기계 이론 관점으로 모델링해 설명해보세요.

맵 전이 FSM은 상태 집합 `{NONE, WAITING_ACK, SWITCHING}`와 입력 집합 `{REQ 승인, ACK 수신, 성공 종료, 실패 취소}`를 가지는 유한 상태 기계입니다. 유효한 전이는 `NONE -> WAITING_ACK -> SWITCHING -> NONE`뿐이고, 이 경로 밖의 입력은 모두 거부됩니다. 즉, 잘못된 전이를 아예 정의하지 않음으로써 비정상 상태를 차단하는 결정적 상태기계입니다.

3. 토큰 검증을 네트워크 프로토콜의 idempotency/재전송 제어 관점에서 설명해보세요.

토큰은 각 맵 전이 요청에 대한 unique request ID 역할을 합니다. 같은 토큰의 ACK는 세션이 `WAITING_ACK`일 때 단 한 번만 소비되므로, 네트워크 재전송이나 중복 ACK가 와도 전이가 여러 번 실행되지 않습니다. 이런 의미에서 토큰 검증은 idempotency key와 비슷한 역할을 한다고 볼 수 있습니다.

4. 파티 version을 낙관적 동시성 제어(OCC) 관점으로 설명해보세요.

OCC에서는 여러 참여자가 락 없이 읽고 작업하되, commit 시점에 버전이나 변경 여부를 비교해 충돌을 감지합니다. 파티 `version`도 비슷하게, 클라이언트가 파티 상태를 읽고 나중에 더 최신 version이 왔는지 비교함으로써 stale UI를 감지하는 기준이 됩니다. 즉, 강한 락 대신 "버전이 다르면 내가 본 상태가 오래됐다"는 방식으로 최신성을 판별하는 구조입니다.

5. `partyId->instanceId`, `playerId->instanceId` 역인덱스를 자료구조 관점에서 설명해보세요.

이 구조는 정규화된 단일 테이블 대신 조회 성능을 위해 역인덱스를 추가한 해시 맵 설계입니다. 쓰기 시에는 여러 맵을 함께 갱신해야 하는 비용이 있지만, 읽기 시에는 파티 기준 조회와 플레이어 기준 조회를 모두 O(1)에 가깝게 처리할 수 있습니다. 결국 읽기 최적화를 위해 의도적으로 중복 인덱스를 둔 전형적인 trade-off입니다.

6. 인스턴스 timeout 정리를 가비지 컬렉션/수명주기 관리 관점으로 설명해보세요.

인스턴스는 생성된 뒤 일정 조건이 되면 더 이상 유효하지 않은 객체가 됩니다. `CollectExpired`가 종료 후보를 찾는 단계라면, `CloseForParty`는 논리 삭제, `MarkClosing`은 소멸 예정 마킹, `PurgeInstanceRooms`는 실제 메모리 회수 단계라고 볼 수 있습니다. 즉, mark-and-sweep에 가까운 다단계 수명주기 관리 모델입니다.

7. ForceReturn 플래그를 분산 시스템의 eventual consistency 관점으로 설명해보세요.

오프라인 유저는 지금 당장 수정할 수 없는 replica처럼 볼 수 있습니다. 이때 즉시 일관성을 강제할 수 없으니, "다음에 이 엔티티를 관측하면 월드 상태로 맞춘다"는 의도를 플래그로 저장해 둡니다. 그리고 로그인 시점에 그 플래그를 소비하면서 최종 상태를 맞추므로, 지연은 있지만 결국 일관된 상태로 수렴하는 eventual consistency 패턴입니다.

8. `CloseForParty`와 롤백 처리를 트랜잭션 경계 관점으로 설명해보세요.

`CloseForParty`는 파티 기준 인스턴스 종료를 하나의 논리 트랜잭션처럼 취급하는 경계입니다. 종료가 성공하면 파티/플레이어/인스턴스 매핑을 함께 정리해 commit하고, 실패하면 파티 상태를 `IN_DUNGEON`으로 되돌려 이전 안정 상태를 복원합니다. 즉, 부분 성공을 허용하지 않고 stable state between transitions를 유지하는 작은 트랜잭션 경계로 볼 수 있습니다.

9. Room purge의 grace period를 시스템 안정성(플랩 방지) 관점으로 설명해보세요.

유예 시간 없이 빈 방을 즉시 지우면, 짧은 네트워크 지연이나 재입장 시도만으로도 "삭제 -> 재생성 -> 삭제"가 반복되는 플랩이 생길 수 있습니다. grace period는 이런 순간적인 변동을 흡수하는 완충 구간입니다. 시스템 안정성 관점에서는 불필요한 생성/삭제 진동을 줄이고, 늦은 Job이나 패킷이 안전하게 소진될 시간을 주는 역할을 합니다.

10. Part D 전체를 "동시성 제어 + 상태 수렴" 문제로 추상화해 설명해보세요.

Part D의 본질은 여러 입력이 동시에 들어오는 환경에서 공유 상태를 어떻게 안전하게 바꿀지에 대한 문제입니다. 이를 위해 이 프로젝트는 Actor 큐로 쓰기 경합을 줄이고, FSM과 transition flag로 유효한 상태 전이만 허용하며, 실패 시에는 cancel이나 rollback, force-return으로 다시 안정 상태로 모읍니다. 결국 핵심은 "허용된 순서만 실행하고, 나머지는 거부하거나 되돌려서 항상 하나의 정상 상태로 수렴시킨다"는 동시성 제어 문제로 볼 수 있습니다.
