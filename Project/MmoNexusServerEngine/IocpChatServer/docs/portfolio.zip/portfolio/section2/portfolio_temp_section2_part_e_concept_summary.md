# Section2 Part E 개념 정리 (면접 대비용)

기준 문서: `portfolio_temp_section2.html`의 Part E(거래 원자성 보장과 실패 수렴 검증)

## Part E 핵심 개념 정리 (면접 대비용)

이 문서는 Part E를 실제 코드 기준으로 정리한 학습 노트입니다.  
목표는 "이 문서만으로 거래 상태머신, 원자성 보장 방식, 실패 수렴 경로"를 설명할 수 있게 만드는 것입니다.

### 0) 30초 요약

- 핵심 문제: 거래는 두 플레이어 자산이 동시에 바뀌어야 해서, 중간 실패 시 한쪽만 반영되면 치명적이다.
- 핵심 해법: `Invited -> Active -> Locked -> Committing` 상태머신으로 입력을 통제하고, 커밋 직전 메모리 계획(Phase 1) + DBAgent 단일 SQL 트랜잭션(Phase 2)으로 확정한다.
- 핵심 가드:
`Committing 중 취소 금지`, `requestId stale 응답 무시`, `commitPlan 존재 검증`.
- 핵심 수렴:
실패는 `CancelTrade_ActorOnly`로 공통 종료, 성공만 메모리/Redis/클라 델타 반영 후 세션 정리.

### 1) Part E에서 다루는 범위

- 거래 요청~수락~오퍼 변경~준비~확정까지 상태 제어.
- 커밋 전 검증/시뮬레이션(인벤, 골드, 슬롯, 스택 병합).
- DBAgent의 단일 트랜잭션 반영.
- DB 응답 후 성공/실패/무효 응답 처리.
- 타임아웃/맵전이/접속종료/내부 오류의 강제 취소 수렴.

### 2) 코드 구조

#### 2-1. 핵심 파일

- 거래 로직 본체:
`GameServer/GameRoom.Trade.cpp`
- 거래 상태/데이터 구조:
`GameServer/GameRoom.h` (`TradeState`, `TradeSession`, `TradeCommitPlan`)
- 클라 패킷 진입:
`GameServer/ClientPacketHandler.Trade.cpp`
- S2S 응답 라우팅:
`GameServer/S2SPacketHandler.cpp` (`Handle_S2S_RES_TRADE_COMMIT`)
- DB 트랜잭션 처리:
`DBAgent/DBAgentPacketHandler.cpp` (`Handle_S2S_REQ_TRADE_COMMIT`)
- 맵 전이/접속 종료 시 거래 취소:
`GameServer/GameRoom.MapChange.cpp`, `GameServer/GameRoom.EnterLeave.cpp`

#### 2-2. 실행 컨텍스트

- 클라 입력은 `PostRoom -> gr->Push`를 거쳐 `GameRoom` Actor에서 직렬 처리.
- DB 응답도 `FindRoom(channel,map,instance)` 후 해당 room queue로 되돌려 처리.

핵심:
거래 상태 변경은 모두 `GameRoom` 한 큐에서 실행되어 레이스를 줄인다.

### 3) 거래 상태머신

`TradeState`:

1. `None`
2. `Invited`
3. `Active`
4. `Locked`
5. `Committing`

#### 상태 의미

- `Invited`:
초대 대기. 수락/거절만 가능.
- `Active`:
아이템/골드 제안 수정 가능.
- `Locked`:
양측 ready 완료. 제안 수정 불가, confirm만 가능.
- `Committing`:
DB 결과 대기. 취소/변경 불가.

#### 전이 핵심

- 초대 수락 -> `Invited -> Active`
- 양측 ready true -> `Active -> Locked`
- 양측 confirm true -> `Locked -> Committing`
- 성공/실패 종료 -> 세션 삭제(`_trades.erase`)

### 4) 요청 단계별 처리

#### 4-1. 거래 요청 (`HandleTradeReqById`)

주요 가드:

- 자기 자신 거래 금지
- 대상 존재 확인
- 대상 `IsMapChanging()` 차단
- 양쪽 `ActiveTradeId == 0` 확인(중복 거래 금지)
- 거리 제한(`PassDistance2D`, 250.f)

통과 시:

- `tradeId` 발급
- `TradeSession` 생성(`state=Invited`)
- `_tradeByPlayer` 양방향 매핑
- 양쪽 `ActiveTradeId` 설정
- 상대에게 `S_TRADE_INVITE`

#### 4-2. 초대 응답 (`HandleTradeInviteRespById`)

- `state == Invited` 강제
- 응답자는 반드시 B(playerBId)
- 거절 시 `CancelTrade_ActorOnly(...DECLINED...)`
- 수락 시 `state=Active`, ready/confirm false 초기화
- 양측 `S_TRADE_START` 전송

#### 4-3. 오퍼/골드 변경 (`HandleTradeOfferSetById`, `HandleTradeGoldSetById`)

- `state == Active`에서만 허용
- 아이템 유효성:
존재, 장착 아님, 수량 충분
- 골드 유효성:
0 이상, 보유 골드 이하

변경 시 공통:

- `readyA/B=false`, `confirmA/B=false` 재설정
- `S_TRADE_OFFER_UPDATE`, `S_TRADE_READY_STATE` 전송

의미:
변경 후 기존 동의 상태를 무효화해 사기성 확정 방지.

#### 4-4. Ready/Confirm (`HandleTradeReadyById`, `HandleTradeConfirmById`)

- Ready:
둘 다 true면 `state=Locked` + `S_TRADE_LOCKED`.
- Confirm:
`state==Locked`에서만 가능.
양측 confirm true면 `state=Committing` 후 커밋 시작.

### 5) 취소/타임아웃 수렴

#### 5-1. 취소 요청

`HandleTradeCancelById`:

- 본인 거래인지 검증
- `Committing`이면 취소 무시(중요)
- 그 외 상태는 `CancelTrade_ActorOnly`

#### 5-2. 공통 취소 (`CancelTrade_ActorOnly`)

동작:

1. `S_TRADE_CANCELLED` 양측 전송
2. 필요시 `S_TRADE_RESULT(success=false, failCode,msg)` 전송
3. `_tradeByPlayer` 정리
4. 양측 `ActiveTradeId = 0`
5. `_trades.erase`

#### 5-3. 타임아웃 (`UpdateTrades_ActorOnly`)

- `kTradeTimeoutMs = 60,000ms`
- `Committing` 상태는 timeout 제외
- 만료 시 `TRADE_CANCEL_TIMEOUT` 취소

### 6) 원자성 설계: Phase 1 + Phase 2

#### 6-1. Phase 1 (GameServer): 계획 수립

함수: `BuildTradeCommitPlan_ActorOnly`

핵심:
실제 데이터를 직접 바꾸지 않고 snapshot 복사본으로 시뮬레이션.

검증 항목:

- 거래 세션/플레이어 존재
- 골드 음수/부족/오버플로
- 제안 아이템 재검증(존재/장착/수량)

시뮬레이션 단계:

1. 주는 쪽 아이템 차감/삭제
2. 받는 쪽 아이템 추가(스택 병합 우선)
3. 빈 슬롯 할당(최대 24 슬롯)
4. 새 아이템 UID 발급(`GameItemUidGen::Alloc()`)

산출물(`TradeCommitPlan`):

- `finalAItems/finalBItems` (최종 스냅샷)
- `deletedAItemUids/deletedBItemUids`
- `finalGoldA/finalGoldB`
- 클라 델타용 `notifyChange*`, `notifyRemove*`

실패 시:
DB 요청 없이 즉시 실패 반환.

#### 6-2. Phase 2 (GameServer -> DBAgent): DB 트랜잭션

함수: `StartTradeCommitPhase2_ActorOnly`

순서:

1. `commitPlan` 중복 in-flight 가드
2. Phase 1 성공 결과를 `ts->commitPlan`에 저장
3. `S2S_REQ_TRADE_COMMIT` 구성
4. `commitRequestId` 발급/세팅
5. DB 세션으로 전송

S2S 요청에 포함되는 핵심:

- trade/channel/map/instance
- playerA/B
- final gold
- 최종 아이템 스냅샷 + 삭제 목록
- `requestId`

### 7) DBAgent 단일 트랜잭션 처리

함수: `DBAgentPacketHandler::Handle_S2S_REQ_TRADE_COMMIT`

트랜잭션 흐름:

1. `BEGIN TRAN`
2. A delete
3. A upsert
4. B delete
5. B upsert
6. A/B gold update
7. 성공 `COMMIT`, 실패 `ROLLBACK`
8. `S2S_RES_TRADE_COMMIT(success, failCode, requestId)` 응답

핵심:
한 트랜잭션 경계에서 양측 자산을 함께 반영해 부분 성공을 차단.

### 8) 커밋 응답 처리 (GameServer)

함수: `OnTradeCommitResult_ActorOnly`

가드 순서:

1. 거래 세션 존재
2. `state == Committing`
3. `requestId` 일치(불일치면 stale 응답 무시)
4. `commitPlan` 존재

실패 응답:

- `CancelTrade_ActorOnly(...TRADE_CANCEL_INTERNAL...)`

성공 응답:

1. 플레이어 메모리 인벤/골드 반영
2. Redis/Persistence 동기화 (`markDirty=false`)
3. `S_GOLD_UPDATE`, `S_REMOVE_ITEM`, `S_CHANGE_ITEM` 전송
4. 양측 `S_TRADE_RESULT(success=true)`
5. 거래 세션/매핑 정리

### 9) Part E 핵심 불변조건

1. `Active`가 아니면 offer/gold 변경 불가.
2. `Locked`가 아니면 confirm 불가.
3. `Committing` 중 사용자 취소 불가.
4. DB 요청은 Phase 1 검증 통과 시에만 발행.
5. DB 응답은 `requestId` 일치 시에만 적용.
6. 성공 시 양측 자산을 함께 반영하고, 실패 시 둘 다 취소 수렴.
7. 거래 종료 시 `_tradeByPlayer`와 `ActiveTradeId`를 반드시 함께 정리.

### 10) 맵 전이/접속 종료와 거래 연계

- 맵 전이 시작:
`TransferMapChangeById`에서 `TRADE_CANCEL_MAP_CHANGE` 취소.
- 룸 이탈/접속 종료:
`Leave` 경로에서 `TRADE_CANCEL_DISCONNECT` 취소.
- 클라 패킷 진입:
`ClientPacketHandler.Trade.cpp`에서 `IsMapChanging()` 가드.

의미:
거래와 위치 전이가 동시에 진행돼 상태가 꼬이는 케이스를 앞단에서 차단.

### 11) 자주 받는 질문 답변 프레임

#### Q1. 왜 Committing 상태에서 취소를 막나요?

- 한 줄 답:
"DB 트랜잭션 결과를 기다리는 중에 메모리 취소를 허용하면 성공/실패 상태가 분리돼 자산 불일치가 발생할 수 있기 때문입니다."

#### Q2. 2단계 커밋이라 했는데 실제로 무엇이 2단계인가요?

- 한 줄 답:
"1단계는 GameServer 메모리 시뮬레이션으로 계획을 확정하고, 2단계는 DBAgent 단일 SQL 트랜잭션으로 실제 반영하는 구조입니다."

#### Q3. stale 응답은 어떻게 처리하나요?

- 한 줄 답:
"trade별 `commitRequestId`를 저장해 응답 `requestId`와 다르면 무시합니다."

#### Q4. 부분 성공은 어떻게 막나요?

- 한 줄 답:
"DB에서는 BEGIN/COMMIT/ROLLBACK 단일 경계를 사용하고, 서버는 성공 응답에서만 메모리 반영을 수행합니다."

#### Q5. 거래 중 사기성 변경은 어떻게 막나요?

- 한 줄 답:
"offer/gold 변경 시 ready/confirm 상태를 즉시 초기화해서 최종 동의 과정을 다시 밟게 합니다."

### 12) 디버깅 체크리스트

- 상태 꼬임:
`tradeId`, `state`, `readyA/B`, `confirmA/B` 순서 확인.
- 커밋 유실:
`state=Committing`, `commitPlan`, `commitRequestId`, S2S 송수신 확인.
- stale 응답:
응답 `requestId`와 `ts->commitRequestId` 비교 로그 확인.
- 부분 반영 의심:
DBAgent `BEGIN/COMMIT/ROLLBACK` 로그 + GameServer 성공 반영 로그 대조.
- 시간초과 이슈:
`lastTouchedMs`, `kTradeTimeoutMs`, `UpdateTrades_ActorOnly` 실행 주기 확인.
- 맵 전이 충돌:
`TRADE_CANCEL_MAP_CHANGE` 발생 경로 확인.

### 13) 면접 직전 암기 포인트

- "거래 입력은 상태머신으로 제한한다: Invited/Active/Locked/Committing."
- "커밋 전에는 snapshot 시뮬레이션(Phase 1), 커밋은 DB 단일 트랜잭션(Phase 2)."
- "Committing 중 취소 금지 + requestId 매칭으로 무결성 확보."
- "실패는 공통 취소 수렴, 성공만 메모리/Redis/클라 델타 반영."
- "맵 전이/접속 종료 시 거래를 강제 취소해 상태 꼬임을 차단."

---

## Part E 면접 질문 세트 (총 170문제)

## 1. 기본 개념 문제 (35문제)

1. 거래 시스템에서 "원자성"이 왜 중요한가요?

거래는 두 플레이어의 아이템과 골드가 동시에 바뀌는 작업이라서, 한쪽만 반영되고 다른 쪽은 실패하면 곧바로 복사나 소실 같은 치명적인 데이터 오류가 생깁니다. 그래서 Part E에서는 "둘 다 성공하거나 둘 다 아무 일도 없거나"만 허용되도록 원자성을 핵심 목표로 둡니다.

2. Part E 거래 상태머신의 상태 5개를 말해보세요.

`None`, `Invited`, `Active`, `Locked`, `Committing`입니다. 각각 거래 없음, 초대 대기, 제안 수정 가능, 제안 잠금, DB 커밋 대기 상태를 의미합니다.

3. `Invited` 상태에서는 어떤 입력만 허용되나요?

초대를 받은 대상 플레이어 B의 수락 또는 거절만 허용됩니다. 아직 실제 거래창이 열린 상태가 아니기 때문에 오퍼 변경, 골드 입력, Ready, Confirm 같은 입력은 모두 허용되면 안 됩니다.

4. `Active` 상태의 목적은 무엇인가요?

`Active`는 실제 협상 구간입니다. 양측이 아이템과 골드를 올리고 내리면서 거래 조건을 정하는 단계이고, 이 단계에서만 오퍼 수정과 Ready 변경이 가능하도록 제한해 상태를 명확히 나눕니다.

5. `Locked` 상태는 어떤 의미를 가지나요?

양측이 모두 Ready를 눌러서 "이제 제안 내용은 더 이상 수정하지 않는다"는 합의가 끝난 상태입니다. 즉, 조건이 고정된 상태에서 최종 Confirm만 남은 단계라고 보면 됩니다.

6. `Committing` 상태에서 입력 제한이 필요한 이유는 무엇인가요?

이 구간은 이미 DB에 반영 요청을 보낸 뒤 결과를 기다리는 단계이기 때문에, 사용자 취소나 제안 변경을 허용하면 메모리 상태와 DB 결과가 갈라질 수 있습니다. 그래서 Part E는 `Committing`에서 사실상 모든 사용자 입력을 막고 결과 수신만 기다리게 합니다.

7. `HandleTradeReqById`의 핵심 검증 항목을 설명해보세요.

핵심 검증은 자기 자신 거래 금지, 양쪽 플레이어 존재 확인, 대상의 `IsMapChanging()` 여부, 양쪽 `ActiveTradeId == 0` 여부, 그리고 거리 제한 250.f 통과 여부입니다. 이 검증을 통과해야만 `tradeId`를 발급하고 `Invited` 상태의 거래 세션을 생성합니다.

8. `ActiveTradeId_ActorOnly`는 어떤 역할을 하나요?

각 플레이어가 현재 어떤 거래에 묶여 있는지 나타내는 per-player 잠금 표식입니다. 이 값이 0이 아니면 이미 다른 거래에 참여 중이라는 뜻이므로 중복 거래를 차단할 수 있고, 종료 시에는 `_tradeByPlayer`와 함께 반드시 정리해야 유령 거래 상태가 남지 않습니다.

9. 거래 요청에서 거리 검증을 하는 이유는 무엇인가요?

먼 거리에 있는 플레이어와 자유롭게 거래하게 두면 원격 거래 악용이나 비정상 상황을 만들기 쉽습니다. 이 프로젝트에서는 같은 룸 안에서 실제로 가까이 있는 플레이어끼리만 거래하도록 제한해, 서버 권위 상호작용이라는 전제를 유지합니다.

10. 거래 요청 시 대상의 `IsMapChanging()`을 체크하는 이유는 무엇인가요?

맵 전이 중인 대상은 곧 방을 떠나거나 세션 상태가 바뀔 수 있어서, 거래를 시작해도 안정적으로 이어질 가능성이 낮습니다. 그래서 전이 중인 상대는 아예 진입 단계에서 차단해 거래와 위치 전이가 겹쳐 꼬이는 상황을 미리 막습니다.

11. `HandleTradeInviteRespById`에서 수락 시 발생하는 상태 전이는 무엇인가요?

`Invited -> Active` 전이가 일어납니다. 이때 ready/confirm 플래그를 모두 false로 초기화하고, 양측에게 `S_TRADE_START`를 보내 실제 거래창을 열게 합니다.

12. 오퍼 변경 시 ready/confirm를 초기화하는 이유는 무엇인가요?

이미 동의했던 조건이 바뀌었기 때문입니다. 변경 후에도 기존 Ready나 Confirm를 유지하면, 상대가 새로운 제안을 제대로 다시 확인하지 못한 채 거래가 확정될 수 있어서 사기성 변경에 취약해집니다.

13. 골드 제안에서 음수/초과 금액을 차단하는 이유는 무엇인가요?

음수 금액은 계산식 자체를 깨뜨리고, 보유 골드 초과는 서버 자산보다 더 많은 값을 약속하는 잘못된 상태를 만듭니다. 이 둘을 서버에서 다시 검증해야 underflow, overflow, 자산 위조 같은 문제를 막을 수 있습니다.

14. `S_TRADE_OFFER_UPDATE` 패킷은 어떤 정보를 전달하나요?

이 패킷은 `tradeId`, 오퍼를 바꾼 플레이어 ID, 제안 골드, 그리고 현재 그 플레이어가 올려둔 아이템 목록을 전달합니다. 즉, 상대방에게 "지금 네가 보고 있는 거래 조건이 이렇게 바뀌었다"는 최신 오퍼 스냅샷을 전달하는 용도입니다.

15. `S_TRADE_READY_STATE` 패킷의 목적은 무엇인가요?

양측의 Ready 상태를 동기화해 거래 UI가 같은 상태를 보게 만드는 것입니다. 누가 준비를 눌렀는지, 준비를 취소했는지, 아직 잠금 조건이 만족됐는지를 두 클라이언트가 같은 기준으로 확인할 수 있게 합니다.

16. 양측 Ready가 true일 때 왜 `Locked`로 바꾸나요?

Ready는 "현재 제안 내용에 대해 수정 없이 진행하겠다"는 의사 표시이기 때문에, 둘 다 true가 되면 더 이상 오퍼가 변하면 안 됩니다. 그래서 이 순간 `Locked`로 전환해 수정 경로를 닫고 최종 Confirm 단계로 넘어갑니다.

17. Confirm은 왜 `Locked`에서만 가능해야 하나요?

Confirm은 이미 조건이 고정된 거래에 대해 최종 확정을 누르는 단계여야 의미가 있습니다. 아직 `Active`인데 Confirm을 허용하면, 상대가 조건이 바뀌는 중에도 확정이 들어가서 동의 경계가 흐려집니다.

18. `CancelTrade_ActorOnly`가 하는 정리 작업을 설명해보세요.

양측에게 `S_TRADE_CANCELLED`를 보내고, 필요하면 실패 결과 패킷도 전송합니다. 그다음 `_tradeByPlayer` 양방향 매핑을 지우고, 양쪽 플레이어의 `ActiveTradeId`를 0으로 돌린 뒤 `_trades`에서 세션을 제거해 거래 상태를 완전히 종료합니다.

19. `UpdateTrades_ActorOnly`의 타임아웃 정책은 무엇인가요?

`lastTouchedMs`를 기준으로 60초(`kTradeTimeoutMs`) 이상 반응이 없으면 timeout 취소 대상으로 분류합니다. 단, `Committing` 상태는 예외로 두고 그 외 상태만 `TRADE_CANCEL_TIMEOUT`으로 정리합니다.

20. 왜 `Committing` 상태는 timeout 취소에서 제외하나요?

이 구간은 유저가 입력을 안 해서 멈춘 게 아니라 DB 응답을 기다리는 구간이기 때문입니다. 사용자의 inactivity와 서버 간 커밋 대기를 같은 기준으로 끊어버리면, DB는 성공했는데 게임 서버만 timeout 취소하는 최악의 불일치가 생길 수 있습니다.

21. `BuildTradeCommitPlan_ActorOnly`는 무엇을 위한 함수인가요?

실제 플레이어 인벤토리와 골드를 바로 바꾸지 않고, snapshot 복사본으로 "이 거래가 성공했을 때 최종 상태가 어떻게 되는가"를 먼저 계산하는 함수입니다. 즉, Phase 1의 검증과 시뮬레이션을 담당하는 핵심 함수입니다.

22. `TradeCommitPlan`에 `finalAItems/finalBItems`를 저장하는 이유는 무엇인가요?

DBAgent에는 최종 상태 스냅샷을 한 번에 보내야 하고, 성공 응답이 오면 GameServer 메모리에도 같은 결과를 그대로 적용해야 합니다. 그래서 A와 B의 최종 인벤토리 결과를 계획 단계에서 확정해 `finalAItems/finalBItems`로 보관합니다.

23. 슬롯 할당(`kTradeMaxInventorySlots`) 검증이 필요한 이유는 무엇인가요?

받는 쪽 인벤토리에 빈 슬롯이 없는데도 거래를 확정하면, 새 아이템을 어디에 둘지 모르는 상태가 됩니다. 이 문제를 DB 직전이 아니라 Phase 1에서 미리 걸러야, 커밋을 시작했다가 뒤늦게 실패하는 상황을 줄일 수 있습니다.

24. 소모품 스택 병합 로직의 목적은 무엇인가요?

같은 템플릿의 소모품은 기존 스택에 합쳐 넣을 수 있으므로, 새 슬롯을 불필요하게 차지하지 않게 해 줍니다. 결과적으로 슬롯 부족으로 실패하는 경우를 줄이고, 인벤토리를 더 자연스럽게 유지할 수 있습니다.

25. `StartTradeCommitPhase2_ActorOnly`에서 `requestId`를 넣는 이유는 무엇인가요?

거래 커밋 응답은 비동기로 돌아오기 때문에, 이 응답이 현재 커밋 시도에 대한 것인지 식별할 키가 필요합니다. `requestId`를 넣으면 늦게 도착한 옛 응답이나 잘못 라우팅된 응답을 현재 거래 결과로 잘못 적용하지 않을 수 있습니다.

26. DBAgent 트랜잭션에서 `BEGIN/COMMIT/ROLLBACK`의 의미를 설명해보세요.

`BEGIN`은 양측 아이템과 골드 반영을 하나의 원자 작업으로 묶는 시작점입니다. 중간에 어떤 쿼리라도 실패하면 `ROLLBACK`으로 전부 없던 일로 되돌리고, 모든 단계가 성공했을 때만 `COMMIT`으로 최종 확정합니다.

27. `S2S_RES_TRADE_COMMIT` 응답은 어떤 정보를 포함하나요?

응답에는 `tradeId`, `channelId`, `mapId`, `instanceId` 같은 라우팅 정보와 `success`, `failCode`, `requestId`가 포함됩니다. GameServer는 이 값으로 올바른 룸을 찾고, 현재 커밋 시도와 일치하는 응답인지 다시 검증합니다.

28. `OnTradeCommitResult_ActorOnly`에서 stale 응답을 무시하는 기준은 무엇인가요?

우선 거래 세션이 존재해야 하고, 상태가 아직 `Committing`이어야 합니다. 그다음 현재 세션의 `commitRequestId`와 응답의 `requestId`가 둘 다 0이 아니고 서로 다르면 stale 응답으로 보고 무시합니다.

29. 커밋 성공 후 왜 메모리와 Redis 동기화를 함께 하나요?

DB는 영속 저장소이고, 메모리와 Redis는 실제 게임 플레이와 이후 저장 파이프라인이 보는 런타임 상태입니다. DB만 성공시키고 메모리/Redis를 안 맞추면 서버 내부 상태가 뒤틀리기 때문에, 성공 시점에 세 층을 함께 맞춰 줘야 합니다.

30. 성공 후 `S_REMOVE_ITEM`/`S_CHANGE_ITEM` 델타 전송을 하는 이유는 무엇인가요?

클라이언트 인벤토리를 전체 재전송하지 않고, 실제로 사라진 아이템과 바뀐 아이템만 정확히 갱신하기 위해서입니다. 이렇게 하면 네트워크 비용을 줄이면서도 거래 결과를 즉시 UI에 반영할 수 있습니다.

31. 맵 전이 시 거래를 강제 취소하는 이유는 무엇인가요?

거래 도중 한 명이 다른 맵이나 채널로 이동하면 같은 룸 Actor에서 양측 상태를 안전하게 관리하기 어려워집니다. 그래서 `TransferMapChangeById` 진입 시 활성 거래가 있으면 `TRADE_CANCEL_MAP_CHANGE`로 먼저 정리하고 이동을 진행합니다.

32. 접속 종료 시 거래 취소를 하지 않으면 어떤 문제가 생기나요?

상대는 여전히 거래 중이라고 믿고 있는데, 실제 상대 세션은 사라진 유령 거래 상태가 남게 됩니다. 이 상태가 남으면 `ActiveTradeId`가 풀리지 않아 새 거래도 못 하고, 자산 잠금이나 UI 잔상 문제도 같이 생길 수 있습니다.

33. 왜 거래 로직을 Room Actor 큐에서만 실행하나요?

거래는 양쪽 플레이어와 같은 룸 문맥에 묶여 있고, 동시에 여러 입력이 들어와도 순서가 보장돼야 합니다. Room Actor 큐에서만 처리하면 별도 락 없이도 요청이 직렬화되어, offer/ready/confirm 경합과 중복 상태 전이를 크게 줄일 수 있습니다.

34. Part E에서 "실패 수렴"이란 무엇인가요?

검증 실패, 거절, 타임아웃, 맵 전이, 접속 종료, DB 실패처럼 원인은 달라도 최종적으로는 하나의 공통 취소 경로로 정리되는 것을 뜻합니다. 즉, 중간 상태를 남기지 않고 `CancelTrade_ActorOnly` 중심으로 안전한 종료 상태에 모으는 설계입니다.

35. Part E를 한 줄로 요약하면 무엇인가요?

Part E는 거래를 상태머신과 2단계 커밋으로 통제해, 성공만 양측 자산에 동시에 반영하고 실패는 모두 공통 취소로 수렴시키는 설계입니다.

## 2. 어려운 개념 질문 (10문제)

1. `Committing` 중 취소를 허용하면 어떤 일관성 문제가 발생할 수 있나요?

가장 위험한 경우는 DB는 이미 성공했는데 GameServer가 사용자 취소를 받아 거래를 롤백한 것처럼 정리하는 상황입니다. 그러면 DB 자산은 바뀌었는데 메모리와 클라이언트는 취소된 것으로 보여, 아이템 소실이나 복사와 같은 심각한 불일치가 발생합니다.

2. Phase 1 시뮬레이션과 실제 DB 반영 사이의 시간차에서 생길 수 있는 TOCTOU 위험을 설명해보세요.

Phase 1이 끝난 뒤 DB 커밋 응답이 오기 전까지는 시간차가 존재하므로, 그 사이에 같은 자산을 다른 경로가 건드리면 계획과 실제 상태가 어긋날 수 있습니다. 현재 구조는 Room Actor 직렬화와 `Committing` 상태 잠금으로 거래 관련 입력을 막아 이 위험을 크게 줄였지만, 만약 인벤토리를 바꾸는 다른 시스템이 같은 규칙을 따르지 않으면 여전히 TOCTOU가 생길 수 있습니다.

3. stale DB 응답이 뒤늦게 도착했을 때 requestId 가드가 왜 필요한지 설명해보세요.

비동기 시스템에서는 응답이 순서대로 오지 않는다고 가정해야 합니다. requestId 가드가 없으면 예전 커밋 응답을 현재 거래 세션에 잘못 적용할 수 있고, 특히 같은 거래 문맥이 이미 다른 상태로 바뀐 뒤라면 치명적인 오적용이 발생할 수 있습니다.

4. 슬롯 재할당/스택 병합 로직에서 경계 조건 버그가 왜 치명적인지 설명해보세요.

거래는 자산 이동이기 때문에 슬롯 하나, 수량 하나만 잘못 계산돼도 바로 아이템 복사나 소실로 이어집니다. 예를 들어 빈 슬롯 판정이 틀리면 덮어쓰기나 유령 슬롯이 생기고, 스택 병합 수량 계산이 틀리면 실제 보유량보다 많거나 적은 결과를 커밋하게 됩니다.

5. 거래 중 맵 전이와 접속 종료가 동시에 발생할 때 수렴 경로를 어떻게 보장하나요?

핵심은 모든 관련 이벤트가 결국 같은 Room Actor 큐에서 순차 처리된다는 점입니다. 맵 전이 경로는 `TRADE_CANCEL_MAP_CHANGE`, 룸 이탈/접속 종료는 `TRADE_CANCEL_DISCONNECT`로 거래 취소를 요청하고, 이미 `Committing`이면 내부 실패 외 취소를 막아 한쪽 경로만 최종 상태를 만들게 합니다.

6. 단일 트랜잭션이라도 애플리케이션 레벨 실패가 생길 수 있는 지점을 설명해보세요.

DB 자체는 성공했더라도 GameServer에서 응답을 받을 때 `state != Committing`, `commitPlan` 누락, 플레이어 객체 유실, 라우팅 룸 미존재 같은 문제가 생길 수 있습니다. 즉, DB 원자성과 애플리케이션 상태 수렴은 다른 문제라서, DB 트랜잭션만으로 전체 시스템 안정성이 자동 보장되는 것은 아닙니다.

7. 커밋 성공 후 클라이언트 델타 전송 누락 시 어떤 정합성 문제가 생기나요?

서버 메모리와 DB는 이미 성공 상태인데, 클라이언트 UI만 예전 인벤토리를 보게 됩니다. 그러면 사용자는 거래가 실패했다고 오해하거나, 이미 없는 아이템을 다시 보게 되어 후속 행동에서 추가 오류를 유발할 수 있습니다.

8. 인벤토리 스냅샷 기반 계획 수립이 대규모 동시성 환경에서 가지는 장단점을 설명해보세요.

장점은 실데이터를 건드리지 않고 먼저 검증과 계산을 끝낼 수 있어서, 실패 시 중간 반영이 없고 디버깅도 비교적 명확하다는 점입니다. 단점은 복사 비용과 로직 복잡도가 늘고, 동일 자산을 바꾸는 다른 경로가 엄격히 직렬화되지 않으면 snapshot이 stale해질 수 있다는 점입니다.

9. timeout 정책에서 `Committing` 제외가 무한 대기 위험으로 이어질 수 있는 조건을 설명해보세요.

DBAgent 응답이 유실되거나, 응답 라우팅이 실패하거나, GameServer가 해당 응답을 받지 못하면 `Committing` 상태가 오래 유지될 수 있습니다. 현재는 이 상태를 timeout에서 제외하므로, 별도 watchdog이나 장기 대기 감시가 없으면 거래가 끝나지 않는 stuck 상태가 생길 수 있습니다.

10. 거래 상태머신을 잘못 설계했을 때 발생하는 대표 보안 이슈(복사/소실)를 설명해보세요.

대표적으로 오퍼 변경 후 Confirm 유지, `Committing` 중 취소 허용, state 검증 없는 Confirm 허용이 있습니다. 이런 설계 실수는 같은 아이템이 두 군데에 반영되거나, 한쪽 자산만 빠지고 상대방은 못 받는 복사/소실 버그로 바로 이어집니다.

## 3. 기술/개념 선택 이유 질문 (30문제)

1. 왜 거래를 상태머신 기반으로 설계했나요?

거래는 초대, 협상, 잠금, 확정처럼 단계별 허용 동작이 분명해서, 상태머신으로 설계할수록 어떤 입력이 유효한지 명확해집니다. 특히 잘못된 시점의 오퍼 변경, Confirm, 취소를 구조적으로 차단할 수 있어서 정합성과 디버깅 측면에서 유리합니다.

2. 왜 `Invited -> Active -> Locked -> Committing` 순서를 강제했나요?

초대 수락 전에는 거래창이 열리면 안 되고, 조건이 잠기기 전에는 최종 확정을 받으면 안 되며, 커밋이 시작된 뒤에는 다시 취소나 수정이 들어오면 안 됩니다. 이 순서는 각각의 의미를 분리해 중간 상태 개입을 막기 위한 최소 경계입니다.

3. 왜 거래 요청 시 거리 제한을 두었나요?

거래를 같은 공간에서 실제로 만난 플레이어끼리의 상호작용으로 제한하려는 정책입니다. 동시에 원격 거래 악용과 비정상 타겟팅을 줄이고, 같은 룸 안에서 상호작용이 일어났다는 서버 권위 가정을 유지하는 역할도 합니다.

4. 왜 대상 플레이어의 맵 전이 상태를 검증하나요?

맵 전이 중인 대상은 곧 룸 문맥이 바뀌거나 세션 상태가 변할 수 있어서, 거래 세션을 시작해도 안정적으로 유지되기 어렵습니다. 그래서 애초에 진입을 막아 이후 강제 취소와 꼬임을 줄이는 쪽을 택했습니다.

5. 왜 거래 중복을 `ActiveTradeId`로 차단하나요?

플레이어 단위로 "지금 이미 거래 중인가"를 O(1)에 가깝게 판정하기 위한 가장 단순하고 강한 가드이기 때문입니다. `_tradeByPlayer` 조회와 함께 쓰면 거래 세션 접근과 중복 진입 차단을 동시에 해결할 수 있습니다.

6. 왜 오퍼 수정 시 ready/confirm를 즉시 초기화하나요?

조건이 바뀌었으면 기존 동의는 더 이상 유효하지 않기 때문입니다. 이 초기화가 없으면 상대가 이전 조건에 대해 눌렀던 Ready/Confirm가 새로운 조건에도 그대로 살아 있어, 사용자 의사와 다른 거래 확정이 발생할 수 있습니다.

7. 왜 골드 검증을 서버에서 다시 수행하나요?

클라이언트는 신뢰할 수 없고, 골드는 자산 그 자체이기 때문입니다. 음수, 초과 제안, 오버플로를 서버가 직접 검증해야 자산 위조나 계산 오류를 막을 수 있습니다.

8. 왜 Confirm 진입 전에 `Locked` 단계를 분리했나요?

Ready와 Confirm는 의미가 다르기 때문입니다. Ready는 "조건을 잠그겠다"는 합의이고, Confirm는 "이 잠긴 조건을 실제로 커밋하겠다"는 최종 승인이라서, 둘을 분리해야 제안 고정과 최종 확정이 섞이지 않습니다.

9. 왜 취소 API를 `Committing`에서 막았나요?

이 시점에는 이미 DB 트랜잭션과 결합된 비동기 처리가 시작됐기 때문에, 사용자 취소를 받으면 DB 결과와 메모리 결과가 갈라질 수 있습니다. 그래서 `Committing`에서는 내부 실패 외 취소를 막고 결과 수신만 허용하는 것이 더 안전합니다.

10. 왜 timeout 취소를 상태 기반으로 다르게 적용했나요?

`Active`나 `Invited`는 유저 반응이 멈춘 상태로 볼 수 있지만, `Committing`은 외부 시스템 응답을 기다리는 상태입니다. 두 상황을 같은 timeout 정책으로 끊어버리면 의미가 다른 대기 상태를 잘못 취급하게 됩니다.

11. 왜 커밋 전에 계획(`TradeCommitPlan`)을 먼저 만드나요?

DB에 요청을 보내기 전에 이미 모든 검증과 최종 결과 계산이 끝나 있어야, 실패를 DB 이전에 차단할 수 있습니다. 즉, "될 거래만 커밋 단계로 보낸다"는 원칙을 지키기 위해서입니다.

12. 왜 실제 인벤 대신 snapshot 복사본으로 시뮬레이션하나요?

실데이터를 즉시 바꾸면 중간에 실패했을 때 다시 되돌리는 비용과 리스크가 큽니다. snapshot으로 먼저 계산하면 실패 시 아무것도 반영하지 않으면 되고, 성공 계획이 확정됐을 때만 실제 상태를 바꾸면 됩니다.

13. 왜 소모품 스택 병합을 먼저 시도하나요?

이미 같은 템플릿의 스택이 있다면 그곳에 합치는 것이 슬롯 사용 측면에서 가장 효율적입니다. 슬롯을 아끼면 불필요한 `INVENTORY_FULL` 실패를 줄일 수 있고, 플레이어 입장에서도 더 자연스러운 인벤토리 결과를 얻게 됩니다.

14. 왜 슬롯 부족을 DB 이전에 선검증하나요?

받는 쪽 인벤토리가 가득 찬 거래를 DB까지 보낸 뒤 실패시키는 것은 비용도 크고 흐름도 복잡해집니다. Phase 1에서 미리 막아야 DB 트랜잭션을 불필요하게 열지 않고, 실패 수렴도 훨씬 단순해집니다.

15. 왜 새 아이템 UID를 계획 단계에서 발급하나요?

계획 단계에서 이미 최종 스냅샷을 완성해야 DBAgent에 보낼 payload와 성공 후 메모리 반영 결과가 동일해집니다. 즉, 새로운 소유권으로 넘어가는 아이템의 identity까지 계획에 포함시켜 결정성을 확보하려는 목적입니다.

16. 왜 `commitPlan`을 세션에 보관하나요?

비동기 DB 응답이 돌아왔을 때 어떤 결과를 메모리와 클라이언트에 적용해야 하는지 기억하고 있어야 하기 때문입니다. `commitPlan`은 성공 시 적용할 정답이자, 응답 처리 시 유효성 검증에도 쓰이는 컨텍스트입니다.

17. 왜 DB 요청에 최종 스냅샷 전체를 보냈나요?

DBAgent가 게임 로직을 다시 계산하지 않고, GameServer가 확정한 결과를 그대로 원자적으로 반영하게 하려는 의도입니다. 즉, 계산 책임은 GameServer에 두고, DBAgent는 "이 결과를 한 트랜잭션으로 저장하라"는 실행 책임만 맡게 한 설계입니다.

18. 왜 DBAgent에서 A/B를 한 트랜잭션으로 묶었나요?

거래의 본질이 양측 자산 동시 반영이기 때문입니다. A와 B를 분리하면 한쪽만 저장되고 다른 쪽이 실패하는 부분 성공이 가능해지므로, 반드시 같은 `BEGIN/COMMIT/ROLLBACK` 경계 안에 넣어야 합니다.

19. 왜 DB 실패 시 `ROLLBACK`만 허용하고 부분 반영을 금지했나요?

부분 반영은 거래 시스템에서 사실상 실패보다 더 위험합니다. 사용자 입장에서는 자산이 절반만 이동하는 것이고, 운영 입장에서는 복구 난도가 급격히 올라가므로, 실패는 무조건 전부 취소로 수렴시키는 편이 맞습니다.

20. 왜 응답에 `requestId`를 되돌려 받나요?

비동기 응답을 현재 커밋 시도와 정확히 매칭하기 위해서입니다. 응답이 늦게 와도 어떤 요청의 결과인지 알 수 있어야 stale 응답을 무시할 수 있습니다.

21. 왜 응답 처리에서 state/requestId/commitPlan 3중 가드를 쓰나요?

각 가드가 막는 리스크가 다르기 때문입니다. `state`는 현재 거래 단계가 맞는지, `requestId`는 이 응답이 현재 요청과 같은지, `commitPlan`은 적용할 계획이 실제로 살아 있는지를 확인해 서로 다른 종류의 오적용을 막습니다.

22. 왜 커밋 성공 시 메모리와 Redis를 함께 갱신하나요?

게임 서버가 당장 참조하는 런타임 상태는 메모리와 Redis 캐시에도 반영돼 있어야 합니다. DB만 맞고 런타임 상태가 다르면 이후 플레이, 저장, UI 동기화가 전부 잘못될 수 있어 성공 시점을 기준으로 한꺼번에 맞춥니다.

23. 왜 클라이언트 갱신을 전체 재전송이 아닌 델타 전송으로 했나요?

거래 후 바뀌는 아이템과 골드는 제한적이기 때문에, 변경분만 보내는 것이 비용과 응답성 면에서 더 효율적입니다. 동시에 어떤 아이템이 사라지고 어떤 아이템이 바뀌었는지 명확하게 표현할 수 있어 UI 반영도 정밀해집니다.

24. 왜 거래 종료 시 `_tradeByPlayer`와 `ActiveTradeId`를 동시에 지우나요?

하나는 룸 내부 거래 세션 조회용이고, 다른 하나는 플레이어의 진입 가드용이라 둘 중 하나만 남아도 정합성이 깨집니다. 즉, 내부 색인과 플레이어 잠금 표식을 함께 풀어야 비로소 거래가 완전히 종료됩니다.

25. 왜 맵 전이 시작 시 거래를 강제 취소하나요?

맵 전이는 플레이어가 현재 룸 문맥을 떠나는 사건이기 때문에, 같은 룸 기반 거래를 유지하기 어렵습니다. 그래서 이동을 우선 진행하기 전에 거래를 끊어 상태 경계를 명확하게 정리합니다.

26. 왜 접속 종료 시 거래를 강제 취소하나요?

한 명이 연결을 잃으면 더 이상 양측 합의 기반 상호작용이 성립하지 않습니다. 이 상태를 유지하면 상대가 무한 대기하거나 거래 잠금이 남기 때문에, disconnect는 강제 취소 트리거로 보는 것이 맞습니다.

27. 왜 거래 패킷 핸들러에서 `PostRoom -> Push` 체인을 쓰나요?

세션에서 현재 룸을 안전하게 찾는 책임과, 실제 거래 로직을 룸 Actor 큐에서 직렬 실행하는 책임을 분리하기 위해서입니다. 이 체인을 쓰면 세션 스레드에서 바로 공유 상태를 건드리지 않고, 올바른 룸 컨텍스트로 안전하게 작업을 넘길 수 있습니다.

28. 왜 트랜잭션 실패 코드를 공통 failCode로 수렴하나요?

사용자에게는 너무 세분화된 내부 오류보다 "이 거래는 실패했다"는 일관된 결과가 더 중요합니다. 반면 상세 원인은 로그로 남기고, 프로토콜 레벨에서는 제한된 failCode로 수렴시키는 편이 클라이언트 처리와 운영 대응 모두 단순해집니다.

29. 왜 Part E를 "원자성 + 실패 수렴" 관점으로 설명해야 하나요?

Part E의 차별점은 단순히 거래 UI를 구현한 것이 아니라, 실패 케이스에서 자산 정합성을 어떻게 지켰는가에 있기 때문입니다. 면접에서도 이 포인트가 서버 프로그래머 관점의 핵심 가치로 평가받기 좋습니다.

30. 왜 운영에서 requestId 로그가 중요한가요?

거래 커밋은 비동기라서 "어느 요청에 대한 응답이 언제 왔는지"를 추적하지 못하면 장애 분석이 어렵습니다. requestId 로그가 있으면 stale 응답, 유실, 중복 처리, 장기 대기 같은 문제를 훨씬 빠르게 좁힐 수 있습니다.

## 4. 파트 흐름 질문 (30문제)

1. `C_TRADE_REQ` 수신부터 `S_TRADE_INVITE` 전송까지 흐름을 설명해보세요.

클라이언트가 `C_TRADE_REQ`를 보내면 세션 핸들러가 먼저 `IsMapChanging()`과 `playerId`를 확인합니다. 그다음 `PostRoom`으로 현재 룸을 찾고, `GameRoom`이면 `gr->Push`로 `HandleTradeReqById`를 룸 Actor 큐에 넣습니다. 룸 안에서는 자기 자신 거래 금지, 대상 존재, 대상의 맵 전이 여부, 양측 `ActiveTradeId`, 거리 조건을 검증하고, 통과하면 `tradeId`를 발급해 `TradeSession(state=Invited)`을 만들고 양측 `ActiveTradeId`와 `_tradeByPlayer`를 세팅한 뒤 상대에게 `S_TRADE_INVITE`를 보냅니다.

2. 거래 요청 시 가드 실패(거리/중복/맵전이)의 종료 흐름을 설명해보세요.

`HandleTradeReqById`는 각 가드에서 실패할 때마다 바로 `SendTradeResult` 실패 응답을 보낸 후 return 합니다. 이 시점에는 아직 `_trades` 세션이나 `_tradeByPlayer` 매핑이 만들어지지 않았기 때문에, 별도 정리 없이 미진입 상태로 종료되는 것이 특징입니다.

3. 초대 응답 수락 시 `Invited -> Active` 전환 흐름을 설명해보세요.

`C_TRADE_INVITE_RESP`는 세션에서 `PostRoom -> Push` 체인으로 `HandleTradeInviteRespById`에 들어갑니다. 룸 Actor는 responder가 실제 B인지, 현재 state가 `Invited`인지, 양 플레이어 객체가 아직 존재하는지 확인합니다. 통과하면 `state=Active`로 바꾸고 ready/confirm를 false로 초기화한 뒤, 양측에 서로의 정보가 담긴 `S_TRADE_START`를 보내 거래창을 열고 `S_TRADE_READY_STATE`도 함께 동기화합니다.

4. 초대 거절 시 취소 수렴 흐름을 설명해보세요.

거절 응답이 오면 `HandleTradeInviteRespById`가 `CancelTrade_ActorOnly(ts->tradeId, TRADE_CANCEL_DECLINED, TRADE_FAIL_REJECTED, "declined")`를 호출합니다. 공통 취소 함수는 양측에 cancelled/result 패킷을 보내고, `_tradeByPlayer`와 `ActiveTradeId`를 정리한 뒤 `_trades`에서 세션을 제거합니다. 즉, 거절도 별도 분기 없이 공통 종료 경로로 수렴합니다.

5. 오퍼 변경 요청의 검증 순서(아이템 존재/장착/수량)를 설명해보세요.

먼저 trade 존재와 `state == Active`를 확인하고, 요청자 플레이어 객체가 유효한지 봅니다. 그다음 `itemUid`와 `count`를 읽어 `count <= 0`이면 offer에서 제거하고, 양수면 실제 인벤토리에서 `FindItemByUid`로 아이템이 존재하는지 확인합니다. 존재하면 장착 중인지(`isequipped`)를 검사하고, 마지막으로 요청 수량이 현재 보유 수량 이하인지 확인한 뒤에만 offer에 반영합니다.

6. 골드 변경 요청의 검증 순서를 설명해보세요.

오퍼 변경과 마찬가지로 trade 존재, `state == Active`, 플레이어 유효성을 먼저 확인합니다. 그 다음 제안 골드가 0 이상인지 검사하고, 이어서 `gold <= p->GetGold()`인지 확인합니다. 이 검증을 통과한 경우에만 A 또는 B의 offerGold를 갱신합니다.

7. 오퍼 변경 후 ready/confirm 초기화 및 브로드캐스트 흐름을 설명해보세요.

아이템이든 골드든 제안 내용이 바뀌면 거래 세션의 `readyA/B`, `confirmA/B`를 모두 false로 리셋합니다. 그 뒤 `SendOfferUpdate_ActorOnly`로 변경된 오퍼 스냅샷을 양측에 보내고, `SendReadyState_ActorOnly`로 준비 상태도 다시 false 기준으로 맞춥니다. 즉, 조건 변경과 동의 상태 무효화가 한 세트로 움직입니다.

8. Ready 입력 후 `S_TRADE_READY_STATE` 전파 흐름을 설명해보세요.

`HandleTradeReadyById`는 trade 존재와 `state == Active`를 확인한 뒤, 요청자가 A인지 B인지에 따라 `readyA` 또는 `readyB`를 갱신합니다. Ready 해제라면 해당 플레이어의 confirm도 같이 false로 풀어 줍니다. 그 후 `SendReadyState_ActorOnly`를 호출해 양측 클라이언트에 현재 ready 비트를 동시에 전파합니다.

9. 양측 Ready가 true가 될 때 `Locked` 전환 흐름을 설명해보세요.

Ready 갱신 후 두 플래그를 확인해 `readyA && readyB`가 되면 `ts->state = TradeState::Locked`로 전환합니다. 이어서 `S_TRADE_LOCKED`를 양측에 전송해 "이제 더 이상 제안을 수정할 수 없는 잠금 상태"에 들어갔음을 알려 줍니다.

10. Confirm 요청에서 `Locked` 검증 후 처리 흐름을 설명해보세요.

`HandleTradeConfirmById`는 trade 존재를 확인한 뒤, 현재 state가 반드시 `Locked`인지 검사합니다. 통과하면 요청자가 A인지 B인지에 따라 `confirmA` 또는 `confirmB`를 true로 바꾸고, 둘 다 true인지 확인해 다음 단계로 넘어갈지 결정합니다. 아직 둘 다 아니면 `Locked` 상태를 유지한 채 기다립니다.

11. 양측 Confirm 완료 후 `Committing` 진입 흐름을 설명해보세요.

두 confirm이 모두 true가 되면 `ts->state = TradeState::Committing`으로 전환합니다. 그런 다음 `StartTradeCommitPhase2_ActorOnly`를 호출해 Phase 1 계획 생성과 DBAgent 요청을 시작하고, 이 과정이 실패하면 즉시 `CancelTrade_ActorOnly(...TRADE_CANCEL_INTERNAL...)`로 내부 실패 취소 경로에 들어갑니다.

12. `StartTradeCommitPhase2_ActorOnly` 내부 단계 흐름을 설명해보세요.

먼저 trade 세션이 존재하는지, 이미 `commitPlan`이 있어 중복 in-flight 상태가 아닌지 확인합니다. 이어서 `BuildTradeCommitPlan_ActorOnly`를 호출해 Phase 1 검증과 시뮬레이션을 수행하고, 성공한 계획을 `ts->commitPlan`에 저장합니다. 그 다음 `S2S_REQ_TRADE_COMMIT`에 라우팅 정보, 플레이어 ID, 최종 골드, 최종 아이템 스냅샷, 삭제 UID 목록, `requestId`를 채워 DB 세션으로 전송합니다.

13. `BuildTradeCommitPlan_ActorOnly`의 사전 검증 흐름을 설명해보세요.

함수는 먼저 trade와 양 플레이어 객체가 존재하는지 확인합니다. 다음으로 offerGold가 음수인지, 현재 보유 골드를 넘는지, 최종 합산 시 오버플로가 나는지 검사합니다. 그 후 offerA/offerB에 들어 있는 각 아이템이 실제 인벤토리에 존재하는지, 장착 중이 아닌지, 수량이 양수이면서 보유 수량 이하인지를 재검증합니다.

14. 계획 수립에서 A/B 제공 아이템 차감 처리 흐름을 설명해보세요.

실제 인벤토리를 직접 건드리지 않고 `aItems`, `bItems`라는 snapshot 복사본을 만듭니다. A가 주는 아이템은 A snapshot에서, B가 주는 아이템은 B snapshot에서 찾은 뒤, 전부 주는 경우에는 deleted UID와 notifyRemove에 기록하고 snapshot에서 삭제합니다. 일부만 주는 경우에는 count를 줄이고 notifyChange에 변경된 아이템을 기록합니다.

15. 계획 수립에서 슬롯 재할당/스택 병합 흐름을 설명해보세요.

먼저 아이템 차감이 끝난 snapshot 기준으로 사용 중 슬롯 비트맵을 만듭니다. 받는 아이템이 소모품이면 같은 templateId의 기존 스택을 찾아 count를 합치고 notifyChange에 기록합니다. 합칠 스택이 없으면 `takeEmptySlot`으로 빈 슬롯을 하나 잡아 새 UID의 `ItemInfo`를 만들고, snapshot과 notifyChange에 반영합니다. 빈 슬롯이 없으면 즉시 `TRADE_FAIL_INVENTORY_FULL`로 실패합니다.

16. 계획 실패 시 즉시 취소되는 흐름을 설명해보세요.

`BuildTradeCommitPlan_ActorOnly`가 false를 반환하면 `StartTradeCommitPhase2_ActorOnly`도 실패합니다. 이 반환값은 다시 `HandleTradeConfirmById`에서 받아져, `CancelTrade_ActorOnly(tradeId, TRADE_CANCEL_INTERNAL, failCode, msg)`가 호출됩니다. 결과적으로 DB 요청은 발행되지 않고, 거래는 내부 실패 취소로 정리됩니다.

17. S2S 커밋 요청 생성 시 필드 구성 흐름을 설명해보세요.

요청에는 `tradeId`, `channelId`, `mapId`, `instanceId`를 넣어 응답을 원래 룸으로 라우팅할 수 있게 합니다. 이어서 `playerAId`, `playerBId`, `finalGoldA`, `finalGoldB`, `finalAItems`, `deletedAItemUids`, `finalBItems`, `deletedBItemUids`를 채웁니다. 마지막으로 세션에 저장한 `commitRequestId`를 `requestId`로 넣어 비동기 응답 매칭 기준을 만듭니다.

18. DBAgent에서 `BEGIN TRAN` 이후 처리 순서를 설명해보세요.

DBAgent는 먼저 응답 패킷에 tradeId와 라우팅 echo, requestId를 채운 뒤, DB 커넥션을 꺼내 `BEGIN TRAN`을 실행합니다. 그 다음 A 쪽 delete와 upsert, B 쪽 delete와 upsert, 그리고 양쪽 gold update를 순서대로 수행합니다. 중간에 하나라도 실패하면 이후 단계는 멈추고 최종적으로 rollback 경로로 갑니다.

19. DBAgent에서 A delete/A upsert/B delete/B upsert 순서를 설명해보세요.

A 쪽은 먼저 `deletedAItemUids`를 순회하며 `DELETE FROM ITEMS`를 실행하고, 그 뒤 `finalAItems`를 기반으로 `UPDATE ... IF @@ROWCOUNT = 0 INSERT ...` 방식의 upsert를 수행합니다. B 쪽도 정확히 같은 패턴으로 `deletedBItemUids` delete 후 `finalBItems` upsert를 실행합니다. 이 순서를 통해 최종 스냅샷과 삭제 목록을 일관되게 반영합니다.

20. DBAgent에서 gold update 후 commit/rollback 분기 흐름을 설명해보세요.

아이템 처리까지 모두 성공한 경우에만 A gold update, B gold update를 순서대로 실행합니다. 이 단계까지 `ok`가 유지되면 `COMMIT TRAN`을 실행하고, 중간 어느 단계에서라도 실패하면 `ROLLBACK TRAN`을 실행합니다. 이후 `res.success`와 `failCode`를 채워 GameServer로 응답을 돌려보냅니다.

21. `S2S_RES_TRADE_COMMIT` 응답이 GameServer로 돌아오는 흐름을 설명해보세요.

DBAgent가 응답을 보내면 `S2SPacketHandler::Handle_S2S_RES_TRADE_COMMIT`가 이를 받습니다. 핸들러는 응답에 들어 있는 `channelId`, `mapId`, `instanceId`로 원래 거래가 일어난 `GameRoom`을 찾고, 그 룸 Actor 큐에 `room->OnTradeCommitResult(pkt)` 작업을 넣습니다. 즉, DB 응답 처리도 다시 동일 룸 문맥으로 회귀시켜 직렬성을 유지합니다.

22. `OnTradeCommitResult_ActorOnly`의 3중 가드(state/requestId/commitPlan) 흐름을 설명해보세요.

먼저 trade 세션이 있는지 확인하고, 없으면 바로 무시합니다. 다음으로 현재 state가 `Committing`인지 검사해 이미 끝난 거래에 대한 응답을 걸러냅니다. 그 후 `commitRequestId`와 응답 `requestId`가 일치하는지 확인하고, 마지막으로 `commitPlan`이 실제로 남아 있는지 검사합니다. `commitPlan`이 없으면 이는 내부 이상 상태이므로 `CancelTrade_ActorOnly(...missing commit plan...)`로 취소합니다.

23. 커밋 실패 응답 수신 시 취소 수렴 흐름을 설명해보세요.

DB 응답의 `success`가 false면, `failCode`가 비어 있을 경우 내부 실패 코드로 보정한 뒤 `CancelTrade_ActorOnly(tradeId, TRADE_CANCEL_INTERNAL, fail, "DB commit failed")`를 호출합니다. 이로써 실패는 공통 취소 경로로 들어가고, 메모리 인벤토리나 골드는 건드리지 않은 채 종료됩니다.

24. 커밋 성공 응답 수신 시 메모리 반영 흐름을 설명해보세요.

성공 응답이 오면 먼저 양 플레이어 객체가 아직 존재하는지 확인합니다. 그다음 `const TradeCommitPlan& plan = *ts->commitPlan`을 꺼내 A와 B의 `GetItems()`를 `finalAItems/finalBItems`로 덮어쓰고, `SetGold`로 최종 골드까지 반영합니다. 즉, 메모리 반영은 성공 응답에서만 일괄 적용됩니다.

25. 커밋 성공 후 Redis 동기화 및 dirty 처리 흐름을 설명해보세요.

삭제된 아이템 UID는 `RemoveInventoryItem(...markDirty=false)`로 제거하고, 최종 아이템 스냅샷은 `UpdateInventoryItem(...markDirty=false)`로 Redis/런타임 캐시에 맞춥니다. 이후 `ClearDirtyOnCommitSuccess(invOk=true)`로 인벤 dirty를 정리하고, 골드는 `UpdatePlayerGold(...markDirty=false)`로 갱신합니다. 이미 DB에는 반영됐기 때문에 여기서 `markDirty=false`를 쓰는 것이 중요합니다.

26. 커밋 성공 후 클라 델타(`S_REMOVE_ITEM/S_CHANGE_ITEM/S_GOLD_UPDATE`) 전송 흐름을 설명해보세요.

먼저 양측에게 각각 `S_GOLD_UPDATE`를 보내 최종 골드를 동기화합니다. 그 다음 A와 B에 대해 `notifyRemove*` 목록을 순회하며 `S_REMOVE_ITEM`을 보내고, `notifyChange*` 목록을 순회하며 `S_CHANGE_ITEM`을 보냅니다. 델타 패킷 전송이 끝나면 최종적으로 두 플레이어 모두 `S_TRADE_RESULT(success=true)`를 받습니다.

27. 성공 종료 시 `_tradeByPlayer`/`ActiveTradeId` 정리 흐름을 설명해보세요.

성공 결과 패킷 전송 후 `_tradeByPlayer`에서 A와 B 키를 모두 제거합니다. 이어서 두 플레이어의 `ActiveTradeId`를 0으로 바꾸고, 마지막으로 `_trades.erase(tradeId)`로 세션 본문까지 지웁니다. 이 순서가 완료돼야 거래가 완전히 종료됩니다.

28. 사용자 취소 요청이 `Committing`에서 무시되는 흐름을 설명해보세요.

`HandleTradeCancelById`는 trade를 찾고 요청자가 A 또는 B인지 검증한 다음, `ts->state == TradeState::Committing`이면 즉시 return 합니다. 즉, 이 상태에서는 `CancelTrade_ActorOnly`를 호출하지 않고 아무 작업도 하지 않아서 DB 결과를 기다리게 만듭니다.

29. timeout 검사에서 `Committing` 제외 후 취소하는 흐름을 설명해보세요.

`UpdateTrades_ActorOnly`는 `_trades`를 순회하면서 각 `TradeSession`의 `lastTouchedMs`를 검사합니다. 이때 `state == Committing`인 세션은 아예 건너뛰고, 나머지 상태 중 60초를 초과한 tradeId만 `toCancel`에 모읍니다. 루프가 끝나면 그 목록을 `CancelTrade_ActorOnly(...TRADE_CANCEL_TIMEOUT...)`로 일괄 취소합니다.

30. 맵 전이/접속 종료 이벤트가 거래 취소로 연결되는 흐름을 설명해보세요.

앞단에서는 `ClientPacketHandler.Trade.cpp`가 `IsMapChanging()` 세션을 거래 진입에서 막습니다. 그럼에도 활성 거래 중에 실제 맵 전이가 시작되면 `TransferMapChangeById`가 `ActiveTradeId`를 보고 `TRADE_CANCEL_MAP_CHANGE`로 거래를 취소한 뒤 이동을 진행합니다. 접속 종료나 룸 이탈은 `Leave` 경로에서 `TRADE_CANCEL_DISCONNECT`로 같은 공통 취소 함수로 수렴합니다.

## 5. 관련 자유 질문 (10문제)

1. Part E에서 본인이 가장 설명하기 쉬운 설계 선택은 무엇인가요?

저는 거래 상태머신과 `Committing` 취소 금지 설계를 가장 설명하기 쉽습니다. 이유는 이 두 지점이 "왜 단순 거래 기능이 아니라 서버 정합성 문제인가"를 가장 직관적으로 보여 주기 때문입니다.

2. 신입 입장에서 거래 시스템 코드를 처음 읽을 때 어떤 순서로 접근하겠습니까?

먼저 이 문서와 `docs/portfolio/section2/portfolio_temp_section2.md`의 Part E 설명으로 전체 구조를 잡겠습니다. 그다음 `ClientPacketHandler.Trade.cpp`로 패킷 진입 경로를 보고, `GameRoom.h`의 `TradeState/TradeSession/TradeCommitPlan`을 읽은 뒤, `GameRoom.Trade.cpp`에서 상태 전이 함수와 `BuildTradeCommitPlan_ActorOnly`, `StartTradeCommitPhase2_ActorOnly`, `OnTradeCommitResult_ActorOnly` 순서로 보겠습니다. 마지막으로 `S2SPacketHandler`와 `DBAgentPacketHandler`를 읽어 Game->DB->Game 응답 흐름을 완성하겠습니다.

3. 면접에서 "거래 복사 버그를 어떻게 막았냐"를 한 문단으로 답해보세요.

이 프로젝트에서는 거래를 `Invited -> Active -> Locked -> Committing` 상태머신으로 제한해서 잘못된 시점의 입력을 막았고, 최종 확정 전에는 실제 데이터를 바꾸지 않고 snapshot 기반 `TradeCommitPlan`으로 먼저 검증했습니다. 그 뒤 DBAgent에서 양측 아이템과 골드를 단일 SQL 트랜잭션으로 처리해 부분 성공을 막았고, 응답을 받을 때도 `state == Committing`, `requestId`, `commitPlan`을 함께 검증한 뒤 성공일 때만 메모리와 Redis, 클라이언트 델타를 반영했습니다. 실패는 전부 공통 취소로 수렴시켜 중간 상태를 남기지 않는 방식으로 복사/소실 버그를 방어했습니다.

4. 협업 시 클라이언트 팀과 거래 UI 계약에서 가장 중요한 3가지는 무엇인가요?

첫째, `Locked` 이후에는 오퍼 수정 UI를 막고 Confirm만 허용한다는 상태 계약이 필요합니다. 둘째, 오퍼나 골드가 바뀌면 Ready/Confirm이 서버에서 즉시 초기화될 수 있으므로, 클라이언트도 이 상태 변화를 UI에 즉시 반영해야 합니다. 셋째, 거래 종료는 `S_TRADE_CANCELLED`, `S_TRADE_RESULT`, 인벤 델타 패킷이 각각 다른 의미를 가지므로, 결과 알림과 실제 인벤 갱신을 분리해서 처리해야 합니다.

5. 운영 장애를 줄이기 위해 Part E에 추가하고 싶은 모니터링 지표는 무엇인가요?

가장 먼저 보고 싶은 것은 `Invited/Active/Locked/Committing` 상태별 체류 시간입니다. 그 다음은 `TRADE_CANCEL_*` reason별 취소 건수와 Phase 1 실패 사유 분포, 마지막으로 DB 커밋 왕복 지연과 stale 응답 무시 건수입니다.

6. Part E를 리팩터링한다면 어떤 함수를 먼저 분리하겠습니까?

`BuildTradeCommitPlan_ActorOnly`를 가장 먼저 분리하겠습니다. 현재 이 함수는 골드 검증, 아이템 재검증, 삭제, 스택 병합, 슬롯 할당, notify delta 계산까지 모두 들어 있어서 복잡도가 높고, 테스트 단위로 쪼개기 어렵습니다.

7. requestId 기반 설계를 다른 도메인에 적용한다면 어디에 쓰겠습니까?

구매 확정, 우편 보상 수령, 길드 창고 이동, 던전 입장 승인처럼 비동기 응답이 늦게 돌아올 수 있는 도메인에 바로 적용할 수 있습니다. 핵심은 "지금 도착한 응답이 현재 요청에 대한 것인가"를 판별해야 하는 모든 곳입니다.

8. 거래 실패 메시지 전략(유저 친화성 vs 내부 상세성)을 어떻게 설계하겠습니까?

프로토콜에는 사용자가 이해할 수 있는 제한된 failCode만 노출하고, 내부 상세 원인은 서버 로그에 남기는 이중 구조가 좋습니다. 예를 들어 사용자에게는 `인벤토리 공간 부족`, `거래 실패`, `상대가 거래 불가 상태` 정도만 보여 주고, 로그에는 requestId, tradeId, 상세 메시지, phase, DB 오류를 남겨 운영자가 원인을 추적하게 하겠습니다.

9. Part E 설계 경험을 신입 면접 강점으로 어떻게 표현하겠습니까?

저는 단순히 거래 UI를 붙인 것이 아니라, 자산 이동이라는 민감한 문제를 상태 제어와 원자 커밋, 실패 수렴 구조로 설계해 본 경험이 있다는 점을 강점으로 말하겠습니다. 특히 "성공만 반영하고 실패는 공통 취소로 모은다"는 서버 사고방식을 실제 코드로 풀어낸 점을 강조하겠습니다.

10. Part E를 1분 발표로 설명한다면 어떤 흐름으로 말하겠습니까?

먼저 거래의 핵심 위험이 한쪽만 반영되는 자산 불일치라고 설명하겠습니다. 다음으로 `Invited -> Active -> Locked -> Committing` 상태머신으로 입력을 통제했고, 확정 직전에는 snapshot 기반 Phase 1 계획을 만든 뒤 DBAgent에서 단일 트랜잭션으로 반영했다고 설명하겠습니다. 마지막으로 응답은 `state/requestId/commitPlan`으로 검증하고, 실패는 취소 수렴, 성공만 메모리/Redis/클라 델타 반영으로 끝낸다고 정리하겠습니다.

## 6. 생길 수 있는 문제 관련 질문 (10문제)

1. offer 변경 후 ready/confirm 초기화가 누락되면 어떤 문제가 생기나요?

이미 예전 조건에 대해 누른 Ready/Confirm가 새 조건에도 그대로 살아 있게 됩니다. 그 결과 상대가 변경 사실을 충분히 인지하지 못한 상태에서 거래가 확정될 수 있어, 사기성 변경이나 의도하지 않은 자산 이동이 발생합니다.

2. `Committing` 상태에서 취소를 허용하면 어떤 데이터 불일치가 생기나요?

DB는 성공했는데 GameServer는 취소로 정리해 메모리를 옛 상태로 남기는 분리가 생길 수 있습니다. 반대로 DB는 아직 실패 여부가 미정인데 클라이언트만 취소된 것으로 보이는 등, 저장소와 런타임 상태가 서로 다른 현실을 보게 됩니다.

3. requestId 검증이 없으면 어떤 stale 응답 문제가 생기나요?

늦게 도착한 예전 커밋 응답이 현재 거래 세션에 잘못 적용될 수 있습니다. 비동기 환경에서는 응답 순서를 신뢰할 수 없기 때문에, requestId가 없으면 잘못된 성공/실패 처리나 중복 적용이 발생할 여지가 생깁니다.

4. 슬롯 계산 오류가 발생하면 어떤 아이템 손실/복사 문제가 생길 수 있나요?

빈 슬롯을 잘못 판정하면 기존 아이템을 덮어쓰거나, 같은 슬롯에 둘 이상의 아이템이 있다고 가정하는 잘못된 스냅샷이 만들어질 수 있습니다. 결과적으로 어떤 아이템은 사라지고, 어떤 아이템은 중복 생성된 것처럼 보이는 심각한 인벤토리 오류로 이어집니다.

5. 스택 병합 로직 오류 시 어떤 인벤토리 정합성 문제가 발생하나요?

수량 합산이 잘못되면 원래 가진 수보다 많아지거나 적어지는 문제가 바로 생깁니다. 또한 합칠 수 있는 아이템을 새 슬롯으로 보내거나, 반대로 합치면 안 되는 아이템을 억지로 합치면 최종 인벤 구조가 서버 의도와 다르게 깨집니다.

6. timeout이 너무 짧으면 어떤 UX 문제가 발생하나요?

사용자가 잠깐 고민하거나 네트워크 지연이 있는 동안 거래가 자꾸 끊겨 버립니다. 특히 준비/확정 단계에서 반복 timeout이 나면 거래 시스템 자체가 불안정하다고 느껴질 수 있습니다.

7. timeout이 너무 길면 어떤 리소스/운영 문제가 생기나요?

거래 세션이 오래 살아남아 `_trades`, `_tradeByPlayer`, `ActiveTradeId` 같은 상태가 필요 이상으로 점유됩니다. 운영 관점에서는 유령 거래와 stuck 세션이 늦게 정리돼 장애 탐지도 늦어지고, 사용자도 왜 거래가 안 풀리는지 알기 어려워집니다.

8. 맵 전이 시 거래 취소가 안 되면 어떤 문제가 생기나요?

한 명은 이미 다른 룸으로 이동했는데 거래 세션은 이전 룸 기준으로 남게 됩니다. 그러면 이후 응답과 취소, 오퍼 변경이 잘못된 문맥에서 처리되거나, 플레이어가 이동했는데도 거래중 상태가 남는 꼬임이 발생합니다.

9. 접속 종료 시 거래 정리가 안 되면 어떤 유령 세션 문제가 생기나요?

상대는 더 이상 존재하지 않는 플레이어와 거래 중인 것처럼 남고, 종료한 플레이어의 `ActiveTradeId`도 풀리지 않을 수 있습니다. 그 결과 재접속 전까지 새 거래가 막히거나, 룸 내부에 존재하지 않는 거래 세션이 남는 유령 상태가 생깁니다.

10. 성공 후 클라 델타 전송이 일부 누락되면 어떤 현상이 발생하나요?

서버는 성공 상태인데 클라이언트만 일부 아이템이나 골드 변화를 보지 못하게 됩니다. 사용자는 거래가 반쯤 된 것처럼 느끼고, 다음 입력에서 이미 서버에 없는 아이템을 조작하려 하면서 추가 오류를 만들 수 있습니다.

## 7. 트러블슈팅 관련 질문 (5문제)

1. "거래 성공했는데 한쪽 아이템이 안 보인다" 이슈가 오면 어떤 로그부터 확인하시겠습니까?

가장 먼저 `S2S_RES_TRADE_COMMIT(success=true)`와 해당 `requestId`가 현재 trade의 `commitRequestId`와 일치했는지 확인하겠습니다. 그 다음 `TradeCommitPlan`의 `notifyRemove/notifyChange` 내용, `OnTradeCommitResult_ActorOnly`의 메모리 반영 로그, `S_REMOVE_ITEM/S_CHANGE_ITEM` 전송 로그를 순서대로 보겠습니다. 마지막으로 Redis/DB에는 최종 스냅샷이 맞게 들어갔는지 대조하면 서버 반영 문제인지 클라이언트 동기화 문제인지 분리할 수 있습니다.

2. "거래가 자꾸 타임아웃 난다" 제보에 대해 어떤 단계별 지표를 확인하시겠습니까?

우선 거래 상태별 평균 체류 시간과 `TRADE_CANCEL_TIMEOUT` 발생 비율을 확인하겠습니다. 그다음 `lastTouchedMs` 갱신이 정상적으로 일어나는지, 룸 Actor 큐 지연이 없는지, 클라이언트에서 오퍼/ready/confirm 패킷이 실제로 들어오는지를 봐야 합니다. DB 대기 때문인지 사용자 입력 지연 때문인지 구분하기 위해 `Committing` 이전과 이후를 나눠 보는 것이 중요합니다.

3. "가끔 거래 취소 후에도 거래중 상태가 남는다" 문제를 어떻게 추적하시겠습니까?

`CancelTrade_ActorOnly`가 실제로 호출됐는지와 어떤 reason으로 들어왔는지부터 확인하겠습니다. 그 다음 `_tradeByPlayer.erase`, 양측 `SetActiveTradeId_ActorOnly(0)`, `_trades.erase`가 모두 실행됐는지 로그나 디버거로 확인합니다. 만약 state가 이미 `Committing`이라 취소가 early return 됐다면, 그 시점의 requestId/응답 흐름까지 함께 추적해야 합니다.

4. "DB는 성공인데 클라에는 실패가 뜬다" 상황에서 requestId/state 기준으로 어떻게 진단하시겠습니까?

먼저 DB 응답이 성공인데 GameServer에서 `state != Committing` 또는 requestId mismatch로 무시된 것은 아닌지 확인해야 합니다. 만약 성공 응답이 stale로 버려진 뒤 다른 내부 취소가 일어났다면, 클라이언트는 실패를 보지만 DB는 이미 반영된 상태가 될 수 있습니다. 그래서 응답 도착 시각, 현재 state, `ts->commitRequestId`, 이후 `CancelTrade_ActorOnly` 호출 여부를 함께 봐야 정확히 진단됩니다.

5. "맵 이동 직전에 거래하면 이상해진다" 문제를 어떤 재현 시나리오로 검증하시겠습니까?

먼저 `Active` 상태에서 포탈 또는 채널 이동을 시도해 `TRADE_CANCEL_MAP_CHANGE`가 정상적으로 먼저 발생하는지 보겠습니다. 그다음 `Locked` 직후, 그리고 양측 Confirm로 `Committing`에 들어가기 직전/직후에 맵 전이를 시도해 어떤 경로가 우선 적용되는지 확인해야 합니다. 마지막으로 로그에서 map change token 흐름과 trade cancel reason, requestId를 함께 대조해 둘 중 하나만 최종 상태를 만드는지 검증하겠습니다.

## 8. 비교/대안 유형 질문 (20문제)

1. 상태머신 기반 거래와 단순 플래그 기반 거래를 비교해보세요.
2. 2단계 커밋 방식과 즉시 DB 반영 방식의 차이를 비교해보세요.
3. snapshot 시뮬레이션 방식과 실데이터 즉시 수정 방식의 장단점을 비교해보세요.
4. requestId 매칭 방식과 시간 기반 응답 무시 방식의 차이를 비교해보세요.
5. 단일 트랜잭션 적용과 쿼리 분할 적용의 원자성 차이를 비교해보세요.
6. delta 전송과 full inventory 재전송 방식의 장단점을 비교해보세요.
7. offer 변경 시 confirm 초기화 방식과 유지 방식의 리스크를 비교해보세요.
8. 거리 제한 거래와 거리 무제한 거래 정책의 장단점을 비교해보세요.
9. `Committing` 취소 금지와 허용 정책을 비교해보세요.
10. timeout 즉시 취소와 재시도 대기 정책을 비교해보세요.
11. Room Actor 직렬화와 글로벌 락 기반 처리의 차이를 비교해보세요.
12. tradeId 단일 키와 (A,B) 쌍 키 기반 관리의 차이를 비교해보세요.
13. 소모품 스택 병합 우선과 신규 슬롯 우선 전략을 비교해보세요.
14. 슬롯 고정 상한 모델과 동적 인벤 확장 모델을 비교해보세요.
15. 실패 즉시 공통 취소와 부분 롤백 재시도 전략을 비교해보세요.
16. 서버 주도 취소(맵전이/종료)와 클라 자율 취소 중심 모델을 비교해보세요.
17. Redis 동기화 즉시 반영과 지연 반영 전략을 비교해보세요.
18. failCode 단순화와 세분화 전략을 비교해보세요.
19. S2S 동기 처리와 비동기 큐 처리의 운영 리스크를 비교해보세요.
20. Part E 구조를 MMO와 소규모 협동게임에서 적용할 때 차이를 비교해보세요.

## 9. 한계/개선점 유형 질문 (10문제)

1. Part E의 현재 구조에서 가장 큰 한계를 하나 꼽고 개선안을 제시해보세요.

가장 큰 한계는 `BuildTradeCommitPlan_ActorOnly`에 거래 검증과 인벤토리 시뮬레이션의 복잡한 책임이 너무 많이 몰려 있다는 점입니다. 개선하려면 인벤토리 diff 엔진, 슬롯 할당기, 스택 병합기, notify delta 생성기를 별도 모듈로 분리하고, 각 단위에 대해 케이스 기반 테스트를 붙이는 것이 좋습니다.

2. `Committing` 장기 대기에 대한 보호장치 한계를 어떻게 개선하시겠습니까?

현재는 `Committing`을 timeout에서 제외하기만 하고, 장기 대기 자체를 감지하는 별도 보호장치가 약합니다. 개선하려면 `commitStartedAtMs`를 기록하고, 일정 시간 이상 응답이 없으면 경고 메트릭을 올리거나 운영용 복구 경로로 넘기는 watchdog을 추가하겠습니다.

3. requestId 외 추가 무결성 검증(예: 해시/서명)의 필요성과 개선안을 설명해보세요.

requestId는 "이 응답이 어느 요청 것인가"는 알려 주지만, payload 자체가 기대한 계획과 같은지까지는 보장하지 않습니다. 추가로 plan hash나 playerA/B, finalGold, item count 요약 해시를 응답 검증에 포함하면, 잘못된 라우팅이나 비정상 응답을 더 강하게 걸러낼 수 있습니다.

4. 슬롯/스택 시뮬레이션 코드 복잡도를 낮추기 위한 리팩터링 방안을 제시해보세요.

`Vector<ItemInfo>`를 직접 조작하는 로직을 `InventorySimulator` 같은 클래스로 감싸고, `removeOffer`, `mergeStack`, `allocateSlot`, `emitDelta` 같은 작은 연산으로 나누겠습니다. 이렇게 하면 거래뿐 아니라 보상 지급, 우편 수령 같은 다른 도메인에서도 같은 로직을 재사용할 수 있습니다.

5. 실패 코드(`TRADE_FAIL_INTERNAL`)가 과도하게 뭉치는 한계를 어떻게 개선하시겠습니까?

현재는 서로 다른 실패 원인이 모두 internal로 수렴되는 경우가 많아 운영자가 원인을 빠르게 분류하기 어렵습니다. 외부 프로토콜은 단순하게 유지하되, 내부적으로는 `PLAN_INVALID_ITEM`, `PLAN_NO_SLOT`, `DB_ROUTE_MISS`, `STALE_RESPONSE`, `PLAYER_MISSING_AFTER_COMMIT` 같은 세부 카테고리를 로그와 메트릭에 분리해 두는 것이 좋습니다.

6. 로그/메트릭 관측성 부족 시 Part E에 어떤 계측을 추가하겠습니까?

`tradeId`, `requestId`, A/B playerId를 포함한 구조화 로그를 모든 상태 전이에 넣겠습니다. 메트릭으로는 상태별 체류 시간, cancel reason별 카운트, Phase 1 실패 사유, commit latency, stale response 무시 건수, `Committing` 장기 대기 건수를 추가하겠습니다.

7. 타임아웃 정책을 유저 환경(핑/지역) 기반으로 개선하려면 어떻게 설계하겠습니까?

공통 기본값을 두되, RTT나 지역별 평균 지연을 바탕으로 `Invited/Active/Locked` 단계의 timeout을 약간 가변적으로 조정할 수 있습니다. 다만 무작정 늘리기보다는 상한을 두고, UI에 남은 시간을 보여 줘 사용자와 서버가 같은 시간 감각을 갖게 하는 편이 더 실용적입니다.

8. Redis/DB 동기화 경계에서의 잠재적 한계를 어떻게 완화하시겠습니까?

현재는 DB 성공 후 메모리/Redis를 즉시 맞추지만, 그 사이 프로세스 장애가 나면 캐시 갱신이 누락될 가능성이 있습니다. 이를 완화하려면 DB 커밋 성공 이벤트를 durable queue나 재동기화 로그에 남기고, 로그인 시점이나 주기적 검사에서 DB와 Redis를 다시 대조하는 reconciliation 경로를 두는 것이 좋습니다.

9. 대규모 동접에서 거래 처리량을 높이기 위한 구조적 개선안을 제시해보세요.

거래가 같은 룸 안에서는 이미 직렬화돼 있으므로, 먼저 필요한 것은 Room Actor 큐 지연 관측과 무거운 계산의 분리입니다. Phase 1 시뮬레이션을 순수 함수화해 필요한 경우 별도 계산 워커로 넘길 수 있게 하고, 최종 commit/반영만 룸 Actor에서 serialize하는 구조로 발전시킬 수 있습니다. 다만 이 경우에도 같은 자산에 대한 happens-before는 반드시 유지해야 합니다.

10. 크로스 서버 거래로 확장할 때 Part E 구조의 한계와 확장 방향을 설명해보세요.

현재 구조는 두 플레이어가 같은 `GameRoom`과 같은 서버에 있다는 가정이 강합니다. 크로스 서버 거래로 가면 Room Actor 하나로 두 사람을 직렬화할 수 없고, `_tradeByPlayer`나 `ActiveTradeId`도 로컬 메모리에만 둘 수 없습니다. 확장하려면 중앙 거래 코디네이터, 분산 잠금 또는 escrow 개념, durable requestId/plan 저장소, 샤드 간 합의 프로토콜이 필요합니다.

## 10. CS 기초와의 연결 고리 (The CS Bridge) 질문 (10문제)

1. Part E 상태머신을 유한 상태 기계(FSM) 이론으로 설명해보세요.

Part E의 거래는 유한한 상태 집합 `{None, Invited, Active, Locked, Committing}`을 가지는 결정적 FSM입니다. 입력에 따라 허용된 전이만 존재하고, 예를 들어 `Active`가 아닌데 Offer 변경이 들어오면 전이가 일어나지 않도록 설계해 비정상 상태를 차단합니다.

2. 거래 원자성을 데이터베이스 ACID 관점으로 설명해보세요.

Atomicity는 A/B 자산이 함께 반영되거나 전부 취소되는 것으로 구현됩니다. Consistency는 Phase 1 검증과 슬롯/골드 규칙으로 보장되고, Isolation은 Room Actor 직렬화와 `Committing` 잠금으로 보완됩니다. Durability는 DBAgent의 `COMMIT` 이후 DB에 결과가 영속 저장되는 것으로 설명할 수 있습니다.

3. requestId 매칭을 분산 시스템의 idempotency 관점으로 설명해보세요.

requestId는 "이 응답은 어떤 커밋 시도에 대한 것인가"를 식별하는 idempotency/correlation key 역할을 합니다. 같은 요청에 대한 응답을 중복해서 받거나 오래된 응답이 섞여도, 현재 세션의 requestId와 다르면 적용하지 않음으로써 중복 반영을 방지합니다.

4. snapshot 시뮬레이션을 copy-on-write 관점에서 설명해보세요.

실제 인벤토리를 바로 수정하지 않고 복사본을 만든 뒤 그 복사본에서만 변형을 시뮬레이션한다는 점에서 copy-on-write와 유사한 발상입니다. 최종 검증이 끝날 때까지는 원본 상태를 보존하고, commit이 확정됐을 때만 결과를 실제 데이터에 적용합니다.

5. 슬롯 할당/아이템 검색 복잡도를 자료구조 관점에서 설명해보세요.

현재 인벤토리는 `Vector<ItemInfo>` 기반이라 `FindItemByUid`나 스택 검색은 선형 탐색 O(n)에 가깝습니다. 대신 슬롯 상한이 24로 작기 때문에, 해시맵보다 구현 단순성과 순차 탐색 비용이 더 유리한 구조라고 볼 수 있습니다. used slot 비트맵은 O(slotCount)로 빈 슬롯 탐색을 단순화합니다.

6. stale 응답 무시 로직을 happens-before/순서 보장 관점에서 설명해보세요.

비동기 네트워크에서는 실제 도착 순서가 논리 순서와 다를 수 있으므로, 응답 도착만으로 최신성을 판단하면 안 됩니다. requestId와 현재 `Committing` state를 함께 확인하는 것은 "현재 commit 시도 이후에 유효한 응답만 적용한다"는 논리적 happens-before를 인위적으로 복원하는 장치라고 볼 수 있습니다.

7. Actor 직렬화 모델과 mutex 기반 모델을 동시성 이론으로 비교해보세요.

Actor 모델은 공유 상태에 대한 쓰기를 큐 직렬화로 통제하고, mutex 모델은 여러 스레드가 같은 상태를 접근하되 임계구역에서 락으로 충돌을 막습니다. Part E처럼 상태 전이 순서가 중요한 문제에서는 Actor 모델이 deadlock과 lock ordering 부담을 줄이고, 어느 요청이 먼저 처리됐는지 reasoning 하기 쉬운 장점이 있습니다.

8. timeout 취소를 실패 검출(failure detection) 관점으로 설명해보세요.

timeout은 "상대나 사용자가 더 이상 정상적으로 반응하지 않는다"는 의심 신호를 시간 기반으로 감지하는 failure detector 역할을 합니다. 완벽한 검출은 아니지만, 일정 시간 무반응을 실패로 간주해 시스템을 공통 취소 상태로 수렴시키는 실용적 장치입니다.

9. 커밋 성공 후 델타 전송을 캐시 일관성 관점으로 설명해보세요.

클라이언트 인벤토리는 서버 상태의 캐시라고 볼 수 있습니다. 서버가 commit을 끝낸 뒤 `S_REMOVE_ITEM`, `S_CHANGE_ITEM`, `S_GOLD_UPDATE`를 보내는 것은, 변경된 키만 invalidate/update해서 클라이언트 캐시를 최신 서버 상태와 일치시키는 일종의 write-through 갱신으로 해석할 수 있습니다.

10. Part E 전체를 "검증-커밋-수렴" 파이프라인으로 추상화해 설명해보세요.

먼저 검증 단계에서는 상태머신과 Phase 1 계획 수립으로 유효한 거래만 다음 단계로 보냅니다. 그다음 커밋 단계에서는 DBAgent 단일 트랜잭션으로 양측 자산을 함께 확정합니다. 마지막 수렴 단계에서는 성공일 때만 메모리/Redis/클라를 반영하고, 실패는 공통 취소로 모아 시스템 전체를 다시 안정 상태로 되돌립니다.
