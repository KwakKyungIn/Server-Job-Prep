## Section 2: 핵심 차별화 기능 딥다이브 (Page 6~21)

> 편집 기준: 장문 설명 대신 카드/표/다이어그램 중심으로 구성한다.
> 제출 기준: 각 페이지는 그대로 복붙 가능한 문구 + 코드 스니펫 위치를 함께 제공한다.

---

## 2-1. 서버 권위 이동 검증 (Page 6~9)

### Page 6. 서버 권위 이동 검증: 필요한 이유

**레이아웃**
- 상단: 제목 + 한 줄 서브카피
- 본문 좌측: `클라이언트 신뢰 시 실제 문제` 카드 3개
- 본문 우측: `서버 권위 설계 원칙` + `검증 경계` 리스트
- 하단: `위협-대응 구조 다이어그램`

**페이지 역할/범위 (중복 방지 기준)**
- 이 페이지는 `왜 필요한가`만 다룬다: 위협 모델, 설계 원칙, 불변조건
- 검증 단계 상세(`seq/dt/speed/navmesh` 순서)는 Page 7~8에서 메인으로 다룬다
- 로그/수치 기반 증명은 Page 9에서 메인으로 다룬다
- Actor/JobQueue 직렬화 메커니즘은 Section 3 Page 22에서 상세히 다룬다
- 패킷 프레이밍/CRC/복호화 신뢰 경로는 Section 3 Page 24에서 상세히 다룬다

**상단 카피 (복붙용)**
- 제목: `2-1. 서버 권위 이동 검증: 필요한 이유`
- 서브카피: `클라이언트 입력은 제안, 위치 확정은 서버 책임`
- 핵심 메시지: `"이동은 클라이언트 입력일 뿐, 최종 위치는 서버가 검증 후 확정한다."`
- 페이지 질문: `왜 클라이언트 좌표를 그대로 반영하면 월드 정합성이 깨지는가?`

**좌측 카드 카피 | 클라이언트 신뢰 시 실제 문제**
| 항목 | 문제 | 결과 |
| --- | --- | --- |
| 1 | 속도핵/텔레포트 | 짧은 시간 과도한 거리 이동 |
| 2 | 벽 통과/비정상 지형 진입 | 월드 규칙 붕괴 |
| 3 | 시퀀스 역전/재전송/시간값 왜곡 | 과거 상태가 현재 상태를 덮어쓰거나 비정상 이동 허용 |

- 요약 한 줄: `월드 상태 오염 -> 전투 공정성 저하 -> 클라이언트 간 Desync`

**우측 카드 카피 | 서버 권위 설계 원칙**
- 서버가 `seq`, `dt`, `speed`, `navmesh`를 순차 검증
- 비정상 요청은 `drop`, 경계 요청은 `clamp/slide`
- 검증 완료 좌표만 월드 상태에 `commit`
- 확정 결과만 AOI 대상에 `S_MOVE` 브로드캐스트
- 검증 실패 요청은 `상태 미변경(no commit/no broadcast)`으로 수렴

**검증 경계 (제출 포인트)**
- 입력 안정성: NaN/Inf/Crazy Position 즉시 거부
- 순서/시간: 역순 `seq` drop, `dt` 최소/최대 보정
- 속도: 허용 거리 초과 시 이동 거리 제한
- 지형: `ValidateMove` 통과 좌표만 반영

**Page 6에서 강조할 불변조건 (심사 포인트)**
- 불변조건 A: 검증 실패 입력은 월드 상태를 바꾸지 않는다
- 불변조건 B: 이동 상태 커밋은 단일 경로에서만 수행된다
- 불변조건 C: 브로드캐스트 payload는 요청 좌표가 아니라 서버 확정 좌표다
- 불변조건 D: 다음 검증 기준(`last seq/time`)은 commit 시점 기준으로만 전진한다

**하단 다이어그램 (복붙용)**
```mermaid
flowchart LR
  A[Client Sends Position] --> B{Trust Client As-Is?}
  B -->|Yes| C1[Speed Hack / Teleport]
  B -->|Yes| C2[Wall Clip / Invalid Terrain]
  B -->|Yes| C3[Seq Reorder / Replayed Packet]
  C1 --> D[World State Corruption]
  C2 --> D
  C3 --> D
  D --> E[Combat Fairness Break + Desync]
  B -->|No: Server Authoritative| F[Server Validation]
  F --> G[Seq Check + dt Clamp + Speed Check + NavMesh]
  G --> H[Commit + S_MOVE Broadcast]
  H --> I[Consistent Shared World]
```

**코드 근거 포인트 (상세 해설은 후속 페이지)**
- 입력 진입/룸 큐 위임: `GameServer/ClientPacketHandler.GamePlay.cpp:8`
- 이동 검증/커밋 본체: `GameServer/GameRoom.Move.cpp:29`
- 검증 유틸(`seq/dt/speed`): `GameServer/MoveValidationUtils.h:19`, `GameServer/MoveValidationUtils.h:28`, `GameServer/MoveValidationUtils.h:57`
- 상세 코드 해설 위치: Page 7~9, Section 3 Page 22/24

**하단 캡션**
- `클라이언트는 제안하고, 서버가 검증 후 확정한다.`

---

### Page 7-8. 이동 검증 파이프라인

**페이지 역할/범위 (중복 방지 기준)**
- Page 7은 `Stage 1 입력 정규화`를 메인으로 다룬다.
- Page 8은 `Stage 2 지형 검증/상태 확정`을 메인으로 다룬다.
- Page 9는 로그/좌표 비교 기반 증명을 메인으로 다룬다.
- Actor 직렬화 구조 상세는 Section 3 Page 22에서 다룬다.
- 패킷 프레이밍/CRC/복호화는 Section 3 Page 24에서 다룬다.

**Page 7 레이아웃**
- 상단: 제목 + 단계 정의 서브카피
- 본문 상단: Stage 1 흐름도
- 본문 하단 좌측: Stage 1 처리 단계(1~4)
- 본문 하단 우측: Stage 1 분기 결정 매트릭스

**Page 7 상단 카피 (복붙용)**
- 제목: `2-1. 이동 검증 체인 (Stage 1/2)`
- 서브카피: `입력 수신 -> 안정성 검사 -> 순서/시간/속도 검증`
- 핵심 문장: `Stage 1의 목적은 요청 좌표를 즉시 확정하지 않고, 검증 가능한 서버 기준 후보 좌표(reqClamped)로 정규화하는 것이다.`

**Page 7 본문 카피 | Stage 1 처리 단계**
1. `Handle_C_MOVE` 수신 후 RoomActor Queue enqueue (동일 룸 직렬 처리)
2. 입력 안정성 검사 (NaN/Inf/CrazyPos/Out-of-Bounds 즉시 거부)
3. 순서/시간 검사 (`IsSeqNewer`, `ComputeDtSec`)
4. 속도 검사 (`CheckSpeed2D`) 후 `reqClamped` 산출

**Page 7 핵심 산출물 계약**
- 성공 경로 산출물: `reqClamped` (Stage 2 입력)
- 실패 경로 산출물: 없음 (`drop`, `no commit`, `no broadcast`)
- Stage 1 종료 시점에는 월드 좌표를 확정하지 않는다

**Page 7 분기 결정 매트릭스 (복붙용)**
| 입력 상태 | 판정 기준 | 서버 처리 | Stage 2 전달 |
| --- | --- | --- | --- |
| 입력 이상 | NaN/Inf/CrazyPos | `drop` | X |
| 순서 역전 | `IsSeqNewer == false` | `drop` | X |
| 속도 초과 | `CheckSpeed2D == over` | `clamp` 적용 | O (`reqClamped`) |
| 정상 입력 | 모든 검사 통과 | 그대로 유지 | O (`reqRaw`/`reqClamped`) |

**Page 8에서 이어질 내용 (요약만)**
- `ValidateMove` 통과 좌표만 `commit`
- Zone/AOI 갱신 후 `S_MOVE` 전파
- 최종 `MoveStamp` 갱신으로 다음 검증 기준 업데이트

**다이어그램 (복붙용)**
```mermaid
flowchart TD
  A[C_MOVE 수신] --> B[RoomActor enqueue]
  B --> C{입력 안정성 검사}
  C -->|Fail| X1[DROP]
  C -->|Pass| D{Seq + dt 검사}
  D -->|Fail| X2[DROP]
  D -->|Pass| E{속도 검사}
  E -->|Over| F[Clamp -> reqClamped]
  E -->|OK| G[요청 좌표 유지]
  F --> H[Stage 2 전달]
  G --> H
```

**코드 스니펫 배치**
- Page 7 Snippet A (입력/순서/시간/속도): `GameServer/GameRoom.Move.cpp:45`, `GameServer/GameRoom.Move.cpp:75`, `GameServer/GameRoom.Move.cpp:90`, `GameServer/GameRoom.Move.cpp:102`
- Page 8 Snippet B (NavMesh/commit/AOI): `GameServer/GameRoom.Move.cpp:117`, `GameServer/GameRoom.Move.cpp:151`, `GameServer/GameRoom.Move.cpp:155`, `GameServer/GameRoom.Move.cpp:168`
- 보정 근거 Snippet C: `GameServer/NavSystem.cpp:182`

**하단 캡션**
- `Stage 1은 입력을 정규화하고, Stage 2는 검증 통과 좌표만 월드 상태로 확정한다.`

---

### Page 9. 이동 검증 결과 (로그/좌표 보정 사례)

**레이아웃**
- 상단: 테스트 목표 한 줄
- 본문 좌측: 실패 케이스 카드
- 본문 우측: 보정 케이스 카드
- 하단: `요청 좌표 vs 서버 확정 좌표` 비교 표

**상단 카피 (복붙용)**
- 제목: `2-1. 검증 결과: 서버가 실제로 막는가?`
- 서브카피: `로그 + 좌표 비교로 drop/clamp 동작을 증명`

**실패 케이스 카드**
- 케이스: `MOVE_SEQ_REWIND_DROP`
- 요청: 과거 `seq` 재전송
- 서버 처리: 즉시 drop
- 결과: 위치 미변경

**보정 케이스 카드**
- 케이스: `SPEED_EXCEEDED_CLAMP`
- 요청: 허용 이동거리 초과
- 서버 처리: clamp 후 NavMesh 재검증
- 결과: 보정 좌표로 commit

**비교 표 템플릿 (복붙용)**
| 시나리오 | reqDist2D | maxDist | 서버 처리 | 최종 좌표 |
| --- | --- | --- | --- | --- |
| 역순 seq | - | - | drop | 변경 없음 |
| 과속 이동 | (측정값) | (허용값) | clamp + validate | (보정 좌표) |

**코드 스니펫/로그 근거**
- 로그 포인트: `GameServer/GameRoom.Move.cpp:83`, `GameServer/GameRoom.Move.cpp:108`
- 결론 문구: `비정상 이동 요청은 서버에서 drop/clamp되어 월드 정합성이 유지된다.`

---

## 2-2. AOI 최적화 + 스냅샷 배칭 (Page 10~12)

### Page 10. 전송 대상 축소가 필요한 이유

**페이지 역할/범위 (중복 방지 기준)**
- 이 페이지는 `왜 AOI를 먼저 도입해야 하는가`를 메인으로 다룬다: 문제 정의, 설계 선택 기준, 도입 효과.
- `SpatialGrid/Connectivity`의 상세 분기와 필터 파이프라인은 Page 11에서 메인으로 다룬다.
- `snapshot begin/end` 경계와 배칭 전송 정책은 Page 12에서 메인으로 다룬다.
- 실제 부하 수치(p95/RPS/오류율)와 운영 검증은 Section 5 Page 35~37에서 메인으로 다룬다.
- 따라서 Page 10에서는 알고리즘 내부 구현/실험 수치를 깊게 파고들지 않고, 설계 방향과 판단 근거를 중심으로 제시한다.

**레이아웃**
- 상단: 문제 정의
- 본문 좌측: 브로드캐스트 한계
- 본문 우측: AOI 전략
- 하단: `Before vs After` 비교 박스

**상단 카피 (복붙용)**
- 제목: `2-2. AOI 최적화: 먼저 대상을 줄인다`
- 서브카피: `패킷 크기보다 먼저, 보내는 대상 수를 줄여야 한다`
- 페이지 질문: `왜 직렬화/압축 이전에 수신자 집합을 줄이는 설계를 먼저 선택했는가?`

**좌측 카드 | 브로드캐스트 방식의 한계**
- 엔티티 증가 시 `O(N x M)` 전송 루프 확대
- CPU: 직렬화/필터 루프 비용 증가
- 네트워크: 송신 버퍼 급증, 지연 확대

**우측 카드 | AOI 적용 전략**
- `SpatialGrid`로 후보군 1차 축소
- 거리 + Connectivity로 2차 필터링
- 최종 가시 집합만 전송

**정량 인식 포인트 (복붙용)**
- Tick당 전송 대상 근사: `targets_per_tick = sender_count x avg_receivers_per_sender`
- 전체 브로드캐스트 구간에서는 `avg_receivers_per_sender`가 룸 인원 증가에 따라 선형 확대된다.
- AOI 적용 구간에서는 `avg_receivers_per_sender`를 `visible_set_size`로 제한해 비용 상한을 낮춘다.
- 핵심은 "패킷 1개를 가볍게"보다 "보낼 대상 자체를 줄이는 구조"다.

**하단 비교 카피**
| 구분 | 기존 | 개선 |
| --- | --- | --- |
| 대상 선정 | 전체 브로드캐스트 | AOI 후보군 한정 |
| 판정 기준 | 거리 위주 | 거리 + 연결성 |
| 결과 | 불필요 전송 다수 | 유효 대상 중심 전송 |

**Page 10 산출물 계약 (Page 11~12 연결)**
- Page 11 입력 계약: `후보군 수집 -> 거리/연결성 필터`로 가시 후보를 결정한다.
- Page 12 입력 계약: 확정된 가시 집합을 `snapshot begin/end` 경계 규칙으로 배칭 전송한다.
- 빈 가시 집합이어도 경계 패킷 규칙(begin/end)은 유지한다(상세 규칙은 Page 12에서 설명).

**코드 스니펫 배치**
- Snippet 9-A (후보군 수집): `GameServer/GameRoom.AOI.v2.cpp:25`
- Snippet 9-B (Zone 반경 조회): `GameServer/SpatialGrid.cpp:106`
- Snippet 9-C (AOI 갱신 스로틀): `GameServer/GameRoom.AOI.v2.cpp:46`

**하단 캡션**
- `AOI는 브로드캐스트 최적화가 아니라 전송 대상을 구조적으로 제한하는 설계다.`

---

### Page 11. SpatialGrid + Connectivity 필터

**페이지 역할/범위 (중복 방지 기준)**
- 이 페이지는 `가시 대상을 어떻게 결정하는가`를 메인으로 다룬다: 후보군 수집 -> 거리/연결성 필터 -> Old/New diff.
- 스냅샷 경계(`snapshot begin/end`)와 배칭 전송 정책은 Page 12에서 메인으로 다룬다.
- 실제 운영 수치(p95/RPS/오류율) 검증은 Section 5 Page 35~37에서 메인으로 다룬다.
- 따라서 Page 11은 알고리즘 판정 규칙과 입출력 계약을 중심으로 설명한다.

**레이아웃**
- 상단: 필터 목적 + 핵심 판정 문장
- 본문 좌측: 갱신 트리거 + Broad Phase 후보군 수집
- 본문 우측: Narrow Phase + Diff/동기화 규칙
- 하단: 필터 파이프라인 + 입출력 계약 표

**상단 카피 (복붙용)**
- 제목: `2-2. 후보 축소 + 연결성 검증`
- 서브카피: `가까워도 연결되지 않으면 보이지 않게 만든다`
- 핵심 문장: `AOI는 거리와 연결성을 모두 통과한 대상만 가시 집합으로 확정한다.`

**본문 카피**
- 0단계 갱신 트리거: `zoneChanged` 또는 `lazyUpdateTickMs/lazyUpdateDist` 조건 충족 시 `UpdateAOI` 실행
- 1단계 Broad Phase: `SpatialGrid::GetNearbyZones`로 인접 Zone 후보(플레이어/몬스터/투사체) 수집
- 2단계 Narrow Phase: `PassDistance2D` + `Connectivity`를 모두 통과한 대상만 `NewVis`에 채택
- 3단계 Diff: `OldVis`와 `NewVis` 비교로 `toSpawn/toDespawn` 계산
- 4단계 동기화: 몬스터/투사체 `Viewers`를 갱신하고 Spawn/Despawn를 전송

**입출력 계약 (복붙용)**
| 구분 | 입력 | 출력 |
| --- | --- | --- |
| 필터 입력 | `me.pos`, `me.zoneIndex`, `myConn`, 인접 Zone 후보군 | 거리/연결성 통과 집합(`NewVis`) |
| Diff 입력 | `OldVis`, `NewVis` | `toSpawn`, `toDespawn` |
| 전송 입력 | `toSpawn`, `toDespawn` | Spawn/Despawn 패킷 (배칭/경계 규칙은 Page 12) |

**다이어그램 (복붙용)**
```mermaid
flowchart TD
  A{ShouldUpdateAOI?} -->|No| X0[이번 Tick 스킵]
  A -->|Yes| B[SpatialGrid 인접 Zone 수집]
  B --> C[후보 엔티티 집합]
  C --> D{거리 검사}
  D -->|Fail| X1[제외]
  D -->|Pass| E{Connectivity 검사}
  E -->|Fail| X2[제외]
  E -->|Pass| F[NewVis 추가]
  F --> G[OldVis diff 계산]
  G --> H[toSpawn/toDespawn 생성]
  H --> I[Viewers 동기화]
  I --> J[Spawn/Despawn 전송]
```

**코드 스니펫 배치**
- Snippet 10-A (갱신 트리거 + 후보군 수집): `GameServer/GameRoom.AOI.v2.cpp:46`, `GameServer/GameRoom.AOI.v2.cpp:185`, `GameServer/GameRoom.AOI.v2.cpp:197`
- Snippet 10-B (거리/연결성 필터 + 투사체 포함): `GameServer/GameRoom.AOI.v2.cpp:219`, `GameServer/GameRoom.AOI.v2.cpp:223`, `GameServer/GameRoom.AOI.v2.cpp:247`, `GameServer/GameRoom.AOI.v2.cpp:262`
- Snippet 10-C (Diff + Viewers 동기화): `GameServer/GameRoom.AOI.v2.cpp:300`, `GameServer/GameRoom.AOI.v2.cpp:314`, `GameServer/GameRoom.AOI.v2.cpp:349`, `GameServer/GameRoom.AOI.v2.cpp:364`
- Snippet 10-D (반경 조회 구현): `GameServer/SpatialGrid.cpp:106`

**하단 캡션**
- `Page 11은 가시 대상 결정 규칙을 확정하고, Page 12는 이 결과를 경계 기반 배칭 전송으로 마무리한다.`

---

### Page 12. 스냅샷 배칭 전송 결과

**페이지 역할/범위 (중복 방지 기준)**
- 이 페이지는 `확정된 가시 집합을 어떻게 안전하게 전송 완료로 닫는가`를 메인으로 다룬다.
- 가시 집합 결정(후보군/거리/연결성/Diff)은 Page 11에서 메인으로 다룬다.
- 운영 지표(p95/RPS/오류율) 기반 효과 검증은 Section 5 Page 35~37에서 메인으로 다룬다.
- 따라서 Page 12는 경계 플래그, 배치 분할, 예외 수렴 규칙에 집중한다.

**레이아웃**
- 상단: 입장 시 버스트 문제 정의
- 본문 좌측: 스냅샷 경계 처리
- 본문 우측: 배칭 전송 정책
- 하단: 입력/출력 계약 + begin/end 시퀀스 타임라인

**상단 카피 (복붙용)**
- 제목: `2-2. Snapshot Batching: 입장 버스트 완화`
- 서브카피: `snapshot_id + begin/end로 경계를 명확히 보낸다`
- 핵심 문장: `Page 12의 목적은 전송량 감소가 아니라, 전송 완료 시점을 프로토콜로 확정하는 것이다.`

**좌측 카드 | 스냅샷 경계 규칙**
- 스냅샷 시작 시점마다 `NextSnapshotSeq`로 새로운 `snapshot_id`를 발급한다.
- 동일 스냅샷 묶음은 같은 `snapshot_id`를 유지한다.
- 첫 패킷: `snapshot_begin=true`
- 마지막 패킷: `snapshot_end=true`
- 빈 스냅샷도 `begin=true,end=true` 단일 패킷을 전송해 로딩 정지 방지

**우측 카드 | 배칭 정책**
- 엔티티를 배치 단위로 분할 송신한다(플레이어/몬스터/투사체).
- `forceFullSnapshot` 경로에서 경계 플래그 규칙을 강제한다.
- 일반 경로는 스냅샷 플래그 없이 변경분만 전송한다.
- `S_DESPAWN` 배칭은 별도 경로로 처리하며 스냅샷 경계 규칙 대상이 아니다.
- 클라이언트는 `snapshot_end=true` 수신으로 완료 시점을 확정한다.

**입력/출력 계약 (복붙용)**
| 구분 | 입력 | 출력 |
| --- | --- | --- |
| 스냅샷 입력 | `toSpawn*`, `snapshotMode`, `snapshotId` | 배치된 `S_SPAWN` 리스트 |
| 경계 처리 | 패킷 리스트(front/back) | `begin/end` 플래그가 부여된 전송 순서 |
| 예외 수렴 | `snapshotMode && pkts.empty()` | `begin=true,end=true` 단일 패킷 전송 |
| 비대상 경로 | `toDespawn*` | 경계 플래그 없이 `S_DESPAWN` 배칭 전송 |

**하단 타임라인 (복붙용)**
1. `S_SPAWN(snapshot_id=K, begin=true, end=false)`
2. `S_SPAWN(snapshot_id=K, begin=false, end=false)` x N
3. `S_SPAWN(snapshot_id=K, begin=false, end=true)`

**forceFullSnapshot 트리거 (요약)**
- `EnterGame` 경로: `UpdateAOI(..., true)`로 입장 직후 풀 스냅샷 전송
- `EnterMapChange` 경로: `UpdateAOI(..., true)`로 맵 이동 직후 풀 스냅샷 전송

**코드 스니펫 배치**
- Snippet 11-A (경계 플래그 + 빈 스냅샷 수렴): `GameServer/GameRoom.AOI.v2.cpp:130`, `GameServer/GameRoom.AOI.v2.cpp:143`, `GameServer/GameRoom.AOI.v2.cpp:144`, `GameServer/GameRoom.AOI.v2.cpp:457`, `GameServer/GameRoom.AOI.v2.cpp:460`
- Snippet 11-B (forceFullSnapshot 배칭): `GameServer/GameRoom.AOI.v2.cpp:393`, `GameServer/GameRoom.AOI.v2.cpp:407`, `GameServer/GameRoom.AOI.v2.cpp:425`, `GameServer/GameRoom.AOI.v2.cpp:436`, `GameServer/GameRoom.AOI.v2.cpp:466`, `GameServer/GameRoom.AOI.v2.cpp:467`
- Snippet 11-C (일반 경로 분기): `GameServer/GameRoom.AOI.v2.cpp:473`, `GameServer/GameRoom.AOI.v2.cpp:476`
- Snippet 11-D (입장/맵이동 트리거): `GameServer/GameRoom.EnterLeave.cpp:89`, `GameServer/GameRoom.EnterLeave.cpp:126`

**하단 캡션**
- `경계 기반 배칭 전송은 대량 스폰 구간에서도 완료 시점을 명확히 고정해 초기 동기화 불확실성을 줄인다.`

---

## 2-3. 전투/투사체 서버 판정 (Page 13~16)

### Page 13. 스킬 판정 구조 (즉발/범위/부채꼴)

**페이지 역할/범위 (중복 방지 기준)**
- 이 페이지는 `즉발/범위/부채꼴` 스킬의 서버 판정 경로와 피해 반영 계약을 메인으로 다룬다.
- `SKILL_PROJECTILE`의 Tick 시뮬레이션/충돌 처리 본문은 Page 14에서 메인으로 다룬다.
- 쿨타임/중복 타격 차단의 상세 규칙은 Page 15에서 메인으로 다룬다.
- 사망 이후 AI/드랍/리스폰 처리 흐름은 Page 16에서 메인으로 다룬다.

**레이아웃**
- 상단: 서버 판정 책임 + 진입 가드
- 본문 좌측: 타입별 판정 규칙 + 후보군 수집 기준
- 본문 우측: 판정 성공/실패 전파 계약
- 하단: 요청 -> 판정 -> 피해 반영 흐름 + 입력/출력 계약

**상단 카피 (복붙용)**
- 제목: `2-3. 스킬 판정은 서버에서 확정`
- 서브카피: `클라이언트는 요청, 명중/피해는 서버가 결정`
- 핵심 문장: `통과한 요청만 피해 반영으로 이어지고, 실패 요청은 서버에서 즉시 차단된다.`

**진입 가드 (요청 차단 조건)**
- 공격자가 현재 룸 소속인지 확인 (`attacker->GetRoom() == this`)
- 스킬 템플릿 유효성 확인 (`GetSkillTemplate`)
- 공격자 생존 상태 확인 (`hp > 0`, `ACTION_DEAD != true`)
- 쿨타임 사용 가능 여부 확인 (`CanUseSkill`)
- `SKILL_PROJECTILE`은 즉시 판정 페이지가 아니라 Page 14 경로로 분기

**타입별 판정 표**
| 타입 | 판정 방식 | 특징 |
| --- | --- | --- |
| `SKILL_AUTO` | `CheckCircle(singleRange)` | 즉발 단일 판정(첫 적중 후 종료) |
| `SKILL_AREA_CIRCLE` | `CheckCircle(circleRadius)` | 반경 내 다수 판정 |
| `SKILL_AREA_CONE` | `CheckFan(coneRange, coneAngle)` | 전방 각도 기반 판정(기본 90도 보정) |

**후보군 수집 기준**
- `CollectCandidates`가 공격자 주변 Zone 후보군만 먼저 수집한다.
- 플레이어 공격은 몬스터 후보군, 몬스터 공격은 플레이어 후보군을 대상으로 판정한다.
- 전체 맵 순회 대신 주변 Zone 기반 수집으로 판정 범위를 제한한다.

**전파 계약**
- 판정 성공 시에만 서버가 쿨타임을 소모한다(`StartSkillCooldown`).
- `S_SKILL`로 사용 사실을 먼저 전파하고, `S_CHANGE_HP`로 대상별 결과를 전파한다.
- 가드 실패/판정 실패 요청은 전파 없이 서버에서 종료한다.

**입력/출력 계약 (복붙용)**
| 구분 | 입력 | 출력 |
| --- | --- | --- |
| 판정 입력 | `attacker`, `skillId`, `castYaw` | `SkillResult(zoneIndex, hits)` |
| 성공 경로 | `ResolveSkill == true` | `S_SKILL` + 대상별 `S_CHANGE_HP` |
| 차단 경로 | 룸 불일치/사망/쿨타임 실패/템플릿 실패 | 전파 없음(서버 종료) |

**다이어그램 (복붙용)**
```mermaid
flowchart TD
  A[C_SKILL] --> B[GameRoom::HandleSkill]
  B --> C{진입 가드 통과}
  C -->|No| X[요청 차단]
  C -->|Yes| D{SkillType}
  D -->|PROJECTILE| P[Page 14 경로]
  D -->|AUTO/CIRCLE/CONE| E[ResolveSkill]
  E --> F{판정 성공}
  F -->|No| X
  F -->|Yes| G[StartSkillCooldown]
  G --> H[S_SKILL 전파]
  H --> I[OnDamaged 결과 반영]
  I --> J[S_CHANGE_HP 전파]
```

**코드 스니펫 배치**
- Snippet 12-A (진입 가드 + 분기): `GameServer/GameRoom.Combat.cpp:17`, `GameServer/GameRoom.Combat.cpp:22`, `GameServer/GameRoom.Combat.cpp:27`, `GameServer/GameRoom.Combat.cpp:37`, `GameServer/GameRoom.Combat.cpp:46`
- Snippet 12-B (타입별 판정 + 파라미터 보정): `GameServer/BattleSystem.cpp:44`, `GameServer/BattleSystem.cpp:51`, `GameServer/BattleSystem.cpp:86`, `GameServer/BattleSystem.cpp:97`, `GameServer/BattleSystem.cpp:107`, `GameServer/BattleSystem.cpp:137`
- Snippet 12-C (후보군 수집 기준): `GameServer/BattleSystem.cpp:66`, `GameServer/BattleSystem.cpp:146`, `GameServer/BattleSystem.cpp:162`, `GameServer/BattleSystem.cpp:171`
- Snippet 12-D (성공 경로 전파): `GameServer/GameRoom.Combat.cpp:123`, `GameServer/GameRoom.Combat.cpp:127`, `GameServer/GameRoom.Combat.cpp:142`

**하단 캡션**
- `즉발/범위 스킬은 서버 가드와 판정 경로를 통과한 경우에만 피해 결과가 확정된다.`

---

### Page 14. 투사체 시뮬레이션 (충돌/NavMesh 레이캐스트)

**페이지 역할/범위 (중복 방지 기준)**
- 이 페이지는 `투사체 Tick 실행 -> 이동 -> 충돌 -> 소멸` 결정 경로를 메인으로 다룬다.
- 스킬 요청 진입 가드/즉발 판정 본문은 Page 13에서 메인으로 다룬다.
- 중복 타격 이력(`HasAlreadyHit/MarkHit`)과 쿨타임 축은 Page 15에서 메인으로 다룬다.
- 처치 이후 AI/드랍/리스폰은 Page 16에서 메인으로 다룬다.
- 성능 수치(p95/RPS/오류율) 검증은 Section 5에서 메인으로 다룬다.

**레이아웃**
- 상단: Tick 기반 처리 원칙 + 종료 조건
- 본문 좌측: 이동/벽 충돌 보정
- 본문 우측: 대상 충돌 판정 순서
- 하단: 투사체 업데이트 파이프라인 + 입력/출력 계약

**상단 카피 (복붙용)**
- 제목: `2-3. 투사체도 서버 Tick에서 판정`
- 서브카피: `벽 충돌 + 대상 충돌을 순서대로 계산`
- 핵심 문장: `한 Tick에서 이동, 충돌, 소멸 기준을 같은 서버 경로에서 확정한다.`

**좌측 카드 | 이동/벽 충돌 처리**
- `Projectile::Update(deltaMs)`에서 `deltaMs`를 최대 100ms로 제한해 과도 이동을 차단한다.
- 이동 후 `oldPos -> newPos` 구간을 `RaycastNav`로 검사한다.
- `tWall < 1.0`이면 충돌 지점으로 좌표를 보정하고 `shouldDespawn=true`로 수렴한다.
- 틱 종료 시 `shouldDespawn || IsExpired()` 조건으로 삭제를 확정한다.

**우측 카드 | 대상 충돌 처리**
- 유효성 가드: 스킬 템플릿/소유자가 없으면 즉시 제거한다.
- 후보군 범위: `oldZone` + `newZone` 주변 Zone을 합쳐 고속 이동 누락을 줄인다.
- 후보 필터: 생존 대상 + 연결성(Connectivity) 일치 대상만 충돌 검사한다.
- 충돌 검사: `SegmentCircleHitXZ`로 `t(0~1)`를 구해 충돌 후보를 수집한다.
- 확정 순서: `t` 오름차순 정렬 후 `OnDamaged -> S_CHANGE_HP` 전파를 수행한다.
- 종료 기준: `stopOnHit` 또는 `HitCount >= maxHits`면 소멸 처리한다.
- 중복 타격 이력의 상세 규칙은 Page 15에서 별도 설명한다.

**입력/출력 계약 (복붙용)**
| 구분 | 입력 | 출력 |
| --- | --- | --- |
| Tick 입력 | `deltaMs`, `oldPos/newPos`, `skillData`, `owner` | 이동/충돌 판정 결과 |
| 충돌 입력 | 후보 Zone 집합, `hitRadius`, Connectivity, 선분 경로 | 정렬된 hit 목록(`t` 기준) |
| Tick 출력 | `S_CHANGE_HP`, 투사체 위치 동기화, `toRemove` 집합 | `LeaveProjectile` 소멸 처리 |

**다이어그램 (복붙용)**
```mermaid
flowchart TD
  A[UpdateProjectiles Tick] --> B{skillData/owner 유효?}
  B -->|No| X[제거 목록 추가]
  B -->|Yes| C[Projectile::Update]
  C --> D[oldPos/newPos 확보]
  D --> E{RaycastNav 충돌?}
  E -->|Yes| F[충돌 지점 보정 + shouldDespawn]
  E -->|No| G[old/new Zone 후보 수집]
  G --> H[Connectivity + SegmentCircleHitXZ]
  H --> I[t 기준 정렬]
  I --> J[OnDamaged + S_CHANGE_HP]
  J --> K{stopOnHit/maxHits}
  K -->|Yes| L[소멸]
  K -->|No| M[OnProjectileMoved]
  L --> M
  M --> N{IsExpired or shouldDespawn}
  N -->|Yes| O[LeaveProjectile]
  N -->|No| P[다음 Tick]
```

**코드 스니펫 배치**
- Snippet 13-A (Tick 이동 + 만료): `GameServer/Projectile.cpp:68`, `GameServer/Projectile.cpp:77`, `GameServer/Projectile.cpp:54`, `GameServer/Projectile.cpp:60`
- Snippet 13-B (유효성 가드 + 벽 충돌 보정): `GameServer/GameRoom.Projectile.cpp:277`, `GameServer/GameRoom.Projectile.cpp:299`, `GameServer/GameRoom.Projectile.cpp:314`, `GameServer/GameRoom.Projectile.cpp:321`, `GameServer/GameRoom.Projectile.cpp:333`
- Snippet 13-C (후보군 병합 + 충돌 계산): `GameServer/GameRoom.Projectile.cpp:353`, `GameServer/GameRoom.Projectile.cpp:363`, `GameServer/GameRoom.Projectile.cpp:411`, `GameServer/GameRoom.Projectile.cpp:444`
- Snippet 13-D (피해 전파 + 종료): `GameServer/GameRoom.Projectile.cpp:463`, `GameServer/GameRoom.Projectile.cpp:478`, `GameServer/GameRoom.Projectile.cpp:487`, `GameServer/GameRoom.Projectile.cpp:490`

**하단 캡션**
- `투사체는 서버 Tick 경로에서 이동, 충돌, 소멸을 순차 확정해 고속 이동 구간의 판정 누락을 줄인다.`

---

### Page 15. 쿨타임 서버 검증 + 중복 타격 방지

**페이지 역할/범위 (중복 방지 기준)**
- 이 페이지는 `연속 입력 차단(쿨타임)`과 `동일 투사체 재타격 차단(hit set)`을 메인으로 다룬다.
- 스킬 요청 진입 가드와 즉발/범위 판정 본문은 Page 13에서 메인으로 다룬다.
- 투사체 이동/충돌/소멸 Tick 경로는 Page 14에서 메인으로 다룬다.
- 처치 이후 AI/드랍/리스폰은 Page 16에서 메인으로 다룬다.
- 운영 수치(p95/RPS/오류율) 기반 효과 검증은 Section 5에서 메인으로 다룬다.

**레이아웃**
- 상단: 두 방어 축의 목적
- 본문 좌측: 서버 시간 기반 쿨타임 검증
- 본문 우측: 투사체 hit 이력 기반 중복 차단
- 하단: 차단 매트릭스 + 입력/출력 계약

**상단 카피 (복붙용)**
- 제목: `2-3. 연사/중복 히트 방어`
- 서브카피: `쿨타임은 서버 시간, 타격 기록은 서버 집합`
- 핵심 문장: `같은 입력이 반복돼도 서버 검증을 통과한 결과만 피해로 반영한다.`

**좌측 카드 | 쿨타임 검증**
- `CanUseSkill`에서 템플릿 유효성과 만료 시각(`_cooldowns[skillId]`)을 검사한다.
- 기준 시간은 `GetTickCount64`이며 클라이언트 시각(`clientTimeMs`)은 판정 기준으로 사용하지 않는다.
- `StartSkillCooldown`은 스킬별 만료 시각을 `now + cooldownMs`로 갱신한다.
- 쿨타임 소모 시점:
  - `SKILL_PROJECTILE`: 투사체 생성 경로 진입 시 즉시 소모
  - 즉발/범위(`ResolveSkill` 경로): 판정 성공 시에만 소모

**우측 카드 | 중복 타격 방지**
- 투사체별 `_hitVictims` 집합과 `_hitCount`를 런타임 상태로 관리한다.
- 충돌 후보 단계에서 `HasAlreadyHit(victimId)`면 즉시 제외한다.
- 피해 확정 직후 `MarkHit(victimId)`로 이력을 기록한다.
- 오브젝트 풀 재사용 시 `ResetHitState`로 이전 이력을 초기화해 잔존 상태를 제거한다.
- `stopOnHit` 또는 `maxHits` 도달 시 즉시 소멸 경로로 수렴한다.

**차단 매트릭스 (복붙용)**
| 케이스 | 서버 검증 | 결과 |
| --- | --- | --- |
| 같은 스킬 연속 입력(쿨타임 미만) | `CanUseSkill == false` | 요청 차단, 전파 없음 |
| 투사체 동일 대상 재충돌 | `HasAlreadyHit == true` | 후보 제외, 피해 미반영 |
| 투사체 최대 타격 수 초과 | `HitCount >= maxHits` | 추가 타격 중단, 소멸 경로 진입 |
| 투사체 단발 설정 | `stopOnHit == true` | 첫 타격 후 소멸 |

**입력/출력 계약 (복붙용)**
| 구분 | 입력 | 출력 |
| --- | --- | --- |
| 쿨타임 입력 | `skillId`, 현재 서버 시각, `_cooldowns` | 사용 가능 여부 + 만료 시각 갱신 |
| hit 이력 입력 | `victimId`, `_hitVictims`, `_hitCount` | 재타격 차단 또는 타격 이력 누적 |
| 방어 출력 | 검증 실패/차단 조건 | 피해 미반영 또는 소멸 수렴 |

**코드 스니펫 배치**
- Snippet 14-A (서버 시간 쿨타임): `GameServer/Creature.cpp:54`, `GameServer/Creature.cpp:62`, `GameServer/Creature.cpp:77`, `GameServer/Creature.cpp:85`
- Snippet 14-B (요청 경로 쿨타임 소모 시점): `GameServer/GameRoom.Combat.cpp:15`, `GameServer/GameRoom.Combat.cpp:37`, `GameServer/GameRoom.Combat.cpp:49`, `GameServer/GameRoom.Combat.cpp:119`, `GameServer/GameRoom.Combat.cpp:123`
- Snippet 14-C (hit 이력 구조 + 초기화): `GameServer/Projectile.h:53`, `GameServer/Projectile.h:59`, `GameServer/Projectile.h:66`, `GameServer/Projectile.cpp:46`
- Snippet 14-D (충돌 루프 차단 적용): `GameServer/GameRoom.Projectile.cpp:403`, `GameServer/GameRoom.Projectile.cpp:426`, `GameServer/GameRoom.Projectile.cpp:475`, `GameServer/GameRoom.Projectile.cpp:478`

**하단 캡션**
- `연속 입력과 중복 타격은 서버 시간/서버 집합 기준으로 차단돼 피해 산정의 일관성을 유지한다.`

---

### Page 16. 피해 확정 이후 서버 수렴 (AI/보상/리스폰)

**페이지 역할/범위 (중복 방지 기준)**
- 이 페이지는 `피해 확정 이후`의 서버 수렴 경로(AI 반응, 사망 처리, 보상 반영, 리스폰 스케줄)를 메인으로 다룬다.
- 스킬 타입별 판정 규칙(즉발/범위/부채꼴)은 Page 13에서 메인으로 다룬다.
- 투사체 이동/충돌/소멸 Tick 경로는 Page 14에서 메인으로 다룬다.
- 쿨타임/중복 타격 방어 축은 Page 15에서 메인으로 다룬다.
- 맵 전이 핸드셰이크와 세션 전이 보호는 Page 17에서 메인으로 다룬다.
- 운영 지표(p95/RPS/오류율) 기반 효과 검증은 Section 5에서 메인으로 다룬다.

**레이아웃**
- 상단: 피해 확정 이후 수렴 흐름 요약
- 본문 1행 좌측: AI 상태 전이 규칙
- 본문 1행 우측: 사망 처리/보상 확정 단계
- 본문 2행 좌측: 차단/가드 매트릭스
- 본문 2행 우측: 입력/출력 계약
- 하단: end-to-end 다이어그램

**상단 카피 (복붙용)**
- 제목: `2-3. 피해 확정 이후 서버 수렴 경로`
- 서브카피: `AI 반응 -> 사망 처리 -> 보상 반영 -> 리스폰 스케줄`
- 핵심 문장: `전투 결과는 단일 서버 경로에서 정리돼 중복 처리 없이 다음 전투 상태로 수렴한다.`

**1) AI 상태 전이 규칙**
- 기본 상태는 `Idle -> Chase -> Attack -> Return`이며 서버 Tick에서 갱신된다.
- `OnDamaged`에서 공격자 기준으로 타겟을 갱신하고 `Idle/Return`이면 즉시 `Chase`로 전이한다.
- 타겟이 사망/이탈하면 `GetTarget` 검증에서 제거되고 `Return`으로 전환된다.
- 공격 상태는 몬스터 내부 공격 간격(`nowMs - _lastAttackMs`)을 만족할 때만 피해 경로를 호출한다.

**2) 사망 처리/보상 확정 단계**
- `OnDead`는 `ACTION_DEAD` 가드로 중복 진입을 차단한다.
- 사망 후 처리는 `room->PushJob(&GameRoom::HandleMonsterDead, ...)`로 직렬 경로에 위임한다.
- `HandleMonsterDead`는 룸 소속/몬스터 존재 여부(`_monsters`)를 다시 검사해 중복 사망을 차단한다.
- 보상은 `killer == player`일 때만 적용한다(비플레이어 처치자는 EXP/드랍 미지급).
- EXP는 `AddExpAndLevelUp`로 반영하고, `UpdatePlayerCore` + `S_CHANGE_STAT`으로 저장/동기화한다.
- 드랍은 `RollDropGroup` + `TryAutoLootItem` 경로로 처리하며, 미수용 분량은 월드 드랍 확장 지점으로 남겨둔다.
- 마무리는 `OnMonsterDespawned_ActorOnly` -> `LeaveMonster` 순서로 수행해 aliveCount/전파를 정리한다.

**3) 차단/가드 매트릭스 (복붙용)**
| 케이스 | 서버 검증/가드 | 처리 결과 |
| --- | --- | --- |
| 중복 사망 이벤트 | `ACTION_DEAD` 또는 `_monsters` 미존재 | 재처리 중단 |
| 처치 주체가 비플레이어 | `killer == nullptr` | EXP/드랍 스킵, 소멸/리스폰만 진행 |
| 과스폰 위험 | `aliveCount >= maxAlive` | 추가 스폰 차단 |
| 즉시 리스폰 설정 | `respawnMs == 0` | `nextSpawnMs = now`로 즉시 보충 |

**4) 입력/출력 계약 (복붙용)**
| 구분 | 입력 | 출력 |
| --- | --- | --- |
| AI 입력 | 현재 상태, 타겟 유효성, Tick 시간 | 상태 전이(`Idle/Chase/Attack/Return`) |
| 사망 처리 입력 | `attacker`, `monster`, 몬스터 템플릿 | 보상 지급 여부 + 사망 처리 실행 |
| 보상 출력 | EXP/드랍 룰, 인벤토리 상태 | `UpdatePlayerCore`, `S_CHANGE_STAT`, 인벤토리 반영 |
| 월드 정리 출력 | `spawnId`, `aliveCount`, `respawnMs` | `aliveCount/nextSpawnMs` 갱신 + 소멸 전파 |

**다이어그램 (복붙용)**
```mermaid
flowchart TD
  A["OnDamaged(attacker, damage)"] --> B["FSM 갱신 (Idle/Chase/Attack/Return)"]
  B --> C{"HP <= 0"}
  C -->|No| D["전투 지속"]
  C -->|Yes| E["Monster::OnDead (중복 사망 가드)"]
  E --> F["Room JobQueue로 HandleMonsterDead 위임"]
  F --> G{"killer가 Player인가?"}
  G -->|Yes| H["EXP 반영 + S_CHANGE_STAT + AutoLoot"]
  G -->|No| I["보상 스킵"]
  H --> J["OnMonsterDespawned_ActorOnly"]
  I --> J
  J --> K["LeaveMonster + aliveCount 갱신"]
  K --> L["nextSpawnMs 계산 후 리스폰 대기/즉시 보충"]
```

**코드 스니펫 배치**
- Snippet 15-A (AI 상태 전이/FSM): `GameServer/Monster.cpp:110`, `GameServer/Monster.cpp:295`, `GameServer/Monster.cpp:384`, `GameServer/Monster.cpp:486`
- Snippet 15-B (사망 가드 + 직렬 위임): `GameServer/Monster.cpp:500`, `GameServer/Monster.cpp:514`, `GameServer/GameRoom.Items.cpp:699`
- Snippet 15-C (보상/드랍 반영): `GameServer/GameRoom.Items.cpp:34`, `GameServer/GameRoom.Items.cpp:136`, `GameServer/GameRoom.Items.cpp:724`, `GameServer/GameRoom.Items.cpp:750`
- Snippet 15-D (소멸/리스폰 스케줄): `GameServer/GameRoom.Items.cpp:764`, `GameServer/GameRoom.LifeTime.cpp:105`, `GameServer/GameRoom.LifeTime.cpp:153`, `GameServer/GameRoom.LifeTime.cpp:171`

**하단 캡션**
- `피해 확정 이후 처리도 단일 서버 경로에서 수렴돼 중복 보상과 상태 불일치를 차단한다.`

---

## 2-4. 파티/인스턴스/맵 전이 (Page 17~19)

### Page 17. 맵 변경 핸드셰이크

**페이지 역할/범위 (중복 방지 기준)**
- 이 페이지는 `맵 변경 요청 -> 토큰 발급 -> ACK 소비 -> 이동 완료`의 핸드셰이크와 실패 차단 경로를 메인으로 다룬다.
- 전투/사망/리스폰 수렴 로직은 Page 16에서 메인으로 다룬다.
- 파티 멤버십 정합성(TTL/수락 재검증)은 Page 18에서 메인으로 다룬다.
- 인스턴스 생성/종료/정리 생명주기는 Page 19에서 메인으로 다룬다.
- 운영 수치(p95/RPS/오류율) 기반 안정성 검증은 Section 5에서 메인으로 다룬다.

**레이아웃**
- 상단: 맵 변경 4단계 계약
- 본문 1행 좌측: 요청/토큰 발급 단계
- 본문 1행 우측: ACK 소비/실행 단계
- 본문 2행 좌측: 실패 차단 매트릭스
- 본문 2행 우측: 입력/출력 계약
- 하단: sequence diagram

**상단 카피 (복붙용)**
- 제목: `2-4. 맵 변경은 토큰 기반 2단계 승인으로 완료한다`
- 서브카피: `요청 승인(BEGIN) -> ACK 검증 -> Room 전이 -> 완료(END)`
- 핵심 문장: `서버가 발급한 토큰과 세션 상태를 함께 검증해 중복 요청·위조 ACK·전이 꼬임을 차단한다.`

**1) 요청/토큰 발급 단계**
- `IsMapChanging()`이 true면 중복 요청을 즉시 무시한다.
- 대상 맵은 `IsValidMapId + IsWorldMapId + MapConfig 존재`를 모두 만족해야 한다.
- 세션 액터에서 `TryBeginMapChange`를 호출해 토큰/목적지/스폰 정보를 잠근다.
- 성공 시 `S_MAP_CHANGE_BEGIN(token, targetMapId, instanceId, targetChannelId, spawn)`를 전송한다.
- 세션 상태는 `MAP_CHANGE_WAITING_ACK`로 전이된다.

**2) ACK 소비/실행 단계**
- `TryConsumeMapChangeAck`는 `WAITING_ACK 상태 + 토큰 일치`일 때만 성공한다.
- ACK 소비 성공 시 세션 상태를 `MAP_CHANGE_SWITCHING`으로 전이한다.
- `playerId == 0` 또는 현재 룸 미존재/비게임룸이면 `CancelMapChange`로 즉시 종료한다.
- 실행은 현재 GameRoom 액터에 위임되며 `TransferMapChangeById`에서 실제 이동을 수행한다.
- 이동 단계에서 목적지 Room 확보 실패 시 취소하고, 거래 중이면 `TRADE_CANCEL_MAP_CHANGE`로 강제 정리한다.
- 완료 시 `EnterMapChange`가 `S_MAP_CHANGE_END`를 전송하고 `UpdateAOI(forceFullSnapshot=true)` + 파티 정보 재동기화를 수행한다.
- 던전 사망 복귀(`ForceReturnToWorld`)도 동일한 BEGIN/ACK 계약을 재사용해 전이 경로를 단일화한다.
- 세션은 마지막에 `EndMapChange`로 상태를 `NONE`으로 초기화한다.

**3) 실패 차단 매트릭스 (복붙용)**
| 실패/위험 케이스 | 서버 검증/가드 | 처리 결과 |
| --- | --- | --- |
| 중복 전이 요청 | `IsMapChanging == true` | 요청 무시 |
| 비정상 맵 이동 | `IsValidMapId/IsWorldMapId/MapConfig` 실패 | BEGIN 미발급 |
| 위조/오래된 ACK | `TryConsumeMapChangeAck` 실패 | 전이 미실행 |
| 전이 중 세션/룸 불일치 | `playerId == 0` 또는 룸 검증 실패 | `CancelMapChange` |
| 목적지 룸 준비 실패 | `GetOrCreateLobby/Room` 실패 | `CancelMapChange` |
| 전이 중 거래 상태 | `ActiveTradeId != 0` | 거래 강제 취소 후 이동 진행 |

**4) 세션 상태 전이/복구 체크포인트 (복붙용)**
| 상태 | 진입 조건 | 이탈/종료 조건 |
| --- | --- | --- |
| `NONE` | 기본 상태, 이전 전이 완료 | `TryBeginMapChange` 성공 시 `WAITING_ACK` 진입 |
| `WAITING_ACK` | `S_MAP_CHANGE_BEGIN` 발급 완료 | ACK 토큰 검증 성공 시 `SWITCHING`, 실패/예외 시 `CancelMapChange`로 `NONE` 복귀 |
| `SWITCHING` | `TryConsumeMapChangeAck` 성공 | `S_MAP_CHANGE_END` + 동기화 완료 후 `EndMapChange`로 `NONE` 복귀 |

**완료 시 재동기화 체크리스트**
- `S_MAP_CHANGE_END`에 토큰/맵/채널/좌표를 포함해 클라이언트 완료 기준을 명확히 한다.
- `UpdateAOI(forceFullSnapshot=true)`로 새 맵 기준 주변 객체 스냅샷을 즉시 재구성한다.
- 파티 정보는 별도 재전송해 UI 상태를 맵 전이 직후 일관되게 맞춘다.
- 전이 중 취소 경로(`CancelMapChange`)와 완료 경로(`EndMapChange`) 모두 상태를 `NONE`으로 수렴시킨다.

**다이어그램 (복붙용)**
```mermaid
sequenceDiagram
  participant C as Client
  participant S as SessionActor
  participant R as GameRoom
  participant N as NewRoom
  C->>S: C_MAP_CHANGE_REQ(targetMapId)
  S->>S: TryBeginMapChange(token, target, spawn)\nstate=WAITING_ACK
  S-->>C: S_MAP_CHANGE_BEGIN(token, targetMapId, spawn)
  C->>S: C_MAP_CHANGE_ACK(token)
  S->>S: TryConsumeMapChangeAck(token)\nstate=SWITCHING
  S->>R: TransferMapChangeById(...)
  R->>R: Leave + 목적지 확보 + 거래 정리
  R->>N: EnterMapChange(session, player)
  N-->>C: S_MAP_CHANGE_END(token, mapId, pos, channel)
  N->>C: AOI 풀 스냅샷 + 파티 정보 재전송
  S->>S: EndMapChange()\nstate=NONE
```

**코드 스니펫 배치**
- Snippet 16-A (요청 가드 + BEGIN 발급): `GameServer/ClientPacketHandler.MapChange.cpp:11`, `GameServer/ClientPacketHandler.MapChange.cpp:31`, `GameServer/ClientPacketHandler.MapChange.cpp:70`, `GameServer/ClientPacketHandler.MapChange.cpp:75`
- Snippet 16-B (ACK 소비 + 세션 상태 전이): `GameServer/ClientPacketHandler.MapChange.cpp:89`, `GameServer/ClientPacketHandler.MapChange.cpp:106`, `GameServer/PlayerSession.cpp:119`, `GameServer/PlayerSession.cpp:152`, `GameServer/PlayerSession.cpp:169`
- Snippet 16-C (Room 전이 실행 + 실패 취소): `GameServer/GameRoom.MapChange.cpp:14`, `GameServer/GameRoom.MapChange.cpp:44`, `GameServer/GameRoom.MapChange.cpp:56`, `GameServer/GameRoom.MapChange.cpp:130`, `GameServer/GameRoom.MapChange.cpp:136`
- Snippet 16-D (완료 패킷 + 스냅샷 재동기화): `GameServer/GameRoom.EnterLeave.cpp:95`, `GameServer/GameRoom.EnterLeave.cpp:115`, `GameServer/GameRoom.EnterLeave.cpp:126`, `GameServer/GameRoom.EnterLeave.cpp:140`

**하단 캡션**
- `맵 전이는 토큰·세션 상태·룸 전이 검증을 모두 통과한 요청만 최종 완료된다.`

---

### Page 18. 파티 구조와 정합성 제어

**페이지 역할/범위 (중복 방지 기준)**
- 이 페이지는 `파티 멤버십 정합성`(직렬 처리, 초대 수명주기, 버전 동기화, 던전 연동 예외 처리)을 메인으로 다룬다.
- 맵 전이 토큰 핸드셰이크는 Page 17에서 메인으로 다룬다.
- 인스턴스 생성/종료 자체의 생명주기는 Page 19에서 메인으로 다룬다.
- 운영 수치(p95/RPS/오류율) 기반 효과 검증은 Section 5에서 메인으로 다룬다.

**레이아웃**
- 상단: 파티 정합성 핵심 전략
- 본문 1행 좌측: 직렬화 경계와 실행 순서
- 본문 1행 우측: 초대 수명주기(발급/만료/수락 재검증)
- 본문 2행 좌측: 멤버 변경 규칙 + 버전 관리
- 본문 2행 우측: 던전 연동 예외 처리(강제 귀환/오프라인 복구)
- 하단: 상태 조회 Fan-out/Fan-in 수집 보장

**상단 카피 (복붙용)**
- 제목: `2-4. 파티 정합성은 단일 액터와 상태 잠금으로 유지한다`
- 서브카피: `초대 -> 수락 -> 멤버 변경 -> 던전 연동 예외 처리까지 단일 경로`
- 핵심 문장: `파티 변경은 PartyActor에서 직렬 처리하고, 던전 전이 구간은 잠금해 경합을 차단한다.`

**1) 직렬화 경계와 실행 순서**
- 모든 파티 변경 연산(Create/Invite/Accept/Leave/Kick/Disband)은 `PartyActor::Push` 경로로 직렬화한다.
- 조회/연산은 PartyActor 스레드에서 수행하고, 실제 송신은 각 Session 스레드로 되돌려 처리한다.
- `IsMapChanging()` 가드가 있는 요청은 전이 중 조작을 사전 차단한다.

**2) 초대 수명주기와 수락 재검증**
- 초대장은 `targetId` 기준 단일 pending으로 관리하며, 새 초대가 오면 기존 pending을 교체한다.
- 유효시간은 `GetTickCount64 + 60초`이며, 만료 시 즉시 폐기한다.
- 수락 시점에 다음을 다시 검사한다:
  - 대상이 이미 다른 파티에 들어갔는지
  - 파티가 던전 전이 중(`inDungeonTransition`)인지
  - 파티가 이미 인스턴스 내부(`instanceId != 0`)인지
- 거절 경로는 pending만 제거하고, 파티 본문 상태는 변경하지 않는다.

**3) 멤버 변경 규칙 + 버전 관리**
- 변경 연산 성공 시 `version`을 증가시켜 클라이언트 동기화 기준으로 사용한다.
- 리더 탈퇴 시 리더 권한을 남은 멤버 중 최소 ID로 위임한다.
- 강퇴/해산은 리더 권한을 재검증하고, 실패 시 상태를 변경하지 않는다.
- `BroadcastPartyInfo`/`S_PARTY_RESULT.version`은 같은 버전 축을 공유해 UI 잔상과 순서 역전을 줄인다.

**4) 던전 연동 예외 처리 (핵심)**
- 던전 내부에서 탈퇴/강퇴/해산이 발생하면 `PartyActor`가 `InstanceActor` 정리(`EjectMember/Close*`)를 오케스트레이션한다.
- 정리 완료 후 대상 세션에 `ForceReturnToWorld`를 요청해 월드 복귀를 강제한다.
- 오프라인 대상은 `MarkForceReturn`으로 마킹하고, 다음 접속(`C_ENTER_GAME`)에서 `ConsumeForceReturn`로 기본 월드 복귀를 강제한다.

**5) 상태 조회 수집 보장 (Fan-out/Fan-in)**
- `C_PARTY_STATUS_REQ`는 파티 스냅샷(version 포함)을 먼저 확보한 뒤 멤버별 세션/룸으로 분산 조회한다.
- 맵 전이 중 세션, 룸 미존재, GameRoom 변환 실패 케이스도 `remaining` 카운트를 감소시켜 응답 정체를 방지한다.
- 마지막 응답에서만 `S_PARTY_STATUS_NTF`를 조립해 전송해 일관된 스냅샷을 보장한다.

**운영 체크리스트 (복붙용)**
- 변경 연산은 반드시 PartyActor 경로로만 실행되고 있는가?
- 초대 수락 시 만료/중복가입/전이중/인스턴스 상태를 재검증하는가?
- 멤버 변경 시 `version` 증가와 브로드캐스트 버전이 일치하는가?
- 던전 탈퇴/강퇴/해산에서 인스턴스 정리와 강제 귀환이 항상 함께 수행되는가?
- 오프라인 강퇴/해산 대상의 `forceReturn`가 다음 로그인에서 소비되는가?

**코드 스니펫 배치**
- Snippet 17-A (직렬 실행 경계): `GameServer/PartyActor.h:21`, `GameServer/ClientPacketHandler.Party.cpp:68`, `GameServer/ClientPacketHandler.Party.cpp:203`, `GameServer/ClientPacketHandler.Party.cpp:388`
- Snippet 17-B (초대 수명주기/TTL): `GameServer/PartyManagerCore.cpp:66`, `GameServer/PartyManagerCore.cpp:100`, `GameServer/PartyManagerCore.cpp:108`, `GameServer/PartyManagerCore.cpp:119`
- Snippet 17-C (수락 재검증/잠금): `GameServer/PartyManagerCore.cpp:139`, `GameServer/PartyManagerCore.cpp:140`, `GameServer/PartyManagerCore.cpp:275`, `GameServer/PartyManagerCore.cpp:290`
- Snippet 17-D (멤버 변경 + 버전): `GameServer/PartyManagerCore.cpp:154`, `GameServer/PartyManagerCore.cpp:176`, `GameServer/PartyManagerCore.cpp:183`, `GameServer/PartyManagerCore.cpp:217`
- Snippet 17-E (던전 연동 강제귀환): `GameServer/PartyActor.cpp:99`, `GameServer/PartyActor.cpp:133`, `GameServer/PartyActor.cpp:155`, `GameServer/ClientPacketHandler.Party.cpp:565`, `GameServer/ClientPacketHandler.EnterGame.cpp:71`
- Snippet 17-F (상태 조회 Fan-out/Fan-in): `GameServer/ClientPacketHandler.Party.cpp:677`, `GameServer/ClientPacketHandler.Party.cpp:689`, `GameServer/ClientPacketHandler.Party.cpp:759`, `GameServer/ClientPacketHandler.Party.cpp:915`

**하단 캡션**
- `파티 정합성은 단일 액터 직렬화, 버전 동기화, 던전 예외 복구를 함께 적용할 때 안정적으로 유지된다.`

---

### Page 19. 인스턴스 던전 생명주기

**페이지 역할/범위 (중복 방지 기준)**
- 이 페이지는 `인스턴스의 생성 -> 입장 확정 -> 종료 -> Purge` 수명주기와 매핑 정리 기준을 메인으로 다룬다.
- 파티 권한/초대/수락 검증 로직은 Page 18에서 메인으로 다룬다.
- 맵 전이 토큰 승인/ACK 소비 절차는 Page 17에서 메인으로 다룬다.
- 거래 원자성(2PC/롤백)은 Page 20~22에서 메인으로 다룬다.
- 운영 수치(p95/RPS/오류율) 기반 효과 검증은 Section 5에서 메인으로 다룬다.

**레이아웃**
- 상단: 인스턴스 수명주기 핵심 계약
- 본문 1행 좌측: 생성/입장 확정 경로
- 본문 1행 우측: 종료/정리 확정 경로
- 본문 2행 좌측: 종료 트리거/예외 매트릭스
- 본문 2행 우측: 상태/매핑 정리 계약
- 하단: lifecycle 다이어그램

**상단 카피 (복붙용)**
- 제목: `2-4. 인스턴스는 생성부터 정리까지 상태로 관리한다`
- 서브카피: `ENTERING -> IN_DUNGEON -> EXITING -> NONE, 이후 Room Purge`
- 핵심 문장: `파티 상태와 인스턴스 매핑을 같은 전이 규칙으로 묶어 중복 생성과 유령 인스턴스를 방지한다.`

**1) 생성/입장 확정 경로**
- 던전 입장 요청은 파티/중복 상태를 확인한 뒤 `TryBeginDungeonTransition(... ENTERING)`으로 전이를 잠근다.
- 생성은 `InstanceActor`에서 `CreateOrGetForParty`로 수행하며, 이미 존재하면 기존 인스턴스를 재사용한다(중복 생성 방지).
- 생성 성공 시 `SetPartyInstance(instanceId, IN_DUNGEON)`와 `EndDungeonTransition(... IN_DUNGEON)`으로 파티 상태를 확정한다.
- 파티원은 `MapChangeBegin`으로 인스턴스 맵 이동을 시작한다.

**2) 종료/정리 확정 경로**
- 던전 퇴장 요청은 `TryBeginDungeonTransition(... EXITING)`으로 종료 전이를 잠근다.
- `CloseForParty` 성공 시 `partyToInstance / playerToInstance / instances` 매핑을 함께 정리한다.
- 인스턴스 룸은 `MarkClosing(true)`로 정리 대상으로 표시한다.
- 파티 상태는 `ClearPartyInstance`와 `EndDungeonTransition(... NONE)`로 기본 상태로 복귀한다.
- 월드 복귀 좌표는 `MakeSafeReturn`으로 계산해 멤버별 맵 복귀를 진행한다.

**3) 종료 트리거/예외 매트릭스 (복붙용)**
| 상황 | 서버 처리 기준 | 결과 |
| --- | --- | --- |
| 입장 중복 요청 | `inDungeonTransition` 또는 기존 `instanceId` 존재 | 입장 거절(중복 생성 방지) |
| 던전 외부에서 퇴장 요청 | `instanceId == 0` | `DUNGEON_EXIT_FAIL_NOT_IN_DUNGEON` |
| 종료 처리 실패 | `CloseForParty` 실패 | 상태 롤백(`IN_DUNGEON`) 후 실패 응답 |
| 마지막 멤버 오프라인 | `OnMemberOffline -> empty` | 인스턴스 종료 + 룸 닫힘 마킹 |
| 제한시간 초과 | `CollectExpired(now)` | `CloseForParty` 후 룸 닫힘 마킹 |
| 인스턴스 룸 비정상 잔존 | `MarkClosing + ShouldPurge` 미충족 | 즉시 삭제하지 않고 유예 후 Purge |

**4) 상태/매핑 정리 계약 (복붙용)**
| 구분 | 입력 | 출력 |
| --- | --- | --- |
| 파티 기준 매핑 | `partyId -> instanceId` | 생성/종료 시 동기 갱신 |
| 플레이어 역인덱스 | `playerId -> instanceId` | 강퇴/오프라인/종료 시 제거 |
| 파티 상태 | `ENTERING/IN_DUNGEON/EXITING/NONE` | 전이 완료 시 일관 상태 유지 |
| 룸 정리 신호 | `MarkClosing(true)` | `PurgeInstanceRooms` 대상 편입 |

**Purge 기준 (요약)**
- 인스턴스 룸이어야 한다(`instanceId != 0`).
- 닫힘 상태여야 한다(`IsClosing == true`).
- 방 인원이 0명이어야 한다.
- `emptySince` 이후 유예 시간(10초) 경과 시 삭제한다.

**다이어그램 (복붙용)**
```mermaid
flowchart TD
  A["C_DUNGEON_ENTER_REQ"] --> B["TryBeginDungeonTransition(ENTERING)"]
  B --> C["CreateOrGetForParty"]
  C --> D["SetPartyInstance + EndDungeonTransition(IN_DUNGEON)"]
  D --> E["파티원 MapChangeBegin -> 인스턴스 플레이"]
  E --> F{"퇴장/강퇴/해산/오프라인/타임아웃"}
  F --> G["CloseForParty or CloseByInstanceId"]
  G --> H["매핑 정리 + ClearPartyInstance + EndTransition(NONE)"]
  H --> I["room.MarkClosing(true)"]
  I --> J{"ShouldPurge 충족?"}
  J -->|Yes| K["RoomManager.PurgeInstanceRooms"]
  J -->|No| L["유예 후 재평가"]
```

**코드 스니펫 배치**
- Snippet 18-A (생성/중복 방지): `GameServer/InstanceManagerCore.cpp:41`, `GameServer/InstanceManagerCore.cpp:49`, `GameServer/InstanceManagerCore.cpp:57`
- Snippet 18-B (종료/역인덱스 정리): `GameServer/InstanceManagerCore.cpp:79`, `GameServer/InstanceManagerCore.cpp:96`, `GameServer/InstanceManagerCore.cpp:182`
- Snippet 18-C (입장 전이 확정): `GameServer/ClientPacketHandler.Dungeon.cpp:134`, `GameServer/ClientPacketHandler.Dungeon.cpp:159`, `GameServer/ClientPacketHandler.Dungeon.cpp:189`
- Snippet 18-D (퇴장 전이/룸 닫힘): `GameServer/ClientPacketHandler.Dungeon.cpp:360`, `GameServer/ClientPacketHandler.Dungeon.cpp:384`, `GameServer/ClientPacketHandler.Dungeon.cpp:414`, `GameServer/ClientPacketHandler.Dungeon.cpp:422`
- Snippet 18-E (오프라인/강제 정리): `GameServer/PlayerSession.cpp:78`, `GameServer/PlayerSession.cpp:82`, `GameServer/PartyActor.cpp:133`, `GameServer/PartyActor.cpp:171`
- Snippet 18-F (타임아웃/Purge): `GameServer/InstanceActor.h:33`, `GameServer/InstanceActor.h:39`, `GameServer/RoomManager.cpp:125`, `GameServer/GameRoom.LifeTime.cpp:180`

**하단 캡션**
- `인스턴스는 파티 상태 전이와 매핑 정리를 함께 적용해 생성부터 Purge까지 일관되게 수렴한다.`

---

## 2-5. 거래 원자성 보장 (Page 20~22)

### Page 20. 거래 상태머신

**페이지 역할/범위 (중복 방지 기준)**
- 이 페이지는 `거래 세션의 상태 전이와 런타임 가드`를 메인으로 다룬다.
- Phase 1 계획 수립, DBAgent 트랜잭션, DB 성공/실패 반영 상세는 Page 21에서 메인으로 다룬다.
- 실패 케이스 검증 결과(시나리오/로그 증빙)는 Page 22에서 메인으로 다룬다.
- 맵 전이 승인 절차 자체는 Page 17, 파티 권한/정합성은 Page 18에서 메인으로 다룬다.
- 따라서 Page 20은 `상태 정의 + 전이 규칙 + 강제 취소 조건`에 집중한다.

**레이아웃**
- 상단: 거래 상태 전이 핵심 문장
- 본문 1행 좌측: 상태별 책임/허용 동작
- 본문 1행 우측: 전이 게이트(진입 조건/실패 처리)
- 본문 2행 좌측: 강제 취소 트리거
- 본문 2행 우측: 세션 정리 불변조건
- 하단: 상태 다이어그램

**상단 카피 (복붙용)**
- 제목: `2-5. 거래 상태 전이로 동시 조작을 차단한다`
- 서브카피: `Invited -> Active -> Locked -> Committing`
- 핵심 문장: `거래는 상태별 허용 동작을 고정하고, 상태 위반 요청은 즉시 차단해 정합성을 유지한다.`

**1) 상태별 책임/허용 동작**
| 상태 | 상태 의미 | 허용 동작 | 차단 동작 |
| --- | --- | --- | --- |
| Invited | 초대 대기 구간 | 수락/거절 응답 | 아이템/골드 제안, Confirm |
| Active | 제안 조정 구간 | 아이템/골드 제안, Ready 토글 | Confirm(잠금 전), 커밋 |
| Locked | 제안 확정 구간 | Confirm 대기/입력 | Offer/Gold 변경, 임의 취소 후 수정 |
| Committing | DB 결과 대기 구간 | 결과 수신 후 성공/내부취소 | 사용자 취소, 제안 변경 |

**2) 전이 게이트 (진입 조건/실패 처리)**
| 전이 | 진입 조건 | 실패 시 처리 |
| --- | --- | --- |
| `None -> Invited` | 대상 유효, 상대 세션 존재, 맵 전이 중 아님, 양측 `ActiveTradeId == 0`, 거리 조건 통과 | 실패 응답 후 미진입 |
| `Invited -> Active` | 초대 대상(B) 수락 + 양측 플레이어 유효 | 거절/유실 시 거래 세션 취소 |
| `Active -> Locked` | 양측 `Ready == true` | 상태 유지(Active) |
| `Locked -> Committing` | 양측 `Confirm == true` | 상태 유지(Locked) |
| `Committing -> 종료` | DB 성공 또는 내부 실패 처리 | 성공 시 완료, 실패 시 내부 취소 |

**3) 강제 취소 트리거**
| 트리거 | 처리 기준 | 결과 |
| --- | --- | --- |
| 사용자 취소 | `state != Committing`에서만 허용 | `CancelTrade` 후 세션 정리 |
| 거래 타임아웃 | `lastTouchedMs` 기준 `kTradeTimeoutMs` 초과 (`Committing` 제외) | `TRADE_CANCEL_TIMEOUT` |
| 맵 전이 시작 | 맵 이동 처리 진입 시 활성 거래 존재 | `TRADE_CANCEL_MAP_CHANGE` |
| 접속 종료/룸 이탈 | `Leave` 경로에서 활성 거래 존재 | `TRADE_CANCEL_DISCONNECT` |
| 내부 오류 | 플레이어 누락/상태 불일치 등 | `TRADE_CANCEL_INTERNAL` |

**4) 세션 정리 불변조건**
- 거래 종료(성공/취소) 시 `_tradeByPlayer(A/B)`는 반드시 제거된다.
- 거래 종료 시 양측 `ActiveTradeId`는 반드시 `0`으로 초기화된다.
- `Committing` 상태에서는 사용자 취소를 허용하지 않는다(내부 실패만 취소 가능).
- 제안 변경(아이템/골드) 발생 시 `Ready/Confirm`는 즉시 초기화되어 잠금 재검증을 강제한다.
- 최종 자산 반영(골드/아이템)은 `Committing` 이후 경로에서만 수행한다(상세는 Page 21).

**다이어그램 (복붙용)**
```mermaid
stateDiagram-v2
  [*] --> Invited: C_TRADE_REQ (유효성/거리/중복 검사 통과)
  Invited --> Active: C_TRADE_INVITE_RESP(accept)
  Invited --> [*]: reject/cancel
  Active --> Active: OFFER_SET/GOLD_SET (Ready/Confirm reset)
  Active --> Locked: READY(A,B)
  Locked --> Committing: CONFIRM(A,B)
  Active --> [*]: CANCEL/TIMEOUT/MAP_CHANGE/DISCONNECT
  Locked --> [*]: CANCEL/TIMEOUT/MAP_CHANGE/DISCONNECT
  Committing --> [*]: commit success
  Committing --> [*]: internal fail
```

**코드 스니펫 배치**
- Snippet 19-A (상태 정의): `GameServer/GameRoom.h:299`, `GameServer/GameRoom.h:336`
- Snippet 19-B (진입 게이트): `GameServer/GameRoom.Trade.cpp:136`, `GameServer/GameRoom.Trade.cpp:159`, `GameServer/GameRoom.Trade.cpp:167`, `GameServer/GameRoom.Trade.cpp:174`
- Snippet 19-C (상태 전이/잠금): `GameServer/GameRoom.Trade.cpp:405`, `GameServer/GameRoom.Trade.cpp:447`, `GameServer/GameRoom.Trade.cpp:457`, `GameServer/GameRoom.Trade.cpp:489`
- Snippet 19-D (강제 취소/타임아웃): `GameServer/GameRoom.Trade.cpp:566`, `GameServer/GameRoom.Trade.cpp:611`, `GameServer/GameRoom.MapChange.cpp:53`, `GameServer/GameRoom.EnterLeave.cpp:165`
- Snippet 19-E (입력 진입 차단): `GameServer/ClientPacketHandler.Trade.cpp:15`, `GameServer/ClientPacketHandler.Trade.cpp:169`
- 2PC 상세 연결: `GameServer/GameRoom.Trade.cpp:944` (Page 21에서 상세)

**하단 캡션**
- `거래는 상태별 허용 동작과 강제 취소 경로를 분리해, 중간 조작 없이 일관된 종료 상태로 수렴한다.`

---

### Page 21. 2-Phase Commit

**페이지 역할/범위 (중복 방지 기준)**
- 이 페이지는 `거래 확정의 2단계 커밋 실행 계약`을 메인으로 다룬다.
- 상태 전이(Invited/Active/Locked/Committing)와 강제 취소 트리거는 Page 20에서 메인으로 다룬다.
- 케이스별 결과 검증(성공/실패 시나리오, 로그 증빙)은 Page 22에서 메인으로 다룬다.
- 따라서 Page 21은 `Phase 1 계획 수립 -> Phase 2 DB 트랜잭션 -> 응답 매칭/적용` 순서에 집중한다.

**레이아웃**
- 상단: 2단계 커밋 핵심 계약
- 본문 1행 좌측: Phase 1 계획 수립(게임 서버)
- 본문 1행 우측: Phase 2 DB 트랜잭션(DBAgent)
- 본문 2행 좌측: 응답 매칭/적용 가드
- 본문 2행 우측: 실패 수렴 매트릭스
- 하단: 2PC 핸드셰이크 흐름

**상단 카피 (복붙용)**
- 제목: `2-5. 거래 확정은 2단계 커밋으로 원자화한다`
- 서브카피: `사전 시뮬레이션 -> DB 단일 트랜잭션 -> 성공 응답 후 반영`
- 핵심 문장: `DB 성공 응답 전에는 메모리/클라이언트 자산을 확정하지 않는다.`

**1) Phase 1 계획 수립 (GameServer)**
- 진입 조건: `Locked` 상태에서 양측 `Confirm` 완료
- `BuildTradeCommitPlan`에서 스냅샷 기반 시뮬레이션 수행
  - 골드 음수/잔액 초과/오버플로우 검증
  - 제안 아이템 유효성(실존/장착/수량) 검증
  - 슬롯 재배치/스택 병합/인벤토리 full 검증
- 산출물: `finalA/BItems`, `deletedA/BItemUids`, `finalGoldA/B`, notify delta
- 실패 시점: DB 요청 없이 즉시 내부 취소

**2) Phase 2 DB 트랜잭션 (DBAgent)**
- `BEGIN TRAN`
- A/B 아이템 `DELETE/UPSERT` + A/B 골드 `UPDATE`를 같은 트랜잭션 경계에서 처리
- 성공 `COMMIT`, 실패 `ROLLBACK`
- 응답에는 `tradeId + route(channel/map/instance) + requestId`를 echo

**3) 응답 매칭/적용 가드**
- S2S 응답은 `channel/map/instance`로 대상 Room을 찾아 Actor 큐에 직렬 전달
- 적용 전 가드:
  - `state == Committing`
  - `requestId` 일치(오래된 응답/stale response 무시)
  - `commitPlan` 존재
- 성공 시:
  - 메모리 아이템/골드 확정 반영
  - Redis 동기화(`markDirty=false`) 및 클라이언트 delta 전송
  - `ActiveTradeId`/세션 매핑 정리
- 실패 시:
  - 내부 취소 경로로 수렴(`CancelTrade INTERNAL`)

**4) 실패 수렴 매트릭스**
| 실패 지점 | 서버 처리 | 보장 결과 |
| --- | --- | --- |
| Phase 1 검증 실패 | DB 요청 생략 + 내부 취소 | 중간 반영 없음 |
| DB 세션 미존재 | `commitPlan/reset` 후 실패 반환 | in-flight 잔존 방지 |
| DB 트랜잭션 실패 | `ROLLBACK` + fail 응답 | 반영 원자성 유지 |
| 응답 requestId 불일치 | stale 응답 무시 | 오래된 응답 재적용 방지 |
| 적용 시 플레이어 누락 | 내부 취소 | 부분 반영 차단 |

**다이어그램 (복붙용)**
```mermaid
flowchart TD
  A[Locked + Confirm(A,B)] --> B[Phase1 BuildTradeCommitPlan]
  B -->|Fail| X1[CancelTrade INTERNAL]
  B -->|Success| C[Set commitPlan + requestId]
  C --> D[S2S_REQ_TRADE_COMMIT]
  D --> E[DBAgent BEGIN TRAN]
  E --> F[A/B DELETE + UPSERT + GOLD UPDATE]
  F -->|Success| G[COMMIT]
  F -->|Fail| H[ROLLBACK]
  G --> I[S2S_RES success + requestId echo]
  H --> J[S2S_RES fail + requestId echo]
  I --> K{Room route + state/requestId 검증}
  J --> K
  K -->|Pass + success| L[메모리/Redis/클라 반영]
  K -->|Fail or db fail| M[CancelTrade INTERNAL]
```

**코드 스니펫 배치**
- Snippet 20-A (Phase 1 계획/검증): `GameServer/GameRoom.Trade.cpp:624`, `GameServer/GameRoom.Trade.cpp:651`, `GameServer/GameRoom.Trade.cpp:658`, `GameServer/GameRoom.Trade.cpp:883`, `GameServer/GameRoom.Trade.cpp:918`
- Snippet 20-B (Phase 2 요청/in-flight 가드): `GameServer/GameRoom.Trade.cpp:944`, `GameServer/GameRoom.Trade.cpp:955`, `GameServer/GameRoom.Trade.cpp:972`, `GameServer/GameRoom.Trade.cpp:996`, `Common/Protobuf/bin/Protocol_S2S.proto:175`
- Snippet 20-C (DB 트랜잭션 본체): `DBAgent/DBAgentPacketHandler.cpp:821`, `DBAgent/DBAgentPacketHandler.cpp:856`, `DBAgent/DBAgentPacketHandler.cpp:895`, `DBAgent/DBAgentPacketHandler.cpp:1025`
- Snippet 20-D (응답 라우팅/매칭 가드): `GameServer/S2SPacketHandler.cpp:134`, `GameServer/S2SPacketHandler.cpp:140`, `GameServer/GameRoom.Trade.cpp:1023`, `GameServer/GameRoom.Trade.cpp:1035`
- Snippet 20-E (성공 적용/정리): `GameServer/GameRoom.Trade.cpp:1065`, `GameServer/GameRoom.Trade.cpp:1072`, `GameServer/GameRoom.Trade.cpp:1127`, `GameServer/GameRoom.Trade.cpp:1134`

**하단 캡션**
- `2단계 커밋은 사전 계획과 단일 DB 트랜잭션, 응답 매칭 가드를 결합해 부분 반영을 차단한다.`

---

### Page 22. 거래 검증 결과

**페이지 역할/범위 (중복 방지 기준)**
- 이 페이지는 `거래 확정 구조가 실제 케이스에서 의도대로 수렴하는지`를 검증 결과 중심으로 다룬다.
- 상태 정의/전이 규칙은 Page 20에서 메인으로 다룬다.
- 2단계 커밋 내부 설계(Phase 1/2 처리 상세)는 Page 21에서 메인으로 다룬다.
- 따라서 Page 22는 `실패/경계/동시성 케이스 + 로그 증빙 + 통과 기준`에 집중한다.

**레이아웃**
- 상단: 검증 목표
- 본문 1행: 케이스 검증 매트릭스(실패/경계/동시성/응답 무결성)
- 본문 2행: 재현 절차 요약 + 로그 관찰 포인트
- 하단: 통과 기준 + 결론 한 줄

**상단 카피 (복붙용)**
- 제목: `2-5. 거래 검증: 실패는 무효, 성공은 동시 확정`
- 서브카피: `원자성과 정합성을 시나리오 기반으로 확인`

**테스트 케이스 표 (복붙용)**
| 분류 | 케이스 | 기대 결과 | 핵심 관찰 포인트 | 근거 코드 |
| --- | --- | --- | --- | --- |
| 사전 검증 실패 | 인벤 부족/슬롯 불가 | Phase 1에서 실패, DB 요청 없음 | `S2S_REQ_TRADE_COMMIT` 미발행, 즉시 취소 응답 | `GameServer/GameRoom.Trade.cpp:883`, `GameServer/GameRoom.Trade.cpp:918`, `GameServer/GameRoom.Trade.cpp:944` |
| 사전 검증 실패 | 골드 음수/초과/오버플로우 | 사전 차단, 커밋 불가 | `commitPlan` 미생성 또는 즉시 폐기 | `GameServer/GameRoom.Trade.cpp:651`, `GameServer/GameRoom.Trade.cpp:658`, `GameServer/GameRoom.Trade.cpp:667` |
| DB 실패 수렴 | DBAgent 트랜잭션 실패 | `ROLLBACK` 후 내부 취소 | fail 응답 후 부분 반영 없음 | `DBAgent/DBAgentPacketHandler.cpp:1026`, `GameServer/GameRoom.Trade.cpp:1045` |
| 응답 무결성 | `requestId` 불일치(stale 응답) | 응답 무시, 재적용 없음 | state/requestId 가드 실패 로그 확인 | `GameServer/GameRoom.Trade.cpp:1023`, `GameServer/GameRoom.Trade.cpp:1035` |
| 동시성/경합 | 동일 대상 동시 거래 시도 | 중복 거래 차단, 상태 위반 없음 | 한쪽만 진입, 나머지 실패 응답 | `GameServer/ClientPacketHandler.Trade.cpp:25`, `GameServer/GameRoom.Trade.cpp:470` |
| 성공 경로 | 정상 교환 완료 | 양측 자산 동시 반영 + 세션 정리 | success 결과 + `ActiveTradeId` 초기화 | `GameServer/GameRoom.Trade.cpp:1065`, `GameServer/GameRoom.Trade.cpp:1134` |

**재현 절차 요약**
- 케이스별 입력을 고정 순서로 재생한다: 초대 -> 수락 -> 제안/잠금 -> 확정(또는 실패 트리거).
- 동일 케이스를 최소 3회 반복해 결과 일관성을 확인한다.
- 실패 케이스는 `중간 반영 없음`을 우선 검증하고, 성공 케이스는 `양측 동시 반영`을 확인한다.

**증빙 체크리스트**
- 공통 식별자: `tradeId`, `requestId`, `channel/map/instance`가 요청-응답에서 일치한다.
- 성공: `S_TRADE_RESULT(success=true)` + 양측 골드/아이템 delta + 거래 세션 정리(`ActiveTradeId == 0`)
- 실패: `S_TRADE_RESULT(success=false)` + `S_TRADE_CANCELLED` + 메모리/Redis 부분 반영 없음
- DB: 트랜잭션 분기(`COMMIT`/`ROLLBACK`)와 GameServer 적용 결과가 동일 케이스에서 일관된다.

**통과 기준**
- 실패 케이스는 모두 `중간 반영 없음`으로 수렴해야 한다.
- 성공 케이스는 양측 자산이 동시에 반영되고 거래 세션이 즉시 정리되어야 한다.
- stale 응답/중복 입력에서 재적용 또는 이중 커밋이 발생하지 않아야 한다.

**최종 결론 카피**
- `검증 실패 시 전체 롤백, 성공 시 동시 반영이 유지되어 거래 정합성이 보장된다.`

---

## Section 2 작성 가이드 (디자인 공통)

- 각 페이지는 `문제 -> 처리 원칙 -> 흐름도 -> 코드 근거` 순서로 고정
- 문단은 3줄 이내, 설명은 카드/표로 분해
- 하단 캡션은 반드시 한 줄 결론으로 통일
- 코드 스니펫은 페이지당 2~4개만 선택해 가독성 유지
